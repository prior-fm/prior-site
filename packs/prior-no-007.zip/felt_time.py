"""Where the middle of your life actually is, under a logarithmic model.

    python felt_time.py            # the film's own numbers
    python felt_time.py 31         # your age
    python felt_time.py 31 --first-memory 3 --lifespan 79

THE MODEL, and its one assumption. Janet's proportional law (Paul Janet, 1897)
says you judge an interval against the length of life you have already lived. A
year at seven is a seventh of everything you remember; a year at fifty is a
forty-sixth. So felt duration is not the interval itself but the interval
divided by your current age — and the total felt time between two ages is

    integral from a to b of (1/t) dt  =  ln(b) - ln(a)

which is why the scale is logarithmic and why it cannot start at zero: ln(0) is
undefined. The film floors it at first memory, because there is no experience
before that to judge anything against.

The felt midpoint of a life running from `a` to `b` is therefore the age m where
ln(m) - ln(a) equals ln(b) - ln(m), and that solves to

    m = sqrt(a * b)

the geometric mean. With the film's inputs, sqrt(4 * 81) = 18 exactly.

WHAT THIS IS NOT. It is a model, not a measurement. Nobody has measured that
your felt midpoint is 18; what has been measured, repeatedly, is that people
report time accelerating with age, and this is the oldest and simplest account
of why. The answer moves with both inputs — run --sweep and watch it move. The
commonly cited form of Janet's law puts the felt midpoint nearer twenty than
eighteen, on different assumed inputs.

Stdlib only. No dependencies, nothing to install.
"""

from __future__ import annotations

import argparse
import math

FIRST_MEMORY = 4.0   # the film's input: first memories at four
LIFESPAN = 81.0      # the film's input: a life of eighty-one years


def felt(age: float, a: float) -> float:
    """Felt time accumulated from first memory `a` to `age`, in ln-units."""
    return math.log(max(age, a)) - math.log(a)


def midpoint(a: float, b: float) -> float:
    """The felt midpoint of a life running a..b — the geometric mean."""
    return math.sqrt(a * b)


def report(age: float, a: float, b: float) -> str:
    m = midpoint(a, b)
    total = felt(b, a)
    lived = felt(age, a)
    calendar = min(age / b, 1.0)

    bar_w = 46
    filled = round(bar_w * min(lived / total, 1.0))
    cal_filled = round(bar_w * calendar)
    mark = round(bar_w * felt(m, a) / total)

    def bar(n: int) -> str:
        return "#" * n + "." * (bar_w - n)

    ruler = "".join("^" if i == mark else " " for i in range(bar_w))

    lines = [
        "",
        f"  first memory {a:g}      life expectancy {b:g}",
        f"  felt midpoint of that life: {m:.1f}",
        "",
        f"  you are {age:g}.",
        "",
        f"  calendar life  [{bar(cal_filled)}]  {100 * calendar:5.1f}% spent",
        f"  FELT life      [{bar(filled)}]  {100 * lived / total:5.1f}% spent",
        f"                  {ruler}  <- the felt midpoint",
        "",
    ]

    if age < m:
        remaining = felt(m, a) - lived
        years = a * math.exp(lived + remaining) - age
        lines.append(f"  the middle of your life is still {years:.1f} years away.")
    elif abs(age - m) < 0.05:
        lines.append("  you are standing on it.")
    else:
        lines.append(f"  the middle of your life was {age - m:.1f} years ago,")
        lines.append(f"  at {m:.1f} -- {100 * (age - m) / b:.1f}% of a calendar life back,")
        lines.append(f"  and {100 * (lived - felt(m, a)) / total:.1f}% of a felt one.")
    lines.append("")
    return "\n".join(lines)


def sweep(a: float, b: float) -> str:
    """How much the answer moves when you move the inputs."""
    out = ["", "  the answer is a MODEL OUTPUT, and it moves:", "",
           "     first memory ->     2      3      4      5      6", ""]
    for life in (70, 75, 80, 81, 85, 90):
        row = f"  lifespan {life:3d}   " + "".join(
            f"{midpoint(fm, life):7.1f}" for fm in (2, 3, 4, 5, 6))
        out.append(row)
    out += ["", f"  the film uses {a:g} and {b:g}, which is the only pair in this",
            "  table that gives a whole number. That is why it was chosen.", ""]
    return "\n".join(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("age", nargs="?", type=float, default=None,
                   help="your age in years")
    p.add_argument("--first-memory", type=float, default=FIRST_MEMORY)
    p.add_argument("--lifespan", type=float, default=LIFESPAN)
    p.add_argument("--sweep", action="store_true",
                   help="show how the answer moves with the two inputs")
    args = p.parse_args()

    a, b = args.first_memory, args.lifespan
    if a <= 0:
        p.error("first memory must be greater than zero — ln(0) is undefined, "
                "and that is the whole reason this scale has a floor")
    if b <= a:
        p.error("lifespan must be greater than first memory")

    if args.sweep:
        print(sweep(a, b))
        return 0

    if args.age is None:
        print(f"\n  sqrt({a:g} x {b:g}) = {midpoint(a, b):.1f}\n")
        print("  pass your age for the rest:  python felt_time.py 31")
        print("  or see how much it moves:    python felt_time.py --sweep\n")
        return 0

    if args.age < 0:
        p.error("age must not be negative")
    print(report(args.age, a, b))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

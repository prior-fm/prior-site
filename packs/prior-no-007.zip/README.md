# Prior — No. 007 — Why time speeds up

Two files. Neither installs anything, neither touches the network.

| | |
|---|---|
| `felt-time.html` | Open it in any browser. Enter your age; change either assumption and watch the answer move. |
| `felt_time.py` | The same model at a terminal. Python 3, standard library only. |

```
python felt_time.py 31
python felt_time.py --sweep
python felt_time.py 31 --first-memory 3 --lifespan 79
```

---

## The claim

You judge an interval against the length of life you have already lived. A year
at seven is a seventh of everything you remember. A year at fifty is a
forty-sixth of it. So the same year is not the same amount of experience, and
the middle of a life is not its calendar midpoint.

## The maths, in full

Felt duration is the interval divided by your current age, so the felt time
accumulated between two ages `a` and `b` is

```
∫ from a to b of (1/t) dt  =  ln(b) − ln(a)
```

Two consequences follow immediately, and both matter.

**The scale is logarithmic.** Not as a metaphor — that integral *is* a
logarithm.

**It cannot start at zero.** `ln(0)` is undefined, so the model has to be
floored somewhere, and first memory is the honest place: there is no experience
before it against which anything could be judged.

The felt midpoint is the age `m` where the felt time before it equals the felt
time after:

```
ln(m) − ln(a) = ln(b) − ln(m)
        2 ln(m) = ln(a) + ln(b)
              m = √(a · b)
```

The geometric mean. With first memory at 4 and a life of 81 years,
`√(4 × 81) = √324 = 18`, exactly.

## What this is not

**It is a model, not a measurement.** Nobody has measured that your felt
midpoint is 18. What *has* been measured, repeatedly, is that people report time
accelerating with age. This is the oldest and simplest account of why — the
proportional account usually credited to Paul Janet in 1897 — and it is the same
Weber–Fechner logarithm that puts decibels and stellar magnitudes on log scales.

**The answer moves with both inputs, and it is worth seeing how far.** Run
`--sweep`, or change the two numbers in the HTML:

```
     first memory ->     2      3      4      5      6

  lifespan  70      11.8   14.5   16.7   18.7   20.5
  lifespan  75      12.2   15.0   17.3   19.4   21.2
  lifespan  80      12.6   15.5   17.9   20.0   21.9
  lifespan  81      12.7   15.6   18.0   20.1   22.0
  lifespan  85      13.0   16.0   18.4   20.6   22.6
  lifespan  90      13.4   16.4   19.0   21.2   23.2
```

18 is the top of a range that runs from roughly 12 to 23 across defensible
inputs, and the commonly cited form of Janet's law lands nearer twenty. **4 and
81 are the only pair in that table that produce a whole number**, which is why
the film uses them — and it is a useful habit to ask that of any number which
arrives looking suspiciously tidy.

---

## Who made this

Prior is made by the same person who writes **Vektor** — the how-I-actually-ship
side of the same work: the tools, the pipeline, and the things that go wrong on
the way to a finished thing.

**Prior shows you the idea. Vektor shows you the build.**

- Vektor — [vektor-fm.github.io/vektor-site](https://vektor-fm.github.io/vektor-site/) · [@vektor.fm](https://instagram.com/vektor.fm)
- Prior — [prior-fm.github.io/prior-site](https://prior-fm.github.io/prior-site/) · [@prior.fm](https://instagram.com/prior.fm)

Every issue ships its full source, free.

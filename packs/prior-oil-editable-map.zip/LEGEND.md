# OIL editable map — legend

- **Shared pipe:** the East-West Pipeline/Petroline is one shared land bottleneck feeding Yanbu; the north and south branches are not independent pipelines.
- **North:** tanker leg Yanbu → Ain Sokhna, then a schematic SUMED land-transfer leg → Sidi Kerir. The line is intentionally continuous for editing, but the land transfer is not a sea route.
- **South:** tanker leg Yanbu → Bab el-Mandeb → Asia.
- **Front:** Gulf loading route through Hormuz.
- **Route line:** schematic direction of movement, not a surveyed shipping lane.
- **Route state:** open, restricted, contested and precautionary-shut are editorial states; they do not mean that all shipping is controlled or stopped.
- **Geography:** country shapes and borders are approximate and intended for explanation, not navigation.

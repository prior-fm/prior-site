# OIL editable map — source register

This package is an editable schematic reconstruction, not a live geopolitical or navigation dataset. The routes are included to explain the film's visual logic.

## Reference sources

- [Saudi Aramco Q1 2026 results](https://www.aramco.com/en/news-media/news/2026/aramco-announces-first-quarter-2026-results), 10 May 2026 — East-West Pipeline maximum capacity statement.
- [JODI oil data](https://www.jodidata.org/), June 2026 dashboard — national Saudi crude-export metric.
- [AP route explainer](https://apnews.com/article/yemen-houthis-war-saudi-oil-iran-us-9c2b68921a16bb7bf9a90d31fb7473d9), 12 September 2026 — Yanbu, SUMED/Suez and Bab el-Mandeb route explanation.
- [AP Mayun / pipeline report](https://apnews.com/article/025d052a14d9481258d51009a76d0bd6), 11 September 2026 — reported pipeline shutdown and Mayun/Perim capture.
- [Energy News Today route report](https://energynews.today/2026/08/12/saudi-arabia-ramps-up-oil-exports-through-mediterranean-pipeline-to-avoid-attacks-in-red-sea/), 12 August 2026 — Kpler weekly Yanbu comparison, Sidi Kerir comparison and Aramco 25-day route estimate.
- [Energy World tracker comparison](https://energyworld.co.id/2026/08/12/ekspor-minyak-arab-saudi-di-laut-merah-terhenti-karena-ancaman-serangan-houthi-meningkat/), 12 August 2026 — Vortexa/Kpler/AXSMarine disagreement and AIS-darkness caveat.
- [Al-Monitor tanker/export report](https://www.al-monitor.com/originals/2026/09/saudi-oil-exports-hit-nine-year-low-tanker-attacks-threaten-recovery), 2 September 2026 — tanker incident and conflicting August export estimate.

## Status

These sources support route explanation and provenance, but they do not turn this package into a current operational map. Event claims, tracker estimates and political responsibility remain time-sensitive and should be rechecked before reuse.

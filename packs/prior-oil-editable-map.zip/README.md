# Prior OIL — editable map resource

This is the local resource promised by the film CTA: a standalone HyperFrames
map project containing Prior's reconstructed atlas, editable camera poses, and
editable schematic route geometry.

## Build

```powershell
npm run build
```

Open `index.html` in HyperFrames Studio after building. Edit:

- `data/routes.json` for route coordinates as `[longitude, latitude]` pairs.
- `data/camera.json` for camera positions, scale, and travel timings.
- `data/editorial-system.json` for map typography and border tokens.

The included `hyperframes.json` identifies this folder as a self-contained
HyperFrames project and keeps Studio discovery/import paths portable after the
folder or ZIP is moved.

The route lines are schematic editorial reconstructions, not navigation data.
This package contains geography and route geometry only. It does not contain the
source film, narration, background music, current political/event claims, or
the film's original credit wording.

## Provenance and limits

Country geometry is the local Natural Earth / World Atlas 10m dataset already
used by the Prior map build. Fonts are the bundled free-licensed Newsreader and
IBM Plex Mono files; their license texts are included beside them. GSAP is the
local project copy used by the map composition. The Prior mark is the local
brand PNG used by the film.

Camera positions and routes are reconstructed from the source film's visible
geography and remain approximate. This is an editable schematic demonstration,
not a claim that the map reproduces operational infrastructure precisely.

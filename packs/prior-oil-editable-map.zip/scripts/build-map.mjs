export function buildMap(topology, poses, duration, palette, editorial, routeDataInput){
 const merc=lat=>Math.log(Math.tan(Math.PI/4+Math.max(-80,Math.min(80,lat))*Math.PI/360))*180/Math.PI;
 const xy=([lon,lat])=>[(lon-44)*50+540,(merc(24)-merc(lat))*50+800];
 const decoded=topology.arcs.map(a=>{let x=0,y=0;return a.map(([dx,dy])=>{x+=dx;y+=dy;return xy([x*topology.transform.scale[0]+topology.transform.translate[0],y*topology.transform.scale[1]+topology.transform.translate[1]])})});
 const ring=a=>a.flatMap((id,i)=>{const pts=id<0?[...decoded[~id]].reverse():decoded[id];return i?pts.slice(1):pts});
 const names=new Set(['Egypt','Sudan','Eritrea','Ethiopia','Djibouti','Somalia','Yemen','Saudi Arabia','Israel','Palestine','Jordan','Iraq','Iran','Kuwait','Qatar','United Arab Emirates','Oman','Syria','Lebanon','Turkey','Kenya','Uganda','South Sudan','Libya','Tanzania','Mozambique','South Africa','Namibia','Botswana','Zimbabwe','Zambia','Malawi','Lesotho','Madagascar','Spain','Portugal','Morocco','Algeria','Tunisia','Gibraltar','Angola','Benin','Burkina Faso','Burundi','Cameroon','Central African Rep.','Chad','Comoros','Congo','Dem. Rep. Congo','Eq. Guinea','Gabon','Gambia','Ghana','Guinea','Guinea-Bissau','Liberia','Mali','Mauritania','Mauritius','Niger','Nigeria','Rwanda','Senegal','Sierra Leone','Togo','W. Sahara','Cabo Verde','São Tomé and Principe']);
 const selected=topology.objects.countries.geometries.filter(g=>names.has(g.properties.name));
 const polygons=g=>g.type==='Polygon'?[g.arcs]:g.arcs;
 const allArcUses=new Map(),selectedArcs=new Set();
 for(const g of topology.objects.countries.geometries)for(const p of polygons(g))for(const r of p)for(const id of r){const key=id<0?~id:id;allArcUses.set(key,(allArcUses.get(key)||0)+1);}
 for(const g of selected)for(const p of polygons(g))for(const r of p)for(const id of r)selectedArcs.add(id<0?~id:id);
 const edgePath=coast=>[...selectedArcs].filter(id=>(allArcUses.get(id)===1)===coast).map(id=>'M'+decoded[id].map(q=>q.map(v=>v.toFixed(3)).join(',')).join('L')).join('');
 const edges=`<path id="world-coastlines" class="world-edge" d="${edgePath(true)}"/><path id="world-country-borders" class="world-edge" d="${edgePath(false)}"/>`;
 const land=selected.map(g=>{
  const ps=g.type==='Polygon'?[g.arcs]:g.arcs;
  const d=ps.map(p=>p.map(a=>'M'+ring(a).map(q=>q.map(v=>v.toFixed(3)).join(',')).join('L')+'Z').join('')).join('');
  return `<path class="world-land" d="${d}"/>`;
 }).join('');
 const perimCenter=xy([43.42,12.65]);
 const yemen=topology.objects.countries.geometries.find(g=>g.properties.name==='Yemen');
 const perim=(yemen.type==='Polygon'?[yemen.arcs]:yemen.arcs).filter(p=>ring(p[0]).every(([x,y])=>Math.abs(x-perimCenter[0])<4&&Math.abs(y-perimCenter[1])<4));
 if(perim.length!==1)throw new Error(`Expected one local Perim polygon, found ${perim.length}`);
 const perimPath=perim.map(p=>p.map(a=>'M'+ring(a).map(q=>q.join(',')).join('L')+'Z').join('')).join('');
 const routeData=routeDataInput ?? {
  pipe:[[50.1,26.6],[46.7,26.3],[43.2,25.2],[38.15,24.1]],
  north:[[38.15,24.1],[35.5,27],[33.9,28],[32.6,29.67],[31.75,30.05],[30.8,30.72],[29.77,31.13]],
  south:[[38.15,24.1],[38,22],[39.8,19.4],[41.8,16.8],[43.15,12.65],[44.7,12.2],[47.5,12.15],[51.5,13.2]],
  front:[[50.1,26.6],[52.4,26.5],[54.8,26.1],[56.4,26.6],[57.6,25.1],[59,24.1]],
  cape:[[29.77,31.13],[25,34],[15,36],[5,37],[-5.35,36.14],[-12,32],[-20,18],[-12,0],[0,-20],[12,-34],[20,-37],[40,-35],[52,-20],[65,-5],[80,10]]
 };
 const routePaths=Object.entries(routeData).map(([id,pts])=>`<path id="world-route-${id}" class="world-route world-route-${id}" marker-mid="url(#world-arrow-${id})" marker-end="url(#world-arrow-${id})" d="M${pts.map(xy).map(q=>q.join(',')).join('L')}"/>`).join('');
 const markers=Object.keys(routeData).map(id=>`<marker id="world-arrow-${id}" class="world-arrow" viewBox="0 0 4 4" refX="3.5" refY="2" markerWidth="3.5" markerHeight="3.5" orient="auto" markerUnits="strokeWidth"><path id="world-arrow-fill-${id}" d="M0 0L4 2L0 4L1 2Z" fill="${palette.ink}"/></marker>`).join('');
 const cities=[['medina','MEDINA',39.61,24.47],['jeddah','JEDDAH',39.17,21.49],['portsudan','PORT SUDAN',37.22,19.62],['yanbu','YANBU',38.06,24.08],['abudhabi','ABU DHABI',54.37,24.45],['dubai','DUBAI',55.30,25.27],['hormuz','STRAIT OF HORMUZ',56.10,26.35],['iran','IRAN',53.3,27.7],['sanaa','SANAA',44.2,15.35],['cairo','CAIRO',31.24,30.04],['ain-sukhna','AIN SUKHNA',32.58,29.67],['sidikerir','SIDI KERIR',29.77,31.13],['suez','SUEZ',32.55,29.97],['baghdad','BAGHDAD',44.37,33.32],['amarah','AL AMARAH',47.16,31.84],['basra','BASRA',47.78,30.51]];
 const cityHTML=cities.map(([id,label,lon,lat])=>{const[x,y]=xy([lon,lat]);return`<text id="world-city-${id}" class="world-city" x="${x}" y="${y-(id==='hormuz'?32:0)}" text-anchor="${id==='hormuz'?'end':'start'}" font-size="${editorial.type.mapLabel}">${label}</text>`}).join('');
 const vb=p=>{const[cx,cy]=xy([p.lon,p.lat]);const k=p.scale/50;return[cx-540/k,cy-800/k,1080/k,1920/k].join(' ')};
 const labels=[['yanbu'],['yanbu'],['hormuz'],['yanbu'],['yanbu'],['jeddah','portsudan'],['sanaa','portsudan'],['yanbu'],['ain-sukhna'],[],['hormuz'],['yanbu'],['amarah','basra'],[],[]];
 const countryLabels=[['Saudi Arabia',44.1,22.2],['Saudi Arabia',44.1,22.2],['Iran',53.3,27.4],['Saudi Arabia',44.1,22.2],['Red Sea',37.6,23],null,['Yemen',44,15.8],['Red Sea',39.2,20.5],['Egypt',30.9,28.8],['Africa',25,-5],['Iran',53.3,27.4],['Saudi Arabia',44.1,22.2],['Iraq',46.4,32.7],null,['Saudi Arabia',44.1,22.2]];
 const stages=poses.map((p,i)=>({time:p.time,travel:p.travel,box:vb(p),land:p.land,font:editorial.type.mapLabel/(p.scale/50),countryFont:editorial.type.geography/(p.scale/50),country:countryLabels[i]?{text:countryLabels[i][0],point:xy(countryLabels[i].slice(1))}:null,marker:3.5/(p.scale/50),labels:labels[i]||[]}));
 // Exclude routes only from the fixed screen-space brand area; retain real land/water beneath it.
 const brandHole=box=>{const[x,y,w]=box.split(' ').map(Number),k=w/1080;return{x:x+82*k,y:y+222*k,width:166*k,height:75*k}};
 for(const [i,stage] of stages.entries()){stage.brandHole=brandHole(stage.box);stage.scale=poses[i].scale;stage.marker=Math.min(stage.marker,3.5);}
 const hole=stages[0].brandHole;
 const routes=`<defs><mask id="world-brand-route-mask" maskUnits="userSpaceOnUse" x="-100000" y="-100000" width="200000" height="200000"><rect x="-100000" y="-100000" width="200000" height="200000" fill="white"/><rect id="world-brand-route-hole" x="${hole.x}" y="${hole.y}" width="${hole.width}" height="${hole.height}" fill="black"/></mask></defs><g mask="url(#world-brand-route-mask)">${routePaths}</g>`;
 const target=xy([43.1,25.18]);
 const country=xy([44.1,22.2]),pipeLabel=xy([43.15,27.6]);
 return `<!doctype html><html><head><meta charset="utf-8"></head><body><template>
 <style>@font-face{font-family:'IBM Plex Mono';src:url('../assets/IBMPlexMono-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:block}
 @font-face{font-family:Newsreader;src:url('../assets/Newsreader-Regular.woff2') format('woff2');font-weight:400;font-style:normal;font-display:block}
 #map-world-root{position:absolute;inset:0;overflow:hidden;background:${palette.paper}}
 .world-map{display:block;width:1080px;height:1920px}
 #world-land-group{opacity:1}.world-city,#world-route-front,#world-route-north,#world-route-south,#world-route-cape,#world-perim-highlight,#world-target{opacity:0}
 .world-country{font-family:Newsreader;font-weight:400;fill:${palette.ink};text-anchor:middle}
 .world-intro-label{font-family:'IBM Plex Mono';font-weight:400;fill:${palette.ink};text-anchor:middle}
 .world-land{fill:${palette.neutral};stroke:none}
 .world-edge{fill:none;stroke:${palette.ink};vector-effect:non-scaling-stroke;stroke-linejoin:round}
 #world-coastlines{stroke-width:${editorial.borders.coastWidth};stroke-opacity:${editorial.borders.lightCoastOpacity}}
 #world-country-borders{stroke-width:${editorial.borders.countryWidth};stroke-opacity:${editorial.borders.lightCountryOpacity}}
 .world-route{fill:none;stroke:${palette.ink};stroke-width:5;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}
 .world-route-cape{stroke-dasharray:14 10}
 .world-city{font-family:'IBM Plex Mono';font-weight:400;fill:${palette.ink};paint-order:stroke;stroke:${palette.neutral};stroke-width:0.25;vector-effect:non-scaling-stroke}
 .world-target{fill:none;stroke:${palette.accent};stroke-width:3;vector-effect:non-scaling-stroke}
 .world-route-index-label,#world-cape-label,#world-route-index{font-family:'IBM Plex Mono';font-weight:400;letter-spacing:.04em}
 #world-route-index{position:absolute;left:90px;top:320px;width:410px;padding-left:18px;border-left:3px solid ${palette.accent};color:${palette.ink};font-size:22px;line-height:1.65;opacity:0;z-index:4}
 #world-route-index b{color:${palette.accent};font-weight:400}
 #world-cape-label{position:absolute;left:120px;top:930px;color:${palette.ink};font-size:24px;opacity:0;z-index:4}
 </style><div id="map-world-root" data-composition-id="map-world" data-start="0" data-duration="${duration}" data-width="1080" data-height="1920">
 <svg class="world-map" id="world-map" viewBox="${stages[0].box}" role="img" aria-label="Reconstructed route map. Geographic and camera positions are approximate; routes schematic."><defs>${markers}</defs><g id="world-cropped-geography" data-layout-allow-overflow="true"><g id="world-land-group">${land}${edges}</g>${routes}<path id="world-perim-highlight" d="${perimPath}" fill="${palette.accent}" stroke="${palette.accent}" stroke-width="2" vector-effect="non-scaling-stroke"/><g id="world-city-group">${cityHTML}</g><text id="world-country-label" class="world-country" x="${country[0]}" y="${country[1]}" font-size="${stages[0].countryFont}">Saudi Arabia</text><g id="world-intro-label"><path d="M${target[0]},${target[1]}L${pipeLabel[0]},${pipeLabel[1]+18}" fill="none" stroke="${palette.ink}" stroke-width="1.5" vector-effect="non-scaling-stroke"/><text class="world-intro-label" x="${pipeLabel[0]}" y="${pipeLabel[1]}" font-size="${stages[0].font}">EAST–WEST PIPELINE</text></g><g id="world-yanbu-hub" opacity="0"><circle cx="${xy([38.15,24.1])[0]}" cy="${xy([38.15,24.1])[1]}" r="15" fill="none" stroke="${palette.accent}" stroke-width="3" vector-effect="non-scaling-stroke"/><text class="world-route-index-label" x="${xy([38.15,24.1])[0]+24}" y="${xy([38.15,24.1])[1]-22}" font-size="${editorial.type.metadata/(stages[0].scale/50)}">SHARED PIPE / YANBU</text></g><g id="world-pipe-stop" opacity="0"><circle cx="${target[0]}" cy="${target[1]}" r="18" fill="${palette.paper}" stroke="${palette.accent}" stroke-width="3" vector-effect="non-scaling-stroke"/><path d="M${target[0]-10},${target[1]-10}L${target[0]+10},${target[1]+10}M${target[0]+10},${target[1]-10}L${target[0]-10},${target[1]+10}" fill="none" stroke="${palette.accent}" stroke-width="3" vector-effect="non-scaling-stroke"/></g><circle id="world-target" class="world-target" cx="${target[0]}" cy="${target[1]}" r="12"/></g></svg></div><div id="world-route-index" aria-hidden="true"><div><b>01</b> SOUTH / BAB EL-MANDEB</div><div><b>02</b> NORTH / SUMED</div><div><b>03</b> FRONT / HORMUZ</div></div><div id="world-cape-label" aria-hidden="true">CAPE DETOUR</div>
 <script>(()=>{const tl=gsap.timeline({paused:true});const stages=${JSON.stringify(stages)};
 tl.set('#world-land-group',{opacity:stages[0].land},0);tl.set('.world-city',{opacity:0,attr:{'font-size':stages[0].font}},0);tl.set('.world-arrow',{attr:{markerWidth:stages[0].marker,markerHeight:stages[0].marker}},0);
 tl.set('#world-route-north,#world-route-south,#world-route-front',{opacity:0.18},0);tl.set('#world-route-north,#world-route-south,#world-route-front',{opacity:0},12.45);
 tl.to('#world-city-yanbu',{opacity:1,duration:0.3},0.4);
 for(const s of stages.slice(1)){
  tl.to('#world-map',{attr:{viewBox:s.box},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.to('#world-brand-route-hole',{attr:s.brandHole,duration:s.travel,ease:'power2.inOut'},s.time);
  tl.to('#world-land-group',{opacity:s.land,duration:Math.min(0.9,s.travel),ease:'none'},s.time);
  tl.to('.world-city',{attr:{'font-size':s.font},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.to('#world-yanbu-hub text',{attr:{'font-size':${editorial.type.metadata}/(s.scale/50)},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.to('.world-intro-label',{attr:{'font-size':s.font},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.to('.world-country',{attr:{'font-size':s.countryFont},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.set('#world-country-label',{opacity:0},s.time);
  if(s.country){tl.set('#world-country-label',{textContent:s.country.text,attr:{x:s.country.point[0],y:s.country.point[1]}},s.time);tl.to('#world-country-label',{opacity:1,duration:0.3},s.time+s.travel);}
  tl.to('.world-arrow',{attr:{markerWidth:s.marker,markerHeight:s.marker},duration:s.travel,ease:'power2.inOut'},s.time);
  tl.set('.world-city',{opacity:0},s.time);if(s.labels.length)tl.to(s.labels.map(x=>'#world-city-'+x).join(','),{opacity:1,duration:0.3},s.time+s.travel);
 }
 tl.set('#world-route-cape',{opacity:0},0);
 const draw=(id,t,d)=>{const p=document.querySelector('#world-route-'+id);const len=p.getTotalLength();tl.set(p,{opacity:1},t);tl.fromTo(p,{strokeDasharray:len,strokeDashoffset:len},{strokeDasharray:len,strokeDashoffset:0,duration:d,ease:'none'},t)};
 draw('front',13.3,1.1);draw('south',33.2,1.2);draw('north',37.2,1.2);draw('cape',73,2.4);tl.set('#world-route-cape',{strokeDasharray:'14 10'},75.4);
 const focus=(id,t)=>{for(const n of ['pipe','front','north','south','cape']){tl.to('#world-route-'+n,{stroke:n===id?'${palette.accent}':'${palette.ink}',duration:0.25},t);tl.to('#world-arrow-fill-'+n,{fill:n===id?'${palette.accent}':'${palette.ink}',duration:0.25},t)}};
 for(const [id,t] of [['pipe',0],['front',12.8],['pipe',22.4],['south',33.2],['north',37.2],['south',45.2],['north',66.4],['cape',73],['front',87],['pipe',102.2],['south',122],['south',135.2],['north',140.2],['front',145.6]])focus(id,t);
 tl.set('#world-route-cape',{opacity:0},87);
 // Wide atlas: one directional endpoint on the active detour, never a marker cluster.
 tl.set('.world-route',{attr:{'marker-mid':'none','marker-end':'none'}},73);
 tl.set('#world-route-cape',{attr:{'marker-end':'url(#world-arrow-cape)'}},75.4);
 for(const id of ['pipe','north','south','front'])tl.set('#world-route-'+id,{attr:{'marker-mid':'url(#world-arrow-'+id+')','marker-end':'url(#world-arrow-'+id+')'}},87);
 tl.to('#world-route-index',{opacity:1,duration:0.2},0);tl.to('#world-route-index',{opacity:0,duration:0.35},12.45);
 tl.to('#world-yanbu-hub',{opacity:1,duration:0.25},22.4);tl.set('#world-yanbu-hub',{opacity:0},45.2);tl.to('#world-yanbu-hub',{opacity:1,duration:0.25},133.2);
 tl.to('#world-pipe-stop',{opacity:1,duration:0.2},108.4);tl.set('#world-pipe-stop',{opacity:0},111.6);
 tl.to('#world-cape-label',{opacity:1,duration:0.25},73);tl.set('#world-cape-label',{opacity:0},87);
 tl.set('#world-target',{opacity:0},12.8);tl.set('#world-target',{opacity:1},102.2);tl.set('#world-target',{opacity:0},111.6);
 tl.set('#world-intro-label,#world-country-label',{opacity:0},12.8);
 tl.set('#world-country-label',{opacity:0},25);
 tl.set('#world-country-label',{opacity:0},60.4);
 tl.set('#world-country-label',{opacity:0},162.8);
 // Editorial turning point: a hard field change, not a blackout or a new scene.
 tl.set('#map-world-root',{backgroundColor:'${palette.ink}'},102.2);
 tl.set('.world-land',{fillOpacity:0.22},102.2);
 tl.set('.world-edge',{stroke:'${palette.paper}'},102.2);tl.set('#world-coastlines',{strokeOpacity:${editorial.borders.darkCoastOpacity}},102.2);tl.set('#world-country-borders',{strokeOpacity:${editorial.borders.darkCountryOpacity}},102.2);
 tl.set('.world-route',{stroke:'${palette.paper}'},102.2);tl.set('#world-route-pipe',{stroke:'${palette.accent}'},102.2);
 tl.set('.world-arrow path',{fill:'${palette.paper}'},102.2);tl.set('#world-arrow-fill-pipe',{fill:'${palette.accent}'},102.2);
 tl.set('.world-city',{fill:'${palette.paper}',stroke:'${palette.ink}'},102.2);
 tl.set('#world-country-label',{fill:'${palette.paper}'},102.2);
 tl.set('#map-world-root',{backgroundColor:'${palette.paper}'},111.6);
 tl.set('.world-land',{fillOpacity:1},111.6);
 tl.set('.world-edge',{stroke:'${palette.ink}'},111.6);tl.set('#world-coastlines',{strokeOpacity:${editorial.borders.lightCoastOpacity}},111.6);tl.set('#world-country-borders',{strokeOpacity:${editorial.borders.lightCountryOpacity}},111.6);
 tl.set('.world-route',{stroke:'${palette.ink}'},111.6);tl.set('#world-route-pipe',{stroke:'${palette.accent}'},111.6);
 tl.set('.world-arrow path',{fill:'${palette.ink}'},111.6);tl.set('#world-arrow-fill-pipe',{fill:'${palette.accent}'},111.6);
 tl.set('.world-city',{fill:'${palette.ink}',stroke:'${palette.neutral}'},111.6);tl.set('#world-country-label',{opacity:0,fill:'${palette.ink}'},111.6);
 tl.to('#world-perim-highlight',{opacity:1,duration:0.4,ease:'none'},123.2);tl.set('#world-perim-highlight',{opacity:0},133.2);
 tl.to('#map-world-root',{opacity:0,duration:1.4,ease:'none'},169.6);
 window.__timelines['map-world']=tl;})();</script></template></body></html>`
 .replace('</svg></div><div id="world-route-index"','</svg><div id="world-route-index"')
 .replace('</div>\n <script>','</div></div>\n <script>');
}

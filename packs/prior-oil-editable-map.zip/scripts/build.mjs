import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildMap } from './build-map.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = (relative) => JSON.parse(fs.readFileSync(path.join(root, relative), 'utf8'));
const topology = readJson('assets/countries-10m.json');
const camera = readJson('data/camera.json');
const editorial = readJson('data/editorial-system.json');
const routeSpec = readJson('data/routes.json');
const palette = { paper: '#FFFFFF', ink: '#000000', neutral: '#E8EBEA', accent: '#D03326' };
const duration = 169.6;
const html = buildMap(topology, camera.poses, duration, palette, editorial, routeSpec.routes)
  .replaceAll("url('../assets/", "url('assets/")
  .replaceAll("src='../assets/", "src='assets/");
fs.writeFileSync(path.join(root, 'compositions/map-world.html'), html);

const index = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=1080,height=1920"><title>Prior — OIL editable map</title><script src="assets/gsap.min.js"></script><style>*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1920px;overflow:hidden;background:${palette.paper}}#root{position:relative;width:100%;height:100%;overflow:hidden;background:${palette.paper}}#map-slot{position:absolute;inset:0}.brand{position:absolute;left:90px;top:230px;width:190px;height:74px;z-index:20}.brand img{display:block;width:190px;height:74px}</style></head><body><div id="root" data-composition-id="prior-oil-editable-map" data-start="0" data-duration="${duration}" data-width="1080" data-height="1920" data-fps="30"><div id="map-slot" class="clip" data-composition-id="map-world" data-composition-src="compositions/map-world.html" data-start="0" data-duration="${duration}" data-track-index="0" data-width="1080" data-height="1920"></div><div class="brand"><img src="assets/prior.png" width="190" height="74" alt="PRIOR"></div></div><script>(()=>{window.__timelines['prior-oil-editable-map']=gsap.timeline({paused:true});})();</script></body></html>`;
fs.writeFileSync(path.join(root, 'index.html'), index);
console.log(`Built editable map resource: ${duration}s, ${Object.keys(routeSpec.routes).length} schematic routes.`);

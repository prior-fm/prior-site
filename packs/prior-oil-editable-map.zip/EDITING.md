# OIL editable map — editing guide

1. Run `npm run build` from this folder.
2. Edit camera timing, position and scale in `data/camera.json`.
3. Edit the four schematic route geometries in `data/routes.json` as `[longitude, latitude]` pairs. Keep the north route's Ain Sokhna → Sidi Kerir segment as the SUMED land-transfer leg unless the visual brief changes.
4. Edit typography, borders and map scale tokens in `data/editorial-system.json`.
5. Open the rebuilt `index.html` in HyperFrames Studio and inspect the moving map before delivery.

Do not add narration, music, API credentials, source-film media, or political claims to this resource. Recheck time-sensitive sources before publishing a new film.

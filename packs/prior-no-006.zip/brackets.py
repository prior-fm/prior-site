"""The stack, and the counter it replaces.

No. 006's whole claim lives in the difference between `counter_balanced` and
`stack_balanced`. They are deliberately written to look alike so the difference
is the data structure and nothing else.

Stdlib only. Python 3.9+.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

# One place the pairing is written down. Everything else reads it, so there is
# no second table to fall out of sync.
PAIRS: Dict[str, str] = {")": "(", "}": "{", "]": "["}
OPENERS: str = "([{"
CLOSERS: str = ")]}"


def counter_balanced(s: str) -> bool:
    """Count opens, count closes, require they meet at zero and never go under.

    This is the version almost everyone writes first, and for a single bracket
    type it is correct. With three types it is not — it has no memory of WHICH
    bracket is still open, so `([)]` is indistinguishable from `([])`.

    Kept here to be disagreed with. `run.py` act 1 measures how often.
    """
    depth = 0
    for ch in s:
        if ch in OPENERS:
            depth += 1
        elif ch in CLOSERS:
            depth -= 1
            if depth < 0:          # a close with nothing open
                return False
    return depth == 0


def stack_balanced(s: str) -> bool:
    """The same scan, with a stack instead of a number.

    The stack is the memory the counter does not have: it holds the OPENERS
    that are still unmatched, innermost last. A closer is legal only against
    the innermost opener, which is the top of the stack — that is the entire
    algorithm, and it is why nesting works.

    One pass, O(n) time. Worst-case O(n) space, when the string is all openers.
    """
    stack: List[str] = []
    for ch in s:
        if ch in OPENERS:
            stack.append(ch)
        elif ch in CLOSERS:
            if not stack or stack[-1] != PAIRS[ch]:
                return False       # wrong partner, or no partner at all
            stack.pop()
    return not stack               # anything left open means unbalanced


def trace(s: str) -> List[Tuple[int, str, str, str]]:
    """Replay the scan step by step. This is what the film draws.

    Returns one row per character: (index, character, action, stack after).
    Stops at the first violation and reports it, because the algorithm stops
    there too — it does not keep scanning to be thorough.
    """
    stack: List[str] = []
    rows: List[Tuple[int, str, str, str]] = []
    for i, ch in enumerate(s):
        if ch in OPENERS:
            stack.append(ch)
            rows.append((i, ch, "push", "".join(stack)))
        elif ch in CLOSERS:
            if not stack:
                rows.append((i, ch, "REJECT nothing open", "".join(stack)))
                return rows
            if stack[-1] != PAIRS[ch]:
                rows.append((i, ch, f"REJECT expected {stack[-1]}", "".join(stack)))
                return rows
            stack.pop()
            rows.append((i, ch, "pop", "".join(stack)))
        else:
            rows.append((i, ch, "skip", "".join(stack)))
    rows.append((len(s), "", "accept" if not stack else "REJECT still open",
                 "".join(stack)))
    return rows


def first_violation(s: str) -> Optional[Tuple[int, str]]:
    """Where it breaks, and why — or None if the string is balanced.

    `stack_balanced` answers yes/no. Anything that has to REPORT on input
    wants the position, and getting it out of a bool afterwards means
    scanning twice.
    """
    stack: List[Tuple[int, str]] = []
    for i, ch in enumerate(s):
        if ch in OPENERS:
            stack.append((i, ch))
        elif ch in CLOSERS:
            if not stack:
                return i, f"{ch!r} closes nothing"
            j, opener = stack[-1]
            if opener != PAIRS[ch]:
                return i, f"{ch!r} does not close {opener!r} opened at {j}"
            stack.pop()
    if stack:
        j, opener = stack[-1]
        return j, f"{opener!r} is never closed"
    return None

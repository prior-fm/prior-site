"""The same stack, on a problem you actually have: streaming JSON.

A model streams its answer a token at a time. You want to know, at every
token, whether what has arrived so far is a COMPLETE JSON value — so you can
parse it and act — without calling `json.loads` on every prefix and catching
the exception, and without waiting for the whole response.

That is the bracket problem with two complications the film does not have:

  1. Brackets inside strings are not brackets. `{"a": "}"}` is valid JSON and
     a naive stack rejects it at character 8. This is the bug, and it is the
     reason a JSON scanner needs a string flag as well as a stack.
  2. A backslash escapes the next character, so `"\\""` ends the string and
     `"\""` does not.

Everything else is `brackets.py` with a bigger alphabet.

Stdlib only. Python 3.9+.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import List, Optional

CLOSE_FOR = {"{": "}", "[": "]"}


@dataclass
class JsonScanner:
    """An incremental JSON structure scanner. Feed it bytes as they arrive.

    It is a state machine, not a parser: it never builds a value and never
    validates numbers or keys. It answers exactly two questions, in O(1) per
    character with no re-scanning of the prefix:

        complete   is what has arrived so far a whole JSON value?
        suffix     what is the shortest string that would close it?

    `depth`/`in_string` are the state; `stack` is the memory.
    """

    stack: List[str] = field(default_factory=list)
    in_string: bool = False
    escaped: bool = False
    started: bool = False
    broken: Optional[str] = None
    consumed: int = 0

    def feed(self, chunk: str) -> "JsonScanner":
        """Push a chunk through. Chunk boundaries do not matter — state carries."""
        for ch in chunk:
            self.consumed += 1
            if self.broken is not None:
                continue

            if self.in_string:
                # Inside a string NOTHING is structural. This branch is the
                # whole difference between a JSON scanner and a bracket
                # counter, and it is where the naive version fails.
                if self.escaped:
                    self.escaped = False
                elif ch == "\\":
                    self.escaped = True
                elif ch == '"':
                    self.in_string = False
                continue

            if ch == '"':
                self.in_string = True
                self.started = True
            elif ch in CLOSE_FOR:
                self.stack.append(ch)
                self.started = True
            elif ch in "}]":
                if not self.stack:
                    self.broken = f"{ch!r} at {self.consumed - 1} closes nothing"
                elif CLOSE_FOR[self.stack[-1]] != ch:
                    want = CLOSE_FOR[self.stack[-1]]
                    self.broken = (f"{ch!r} at {self.consumed - 1} closes "
                                   f"{self.stack[-1]!r}, expected {want!r}")
                else:
                    self.stack.pop()
            elif not ch.isspace():
                self.started = True          # a bare number, true, false, null
        return self

    @property
    def complete(self) -> bool:
        """True when a whole JSON value has arrived and nothing is left open."""
        return (self.broken is None and self.started
                and not self.stack and not self.in_string)

    @property
    def suffix(self) -> str:
        """The shortest tail that would make the prefix parse.

        Close the string if one is open, then close every frame on the stack
        from the top down. That is the stack read backwards, which is the
        second thing a stack gives you that a counter cannot.

        This REPAIRS structure only. `{"a": 1, "b":` closes to `{"a": 1, "b":}`,
        which is still not valid JSON — a dangling key needs a value, not a
        brace. `truncate_to_valid` is the honest version.
        """
        if self.broken is not None:
            return ""
        tail = '"' if self.in_string else ""
        return tail + "".join(CLOSE_FOR[c] for c in reversed(self.stack))


def first_complete_prefix(text: str) -> Optional[int]:
    """Index just past the first point at which `text` holds a whole JSON value.

    One pass over the string. The naive alternative — `json.loads(text[:i])`
    inside a try/except for every i — is O(n^2) and is what this exists to
    replace. `run.py` act 3 times both.
    """
    sc = JsonScanner()
    for i, ch in enumerate(text):
        sc.feed(ch)
        if sc.complete:
            return i + 1
    return None


def truncate_to_valid(text: str) -> Optional[str]:
    """The largest prefix of a partial stream that is real, parseable JSON.

    Walks forward, and at every structural point asks whether closing HERE
    would parse. The last point that did is the answer. Used to show a partial
    object to a user mid-stream without ever handing them something
    `json.loads` will reject.

    It refuses to close immediately after an opener or a comma, even though
    both would parse. `{"steps": [{"a": 1}, {` closes to `{"steps": [{"a": 1},
    {}]}` — legal JSON containing an element the model never sent. Truncating
    is honest; inventing an empty object is not. So a candidate is rejected
    when the last non-space character before the suffix is `{`, `[`, `,` or
    `:`.

    Returns None when nothing can be salvaged without inventing.
    """
    sc = JsonScanner()
    best: Optional[str] = None
    for i, ch in enumerate(text):
        sc.feed(ch)
        if sc.broken is not None:
            break
        if sc.in_string or not sc.started:
            continue
        if not sc.stack:
            best = text[: i + 1]           # a whole value, nothing to close
            continue
        if text[: i + 1].rstrip()[-1:] in "{[,:":
            continue                       # closing here would invent a member
        candidate = text[: i + 1] + sc.suffix
        try:
            json.loads(candidate)
        except ValueError:
            continue
        best = candidate
    return best

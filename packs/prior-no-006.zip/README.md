# Prior — No. 006 — Valid parentheses, and the stack underneath it

The runnable version of the film, and the part the film does not have room
for: the same eight lines of stack code doing real work on a model's streaming
output.

**Python 3.9+. No dependencies, no network, no arguments.**

```
python run.py
```

That is the whole setup. It takes about two seconds.

---

## What you are looking for

The film claims one thing, and this is here so you can check it rather than
take it:

> A counter tells you **how many** brackets are open. A stack tells you
> **which ones**. Everything else follows from that.

### Act 1 — how often a counter is actually wrong

Not sampled. Every string over `()[]{}` of the given length, all of them:

```
   length 2:       6 of      36 strings misjudged   (16.67%)
   length 4:     144 of    1296 strings misjudged   (11.11%)
   length 6:    3510 of   46656 strings misjudged   ( 7.52%)
   length 8:   90720 of 1679616 strings misjudged   ( 5.40%)

   Of all of those, false REJECTS: 0.
```

Read the last line twice. The counter never wrongly rejects — **every single
disagreement is a false accept.** It waves through `([)]` and `{[}]` and `(]`.
That is the direction of failure that reaches production, because nothing
downstream complains about input that was let in.

The percentage falls with length only because long random strings are
overwhelmingly invalid in ways both methods catch. The absolute count climbs:
90,720 misjudged strings at length 8.

### Act 2 — the scan, step by step

The same table the film animates, printed:

```
     i  char  action                 stack
   ---  ----- ---------------------- ------------
     0  (     push                   (
     1  [     push                   ([
     2  )     REJECT expected [      ([

   verdict: INVALID at 2 -- ')' does not close '[' opened at 1
```

At index 2 the counter is at 2, which is fine. The stack top is `[`, and `)`
does not close `[`. The stack has the one fact the counter threw away.

### Act 3 — the same stack, on a model's streaming output

This is why the technique is worth twenty minutes rather than an interview.

A model streams JSON a token at a time. You want to act the moment a complete
value has arrived. The usual approach is `json.loads()` on every prefix inside
a `try/except`:

```
   document:         17,925 characters
   loads-per-prefix:   1612.6 ms   -> complete at 17,901
   JsonScanner:           6.1 ms   -> complete at 17,901
   ratio:               264.9x
```

Same answer. `loads`-per-prefix is O(n²) because every prefix re-reads the
whole prefix; the scanner is O(n) because a stack remembers where it was.

Your numbers will differ. The exponent will not.

It also does the thing you actually want mid-stream — hand the user the
largest piece of the answer that is real JSON, with no half-object in it:

```
   partial stream:   {"steps": [{"name": "fetch", "ms": 12}, {"name": "ran
   still open:       {[{  (inside a string)
   closing suffix:   '"}]}'
   largest valid:    {"steps": [{"name": "fetch", "ms": 12}]}
```

The closing suffix is **the stack read backwards**. That is the second thing a
stack gives you that a counter cannot: not just *whether* it is unbalanced, but
exactly what would balance it.

---

## The files

| | |
|---|---|
| `run.py` | The three acts. Start here. |
| `brackets.py` | `counter_balanced` and `stack_balanced`, written to look alike so the difference is the data structure and nothing else. Plus `trace()`, which is what the film draws. |
| `streaming.py` | The incremental JSON scanner. ~90 lines of logic. |

Each module imports cleanly on its own:

```python
from brackets import stack_balanced, trace, first_violation
from streaming import JsonScanner, first_complete_prefix, truncate_to_valid

stack_balanced("{[()]}")            # True
first_violation("([)]")             # (2, "')' does not close '[' opened at 1")

sc = JsonScanner().feed('{"a": [1,')
sc.complete                         # False
sc.suffix                           # ']}'
```

---

## Three things this pack gets right that are easy to get wrong

**1. Brackets inside strings are not brackets.**

```
   input:            {"note": "a } inside a string", "ok": [1, 2]}
   json.loads:       valid
   bracket stack:    INVALID   <- wrong
   JsonScanner:      valid
```

A bare bracket stack rejects legal JSON at character 8. A JSON scanner needs a
string flag as well as a stack, and a backslash flag as well as that — `"\\"`
ends the string and `"\""` does not. This is the single most common bug in
hand-rolled streaming JSON handling, and it only shows up on the inputs that
contain user text, which is most of them.

**2. Reporting wants a position, not a boolean.** `stack_balanced` answers
yes/no, which is what the interview asks for. Anything that has to tell a human
what went wrong wants the index and the reason, and recovering that from a
`False` afterwards means scanning twice. `first_violation` returns both from
the same pass.

**3. Repairing a partial stream must not invent data.** `{"steps": [{"a": 1},
{` closes structurally to `{"steps": [{"a": 1}, {}]}` — legal JSON containing
an element the model never sent. `truncate_to_valid` refuses to close
immediately after `{`, `[`, `,` or `:` for exactly this reason. Truncating is
honest; inventing an empty object is not, and it is worse than useless because
it parses.

---

## And one the film simplifies

The film scans a string of nothing but brackets, because that is what fits on a
frame. Real input is mostly not brackets, and `stack_balanced` skips every
other character silently. That is the right behaviour for the classic problem
and the wrong behaviour for a validator — if you are checking a source file, a
character you do not recognise is usually the thing you most want to hear
about. Decide which one you are writing before you copy the loop.

---

Prior · one idea per issue, and the source with every one
https://prior-fm.github.io/prior-site/

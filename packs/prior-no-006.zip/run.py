"""Prior -- No. 006 -- three acts against the film's claim.

    python run.py

No dependencies, no network, no arguments. About two seconds.

The film says a stack is what turns "is this balanced?" from guesswork into
one linear pass. These three acts are here so you can check that rather than
take it:

    Act 1   how often a counter is wrong, measured exhaustively
    Act 2   the scan, step by step -- the same table the film animates
    Act 3   the same stack on streaming JSON, timed against the usual hack

Everything below is reproducible. There is no randomness anywhere in this
pack: act 1 is exhaustive over every string of its length, act 2 is fixed
input, and act 3's only varying number is a wall-clock timing.
"""

from __future__ import annotations

import itertools
import json
import time
from typing import List

from brackets import counter_balanced, first_violation, stack_balanced, trace
from streaming import JsonScanner, first_complete_prefix, truncate_to_valid

RULE = "-" * 66


def head(n: int, title: str) -> None:
    print(f"\n{RULE}\nACT {n}  {title}\n{RULE}")


# --------------------------------------------------------------------------
# Act 1 -- the counter is wrong, and here is how often
# --------------------------------------------------------------------------
def act_one() -> None:
    head(1, "A counter cannot do this job")

    print("""
A counter tracks HOW MANY brackets are open. A stack tracks WHICH ONES.
For one bracket type that distinction does not exist and the counter is
correct. For three types it is the whole problem.
""".strip())
    print()

    alphabet = "()[]{}"
    false_reject = 0
    for n in (2, 4, 6, 8):
        total = wrong = 0
        for tup in itertools.product(alphabet, repeat=n):
            s = "".join(tup)
            total += 1
            c, k = counter_balanced(s), stack_balanced(s)
            if c != k:
                wrong += 1
                if k and not c:            # said INVALID about a valid string
                    false_reject += 1
        pct = 100.0 * wrong / total
        print(f"  length {n}:  {wrong:6d} of {total:7d} strings misjudged"
              f"   ({pct:5.2f}%)")

    print()
    print(f"  Of all of those, false REJECTS: {false_reject}. Measured, not assumed.")
    print("  Every single disagreement is a false ACCEPT -- the counter waving")
    print("  through a string the stack catches. That is the failure direction")
    print("  that reaches production, because nothing downstream complains.")
    print()

    for s in ("([)]", "{[}]", "([{}])", "(]"):
        c = "pass" if counter_balanced(s) else "FAIL"
        k = "pass" if stack_balanced(s) else "FAIL"
        flag = "   <- disagree" if c != k else ""
        print(f"    {s:<8}  counter {c}   stack {k}{flag}")


# --------------------------------------------------------------------------
# Act 2 -- the scan, step by step
# --------------------------------------------------------------------------
def act_two() -> None:
    head(2, "The scan, one character at a time")

    for s in ("{[()]}", "([)]"):
        print(f"\n  input: {s}\n")
        print(f"    {'i':>3}  {'char':<5} {'action':<22} stack")
        print(f"    {'-'*3}  {'-'*5} {'-'*22} {'-'*12}")
        for i, ch, action, stack in trace(s):
            shown = ch if ch else "-"
            print(f"    {i:>3}  {shown:<5} {action:<22} {stack or '(empty)'}")
        v = first_violation(s)
        print(f"\n    verdict: {'VALID' if v is None else f'INVALID at {v[0]} -- {v[1]}'}")

    print()
    print("  Note what happens at index 2 of `([)]`. The counter is at 2, which")
    print("  is fine. The stack top is `[`, and `)` does not close `[`. The")
    print("  stack has the one fact the counter threw away.")


# --------------------------------------------------------------------------
# Act 3 -- the same stack, on streaming JSON
# --------------------------------------------------------------------------
def act_three() -> None:
    head(3, "The same stack, on a model's streaming output")

    print("""
A model streams JSON a token at a time and you want to act the moment a whole
value has arrived. The usual hack is json.loads() on every prefix inside a
try/except. It works, and it re-parses the entire prefix every time.
""".strip())
    print()

    # 1. the string trap
    tricky = '{"note": "a } inside a string", "ok": [1, 2]}'
    naive_stack: List[str] = []
    naive_ok = True
    for ch in tricky:
        if ch in "{[":
            naive_stack.append(ch)
        elif ch in "}]":
            if not naive_stack:
                naive_ok = False
                break
            naive_stack.pop()
    naive_ok = naive_ok and not naive_stack
    scanner_ok = JsonScanner().feed(tricky).complete
    real_ok = True
    try:
        json.loads(tricky)
    except ValueError:
        real_ok = False

    print(f"  input:            {tricky}")
    print(f"  json.loads:       {'valid' if real_ok else 'INVALID'}")
    print(f"  bracket stack:    {'valid' if naive_ok else 'INVALID'}"
          f"{'   <- wrong' if naive_ok != real_ok else ''}")
    print(f"  JsonScanner:      {'valid' if scanner_ok else 'INVALID'}"
          f"{'   <- wrong' if scanner_ok != real_ok else ''}")
    print()
    print("  Brackets inside strings are not brackets. That is the one rule the")
    print("  film's version does not need and yours does.")

    # 2. mid-stream repair
    print()
    partial = '{"steps": [{"name": "fetch", "ms": 12}, {"name": "ran'
    sc = JsonScanner().feed(partial)
    print(f"  partial stream:   {partial}")
    print(f"  still open:       {''.join(sc.stack)}"
          f"{'  (inside a string)' if sc.in_string else ''}")
    print(f"  closing suffix:   {sc.suffix!r}")
    salvaged = truncate_to_valid(partial)
    print(f"  largest valid:    {salvaged}")
    print()
    print("  The suffix is the stack read backwards. `truncate_to_valid` is the")
    print("  honest one: it hands back only what json.loads actually accepts.")

    # 3. the timing
    print()
    doc = json.dumps({"items": [{"id": i, "tags": ["a", "b"], "ok": True}
                                for i in range(400)]})
    stream = doc + '\n{"trailing": "ignored"}'

    t0 = time.perf_counter()
    naive_at = None
    for i in range(1, len(stream) + 1):
        try:
            json.loads(stream[:i])
        except ValueError:
            continue
        naive_at = i
        break
    t_naive = time.perf_counter() - t0

    t0 = time.perf_counter()
    scan_at = first_complete_prefix(stream)
    t_scan = time.perf_counter() - t0

    print(f"  document:         {len(stream):,} characters")
    print(f"  loads-per-prefix: {t_naive * 1000:8.1f} ms   -> complete at {naive_at:,}")
    print(f"  JsonScanner:      {t_scan * 1000:8.1f} ms   -> complete at {scan_at:,}")
    if t_scan > 0:
        print(f"  ratio:            {t_naive / t_scan:8.1f}x")
    print()
    print("  Same answer. One is O(n^2) because every prefix re-reads the whole")
    print("  prefix; the other is O(n) because a stack remembers.")
    print()
    print("  Your numbers will differ. The exponent will not.")


def main() -> None:
    print()
    print("Prior -- No. 006 -- Valid parentheses, and the stack underneath it")
    print("https://prior-fm.github.io/prior-site/")
    act_one()
    act_two()
    act_three()
    print()
    print(RULE)
    print("Prior - one idea per issue, and the source with every one")
    print(RULE)
    print()


if __name__ == "__main__":
    main()

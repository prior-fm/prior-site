"""Prior No. 008 -- Tower of Hanoi: run the film's claims.

    python run.py

Python 3.9+. No dependencies, no network, no arguments.
"""

from __future__ import annotations

import time

from hanoi import bfs_optimal, moves_required, solve, solve_iterative


def act_1() -> None:
    print("ACT 1 -- the film's 31 moves, from the film's five lines")
    print("-" * 60)
    moves = solve(5, "A", "C", "B")
    for k, (disk, src, dst) in enumerate(moves, 1):
        print(f"   move {k:>2}   disk {disk}   {src} -> {dst}")
    print(f"\n   total: {len(moves)} moves  (2**5 - 1 = {moves_required(5)})")
    assert len(moves) == moves_required(5)


def act_2() -> None:
    print("\nACT 2 -- is 31 actually the minimum? Measure, don't recite.")
    print("-" * 60)
    print("   Breadth-first search over every legal position (3**n states),")
    print("   no recursion, no formula -- the true shortest path:\n")
    print("   disks   states   2**n - 1   BFS shortest   agree")
    for n in range(1, 8):
        formula = moves_required(n)
        measured = bfs_optimal(n)
        print(f"   {n:>5}   {3**n:>6}   {formula:>8}   {measured:>12}   "
              f"{'yes' if formula == measured else 'NO -- INVESTIGATE'}")
    print("\n   The recursion is not just correct, it is unbeatable: no")
    print("   sequence of legal moves whatsoever is shorter.")


def act_3() -> None:
    print("\nACT 3 -- each new disk doubles the work")
    print("-" * 60)
    print("   To move n disks you must move n-1 disks TWICE (off the big")
    print("   disk, then back on top of it) plus one move. So:")
    print("   moves(n) = 2 * moves(n-1) + 1 = 2**n - 1.\n")
    per_move = 1.0  # one move per second
    for n in (5, 10, 20, 30, 40, 64):
        total = moves_required(n)
        seconds = total * per_move
        years = seconds / (365.25 * 24 * 3600)
        scale = (f"{seconds:,.0f} s" if seconds < 3600
                 else f"{seconds / 86400:,.1f} days" if years < 1
                 else f"{years:,.1f} years" if years < 1e6
                 else f"{years:.2e} years")
        print(f"   {n:>3} disks   {total:>26,} moves   {scale:>16} at 1/s")
    print("\n   The 64-disk legend outlives the sun. That is what an")
    print("   exponent does -- and why 'just add one more' is never free.")


def act_4() -> None:
    print("\nACT 4 -- the recursion, with the call stack made visible")
    print("-" * 60)
    a = solve(5, "A", "C", "B")
    b = solve_iterative(5, "A", "C", "B")
    print(f"   recursive move list == explicit-stack move list: {a == b}")
    assert a == b
    t0 = time.perf_counter()
    solve(20, "A", "C", "B")
    t1 = time.perf_counter()
    solve_iterative(20, "A", "C", "B")
    t2 = time.perf_counter()
    print(f"   20 disks ({moves_required(20):,} moves): "
          f"recursive {1000 * (t1 - t0):.0f} ms, "
          f"stack {1000 * (t2 - t1):.0f} ms")
    print("   Same moves, same order -- the stack IS the call stack. When a")
    print("   recursion goes deeper than ~1000 frames, this transform is")
    print("   how it keeps running. (Hanoi never does: depth equals disks.)")


if __name__ == "__main__":
    act_1()
    act_2()
    act_3()
    act_4()

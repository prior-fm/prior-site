# Prior — No. 008 — Tower of Hanoi, and what an exponent feels like

The runnable version of the film: the same five lines the clay bar walks
through, producing the same 31 moves the counter counts — plus the two things
a 20-second film cannot do: **prove** 31 is the minimum, and let you feel the
doubling.

**Python 3.9+. No dependencies, no network, no arguments.**

```
python run.py
```

That is the whole setup. It takes a few seconds.

---

## What you are looking for

The film shows one thing and implies two more. All three are checked here
rather than asserted:

> Five disks take **31 moves** — the recursion's count, `2**5 - 1`.
> No shorter solution exists. And each disk you add **doubles** the total.

### Act 1 — the film's moves, from the film's code

`solve(5, "A", "C", "B")` prints all 31 moves in order. Move 16 — the big
disk's single move, the one the film marks with a chime — lands exactly
halfway: 15 moves to clear the way, one move, 15 moves to rebuild on top.
That symmetry *is* the recursion.

### Act 2 — minimum, measured

`2**n - 1` is a formula you were told. Act 2 refuses to take it: a
breadth-first search walks **every legal position** (`3**n` states, no
recursion, no opinion about strategy) and reports the true shortest path
from all-on-A to all-on-C:

```
   disks   states   2**n - 1   BFS shortest   agree
       5      243         31             31   yes
       7     2187        127            127   yes
```

If the recursion ever wasted a move, these columns would disagree. They
never do — the elegant solution and the exhaustively-verified optimum are
the same object.

### Act 3 — the doubling

To move `n` disks you must move `n-1` disks twice — off the big disk, then
back on top of it — plus one. `moves(n) = 2·moves(n-1) + 1`. At one move
per second: 5 disks is half a minute, 30 disks is 34 years, and the 64-disk
legend runs `5.85e+11` years — the exponent outlives the sun. "Just add one
more" is never free.

### Act 4 — the recursion, with the call stack made visible

`solve_iterative()` is the same algorithm with a hand-rolled stack instead
of the call stack, and Act 4 checks the two move lists are **identical**
rather than telling you they are. The transform matters beyond the puzzle:
any recursion becomes a loop over a stack of pending calls, which is how a
traversal survives when the input goes deeper than Python's ~1000-frame
limit.

---

## The files

| | |
|---|---|
| `run.py` | The four acts. Start here. |
| `hanoi.py` | `solve` (the film's five lines), `solve_iterative`, `bfs_optimal`, `moves_required`. Each importable on its own. |

```python
from hanoi import solve, solve_iterative, bfs_optimal

solve(3, "A", "C", "B")        # [(1,'A','C'), (2,'A','B'), (1,'C','B'), ...]
bfs_optimal(3)                 # 7 — measured, not recited
```

---

## Two things this pack gets right that are easy to get wrong

**1. "Optimal" is a claim about *all* solutions, not about yours.** Showing
your solution takes `2**n - 1` moves proves an upper bound. Only searching
the whole state graph (or an induction over it) proves nobody can do
better. Act 2 is the search; it is 30 lines and runs in milliseconds up to
7 disks — cheap enough that there is no excuse for reciting.

**2. The emit-marker trick in `solve_iterative`.** A naive recursion-to-loop
rewrite loses the *middle* of the function (work that happens between the
two recursive calls). Encoding "do the move now" as a negative stack entry
keeps the recursion's exact event order without a state machine. The same
trick converts any tree recursion with in-order work.

---

## Who made this

Prior is made by the same person who writes **Vektor** — the how-I-actually-ship
side of the same work: the tools, the pipeline, and the things that go wrong on
the way to a finished thing.

**Prior shows you the idea. Vektor shows you the build.**

- Vektor — [vektor-fm.github.io/vektor-site](https://vektor-fm.github.io/vektor-site/) · [@vektor.fm](https://instagram.com/vektor.fm)
- Prior — [prior-fm.github.io/prior-site](https://prior-fm.github.io/prior-site/) · [@prior.fm](https://instagram.com/prior.fm)

Every issue ships its full source, free.

"""Tower of Hanoi -- the film's solver, plus the ways to check it.

Three implementations of the same thing, written so the differences are the
point:

  solve()           the five lines the film shows, verbatim
  solve_iterative() the same recursion with a hand-rolled stack -- the moves
                    come out byte-identical, which you can check
  bfs_optimal()     no recursion at all: breadth-first search over the whole
                    state space, so "31 is the minimum" is a measurement,
                    not a formula you were told

Stdlib only. No dependencies, no network.
"""

from __future__ import annotations

from collections import deque

Move = tuple[int, str, str]  # (disk, from_rod, to_rod)


# ---------------------------------------------------------------------------
# The film's code -- these five lines are what the clay bar walks through.
# ---------------------------------------------------------------------------

def solve(n, src, dst, via, out=None):
    """The recursion, exactly as the film shows it (plus collecting moves)."""
    if out is None:
        out = []
        _solve(n, src, dst, via, out)
        return out
    _solve(n, src, dst, via, out)
    return out


def _solve(n, src, dst, via, out):
    if n == 0: return
    _solve(n - 1, src, via, dst, out)
    out.append((n, src, dst))
    _solve(n - 1, via, dst, src, out)


# ---------------------------------------------------------------------------
# The same recursion without the recursion.
# ---------------------------------------------------------------------------

def solve_iterative(n: int, src: str, dst: str, via: str) -> list[Move]:
    """The explicit-stack version.

    Python's default recursion limit is 1000 frames; `solve()` needs one
    frame per disk, so it is nowhere near trouble here -- but the transform
    itself is the useful part: any recursion becomes a loop over a stack of
    pending calls, and the stack IS the call stack, made visible. The move
    list comes out byte-identical to `solve()`'s, and `run.py` checks that
    rather than asserting it.
    """
    out: list[Move] = []
    stack: list[tuple[int, str, str, str]] = [(n, src, dst, via)]
    while stack:
        n, src, dst, via = stack.pop()
        if n == 0:
            continue
        if n < 0:                            # emit marker: the move itself
            out.append((-n, src, dst))
            continue
        # Pushed in reverse so they pop in the recursion's order:
        # solve the n-1 tower onto via, move disk n, solve n-1 onto dst.
        stack.append((n - 1, via, dst, src))
        stack.append((-n, src, dst, via))
        stack.append((n - 1, src, via, dst))
    return out


# ---------------------------------------------------------------------------
# No formula, no recursion: measure the shortest solution.
# ---------------------------------------------------------------------------

def bfs_optimal(n: int) -> int:
    """Length of the SHORTEST possible solution for n disks, by search.

    A position assigns each disk to one of three rods: 3**n states. From
    each state the legal moves are: take the smallest disk on a rod, put it
    on a rod whose top disk is larger (or empty). Breadth-first search from
    all-on-A finds the true distance to all-on-C with no opinion about how
    the puzzle "should" be solved. If the recursion were ever wasteful,
    this number would come out smaller than 2**n - 1. It never does.
    """
    start = (0,) * n          # state[i] = rod of disk i+1 (disk 1 smallest)
    goal = (2,) * n
    dist = {start: 0}
    frontier = deque([start])
    while frontier:
        state = frontier.popleft()
        if state == goal:
            return dist[state]
        tops: dict[int, int] = {}  # rod -> smallest disk index on it
        for i in range(n - 1, -1, -1):
            tops[state[i]] = i     # smaller disks overwrite larger
        for rod, disk in tops.items():
            for target in range(3):
                if target == rod:
                    continue
                if target in tops and tops[target] < disk:
                    continue       # a smaller disk is already there
                nxt = list(state)
                nxt[disk] = target
                nxt_t = tuple(nxt)
                if nxt_t not in dist:
                    dist[nxt_t] = dist[state] + 1
                    frontier.append(nxt_t)
    raise AssertionError("goal unreachable -- impossible on a legal board")


def moves_required(n: int) -> int:
    """The closed form the doubling produces: 2**n - 1."""
    return 2 ** n - 1

"""Bake the approved continuous-flow test into a separate saved v10 scene.

Run with Blender loading film.blend first. Only water surge keys and water
microtexture are animated differently; lunar fields, land, camera and timing stay
as saved. Render the resulting scene through the shared PowerShell wrapper.
"""
from pathlib import Path
import hashlib
import json
import math
import bpy

HERE = Path(__file__).resolve().parent
source = Path(bpy.data.filepath)
if source.resolve() != (HERE / 'film.blend').resolve():
    raise RuntimeError('Load the released v9 film.blend before preparing the test.')
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
source_manifest = json.loads((HERE / 'renders/v9/film/render-manifest.json').read_text())
if source_hash != source_manifest['variant_scene_sha256']:
    raise RuntimeError('The v9 scene no longer matches its render manifest.')

sc = bpy.context.scene
earth = bpy.data.objects['Earth | exaggerated water, stable geological land']
shape = earth.data.shape_keys
basis = shape.key_blocks['Basis']
primary = [shape.key_blocks[n] for n in ('Ocean surge sine', 'Ocean surge cosine')]
secondary = [earth.shape_key_add(name=n) for n in ('Continuous secondary sine', 'Continuous secondary cosine')]
for key in secondary:
    key.slider_min = -1
for i, point in enumerate(basis.data):
    n = point.co.normalized()
    ds = primary[0].data[i].co - point.co
    dc = primary[1].data[i].co - point.co
    # Recover the exact ocean/land/polar envelope from the released shape pair.
    envelope = math.sqrt(ds.length_squared + dc.length_squared) * .28
    phase = 8*n.y + 4*n.z + 1.2*math.sin(5*n.x)
    for key, value in zip(secondary, (math.sin(phase), math.cos(phase))):
        key.data[i].co = point.co + n * envelope * value

sections = {s['id']:s for s in json.loads((HERE/'narration-timing.json').read_text())['sections']}
intro_end = sections['P1']['start']
coda_start = sections['P9']['end']
def smooth(a, b, t):
    x = max(0., min(1., (t-a)/(b-a)))
    return x*x*(3-2*x)

material = earth.data.materials[0]
water_noises = [n for n in material.node_tree.nodes
                if n.bl_idname == 'ShaderNodeTexNoise' and abs(n.inputs['Scale'].default_value-180)<.01]
if len(water_noises) != 1:
    raise RuntimeError('Cannot identify the released water microtexture unambiguously.')
water_noise = water_noises[0]
water_noise.noise_dimensions = '4D'

fps = sc.render.fps
# Write every integer output frame, including the end boundary, to remove any
# dependence on interpolation around the earlier remapped sampling grid.
floors = []
for frame in range(1, 80*fps+2):
    t = (frame-1)/fps
    floor = .40
    opening_swell = .60*smooth(0, 3.7, t)*(1-smooth(5.5, intro_end+.5, t))
    coda_swell = .60*smooth(coda_start, 70, t)
    strength = floor + opening_swell + coda_swell
    floors.append(strength)
    phase = t*2.1
    for key, value in zip(primary, (math.cos(phase), math.sin(phase))):
        key.value = value*strength
        key.keyframe_insert('value', frame=frame)
    phase2 = -t*1.37 + math.pi/3
    for key, value in zip(secondary, (math.cos(phase2), math.sin(phase2))):
        key.value = value*strength
        key.keyframe_insert('value', frame=frame)
    water_noise.inputs['W'].default_value = .18*t
    water_noise.inputs['W'].keyframe_insert('default_value', frame=frame)

sc.frame_start, sc.frame_end, sc.frame_step = 1, 2400, 1
sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = 540, 600, 100
sc.eevee.taa_render_samples = 8
sc.render.use_overwrite = False
sc.render.use_placeholder = False
sc.render.image_settings.compression = 20
out = HERE/'renders/v10/water-flow-a'
out.mkdir(parents=True, exist_ok=True)
sc.render.filepath = str(out/'frame_####')
sc['water_motion_revision'] = 'v10-flowing-a'
sc['water_motion_floor'] = .40
sc['water_primary_phase_rate'] = 2.1
sc['water_secondary_phase_rate'] = -1.37
sc['water_secondary_relative_height'] = .28
sc.frame_set(1)
destination = HERE/'water-flow-a-v10.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(destination))
report = {'date':'2026-09-07','preset':'A — flowing and sculptural',
          'source_scene_sha256':source_hash,
          'scene_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'fps':fps,'dimensions':[540,600],'samples':8,'duration':80,
          'preview_frames':[181,540],'preview_seconds':[6,18],
          'surge_multiplier_min':min(floors),'surge_multiplier_max':max(floors),
          'primary_phase_rate':2.1,'secondary_phase_rate':-1.37,
          'secondary_relative_height':.28,'microtexture_phase_rate':.18,
          'status':'prepared; rendered appearance pending review'}
(out/'render-manifest.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('CONTINUOUS_WATER_READY '+str(destination))

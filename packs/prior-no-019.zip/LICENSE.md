# License and asset boundary

The pack-authored files `README.md`, `SOURCES.md`, `render.py`, and the accompanying pack manifest are released under the MIT License:

Copyright (c) 2026 Prior

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files, to deal in the software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the software, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

The packed Blender scene contains the image bytes used by the scene. Natural Earth and NASA provenance and usage notes are recorded in `SOURCES.md`; those source terms remain applicable. The pack does not include Printvetica, GSAP, generated voice, ambience, or any final-film assembly assets, so their separate licensing is outside this pack.

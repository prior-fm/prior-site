"""Render one frame from the packed Astra Tides Blender scene.

Run inside Blender, for example:
  blender --background water-flow-a-v10.blend --python render.py -- --frame 1 --output renders/frame-0001.png
"""
from pathlib import Path
import argparse
import bpy
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--frame', type=int, default=1)
    parser.add_argument('--output', type=Path, default=Path('renders/frame-0001.png'))
    blender_args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    args, _ = parser.parse_known_args(blender_args)
    if args.frame < 1:
        raise SystemExit('--frame must be at least 1')
    scene = bpy.context.scene
    scene.frame_set(args.frame)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    scene.render.filepath = str(output)
    scene.render.image_settings.file_format = 'PNG'
    bpy.ops.render.render(write_still=True)
    print(f'ASTRA_TIDES_FRAME {output}')


if __name__ == '__main__':
    main()

# Prior No. 019 — Astra Tides source scene

This compact pack contains the approved continuous-water Blender scene used for the Astra Tides v10 picture. It recreates the picture layer only: it does not contain the captioned film, Prior brand font, GSAP, voice, ambience, or comparison edit.

## Requirements

- Blender 5.2.1 LTS or a compatible Blender 5.x build.
- No add-ons or external Python packages are required by the saved scene or `render.py`.

## Render one picture

From this directory, run:

```powershell
blender --background water-flow-a-v10.blend --python render.py -- --frame 1 --output renders\frame-0001.png
```

The scene contains packed Earth texture and land-mask images. `render.py` renders one selected frame; it does not produce audio or captions. Change `--frame` to inspect another authored pose.

## Files

- `water-flow-a-v10.blend` — approved 80-second, 30 fps continuous-water scene; source images are packed in the `.blend`.
- `render.py` — small still-frame render helper authored for this pack.
- `prepare_water_motion.py` — reference source for the approved water-motion preparation. It is included for inspection and provenance, but its original workflow also expects the private v9 `film.blend` and render manifest.
- `scene-manifest.json` records the initial scene construction; its earlier scene hash and review status are historical. `water-motion-approval.json` records the approved continuous-water revision. The ZIP's `manifest.json` verifies every file actually included here.
- `SOURCES.md` — image provenance and exact hashes.
- `LICENSE.md` — pack code terms and third-party asset boundaries.

The final captioned film is a separate downloadable artifact on the Prior site and is intentionally outside this scene source pack.

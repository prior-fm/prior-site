# No. 019 source record

## Scene inputs

The Blender audit on 2026-09-08 found two packed images in `water-flow-a-v10.blend`, with no linked Blender libraries and no scene audio:

| Packed image | Origin and record |
|---|---|
| `bluemarble-5400.jpg` | NASA Visible Earth Blue Marble imagery; provenance in `kit/data/no-015-albedo.json`. NASA says the imagery is free to use and asks that it not imply NASA endorsement. |
| `no-015-land.png` | Generated from Natural Earth 50m physical land; provenance in `kit/data/no-015-land.json`. Natural Earth is documented there as public domain. |

The pack includes the provenance JSON records, while the exact image bytes used by the scene remain packed inside the `.blend`.

## Frozen source hashes

| File | SHA-256 |
|---|---|
| `water-flow-a-v10.blend` | `8fcb860b164aeb980a68506291636300fd731c0ca50f0440e484511c99555f9c` |
| `prepare_water_motion.py` | `22a154dcc8060cb86a8d93236a5cbf3fcb959a3ee0e56c7fff038258b5cd8ea8` |
| `scene-manifest.json` | `98bf43ddddcc7a89f9eb63b3244bbaaed0622747266d0574250216afac047d58` |
| `water-motion-approval.json` | `1a00958c41e944a78fdec4ae53ddfda69b3c1980aefe5677ab91e301fc7976ff` |
| `no-015-land.json` | `248ed1b55227a36909c7a8f5316f4bf223ef3da32fbed126563db10e1575aa5f` |
| `no-015-albedo.json` | `42696948efbd90f5975d7e41f3b08c3ba067484e49e6a0eb10a6e4687237e27e` |

The original provenance records identify these source URLs:

- Natural Earth: `https://www.naturalearthdata.com/` and the Natural Earth Vector GeoJSON source recorded in `no-015-land.json`.
- NASA Visible Earth: the Blue Marble and cloud URLs recorded in `no-015-albedo.json`.

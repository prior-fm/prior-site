# Prior No. 009 — the pathfinding race

Five algorithms, one real city, one start/end query. This is the exact
experiment behind the film — its Nodes/Time captions are this script's
output, measured, not illustrated.

## Run it

    python race.py

Python 3.9+, standard library only — nothing to install. The first run
downloads central Madrid's drivable street network from OpenStreetMap's
Overpass API (~13 MB, cached to `madrid.json`), builds a ~72,000-node
weighted graph, then races:

| algorithm | what it does | why it matters |
|---|---|---|
| Dijkstra | uniform-cost flood | optimal, but explores half the city |
| Greedy Best-First | chases the heuristic only | ~60× fewer nodes — and a longer route |
| A* | cost + heuristic | optimal AND directed at the goal |
| Bidirectional Dijkstra | two floods meeting | the classic speedup, still uninformed |
| Bidirectional A* | two directed fronts | the sparsest search in the race |

It verifies the honesty claim in code: every optimal algorithm must return
a route of identical length (on the film's run, 8.37 km — Dijkstra, A* and
both bidirectionals agree to the metre), while greedy's is 23.6% longer.
That gap is not a bug; it is the price of never looking back.

Each run writes `<algorithm>.svg` next to the script — the network in
grey, the explored edges in that algorithm's colour, the route on top.
Open them side by side: the comparison IS the film.

## Try your own city

    python race.py --city berlin
    python race.py --bbox 41.35 2.10 41.45 2.23   # south west north east

Wall times vary with your machine; the node counts and route lengths are
deterministic for a given map snapshot.

— Prior · prior-fm.github.io/prior-site · @prior.fm

"""Race five pathfinding algorithms on a real city's street network.

This is the exact experiment behind Prior No. 009 — the film's numbers are
this script's output, not illustrations. Standard library only.

    python race.py                  # Madrid (the film's run)
    python race.py --city berlin    # same race, different city
    python race.py --bbox 40.37 -3.785 40.46 -3.64

It downloads the drivable street network from OpenStreetMap's Overpass API
(cached to <city>.json after the first run, ~10-15 MB), builds a weighted
graph, then runs, on the SAME start/end query:

    Dijkstra                 uniform-cost flood — optimal, explores everywhere
    Greedy Best-First        chases the heuristic only — fast, NOT optimal
    A*                       cost + heuristic — optimal, explores toward the goal
    Bidirectional Dijkstra   two uniform floods meeting in the middle
    Bidirectional A*         two directed fronts — the sparsest search here

For each it reports nodes expanded, wall time, and route length, verifies
that every optimal algorithm found a route of identical length (greedy is
allowed to be longer — that is the point of greedy), and writes
<city>-<algorithm>.svg: the network in grey, the explored edges in colour,
the final route on top. Open them side by side; that comparison is the film.
"""

import argparse
import heapq
import json
import math
import time
import urllib.request
from pathlib import Path

CITIES = {
    # south, west, north, east — chosen so the box is ~12 x 10 km of centre
    "madrid": (40.370, -3.785, 40.460, -3.640),
    "berlin": (52.470, 13.290, 52.560, 13.500),
}

MAJOR = {"motorway", "trunk", "primary", "secondary",
         "motorway_link", "trunk_link", "primary_link", "secondary_link"}
DRIVABLE = MAJOR | {"tertiary", "tertiary_link", "residential", "unclassified"}

# start/end as fractions of the bbox (x from west, y from north) — the
# film's query. Move them and the race changes; the ranking rarely does.
START_FRAC, END_FRAC = (0.168, 0.446), (0.733, 0.471)

ACCENT = {"dijkstra": "#b0cbd6", "greedy": "#da9062", "astar": "#f1ecdf",
          "bidi-dijkstra": "#b0cbd6", "bidi-astar": "#f1ecdf"}


def fetch(bbox, cache: Path):
    if cache.exists():
        return json.loads(cache.read_text(encoding="utf-8"))
    q = (f"[out:json][timeout:180];\n"
         f"way[\"highway\"~\"^({'|'.join(sorted(DRIVABLE))})$\"]"
         f"({bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]});\n(._;>;);\nout body qt;")
    print("downloading street network from Overpass (once, then cached)…")
    req = urllib.request.Request("https://overpass-api.de/api/interpreter",
                                 data=q.encode(),
                                 headers={"User-Agent": "prior-no-009-pack/1.0"})
    with urllib.request.urlopen(req, timeout=300) as r:
        data = json.load(r)
    cache.write_text(json.dumps(data), encoding="utf-8")
    return data


def haversine(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = (math.sin((lat2 - lat1) / 2) ** 2
         + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2)
    return 6371000 * 2 * math.asin(math.sqrt(h))


def build(data):
    nodes, adj = {}, {}
    for el in data["elements"]:
        if el["type"] == "node":
            nodes[el["id"]] = (el["lat"], el["lon"])
    for el in data["elements"]:
        if el["type"] != "way":
            continue
        nds = [n for n in el["nodes"] if n in nodes]
        for u, v in zip(nds, nds[1:]):
            d = haversine(nodes[u], nodes[v])
            if d:
                adj.setdefault(u, {})[v] = min(adj.get(u, {}).get(v, 1e18), d)
                adj.setdefault(v, {})[u] = min(adj.get(v, {}).get(u, 1e18), d)
    # largest connected component
    seen, best = set(), []
    for s in adj:
        if s in seen:
            continue
        comp, stack = [], [s]
        seen.add(s)
        while stack:
            u = stack.pop()
            comp.append(u)
            stack.extend(v for v in adj[u] if v not in seen and not seen.add(v))
        if len(comp) > len(best):
            best = comp
    keep = set(best)
    return ({n: nodes[n] for n in keep},
            {u: {v: d for v, d in nb.items() if v in keep}
             for u, nb in adj.items() if u in keep})


def search(adj, nodes, s, t, g_weight=1.0, h_target=None):
    """One engine, three behaviours: Dijkstra (no h), A* (g + h),
    Greedy (h only, g_weight=0). Returns (settled, parent)."""
    def h(n):
        return haversine(nodes[n], nodes[h_target]) if h_target else 0.0
    dist, parent, done, settled = {s: 0.0}, {s: None}, set(), []
    pq = [(h(s), s)]
    while pq:
        _, u = heapq.heappop(pq)
        if u in done:
            continue
        done.add(u)
        settled.append(u)
        if u == t:
            break
        for v, d in adj[u].items():
            if g_weight:
                nd = dist[u] + d
                if nd < dist.get(v, 1e18):
                    dist[v], parent[v] = nd, u
                    heapq.heappush(pq, (nd + h(v), v))
            elif v not in parent and v not in done:
                parent[v] = u
                heapq.heappush(pq, (h(v), v))
    return settled, parent


def bidirectional(adj, nodes, s, t, informed):
    def mk_h(target):
        return (lambda n: haversine(nodes[n], nodes[target])) if informed else (lambda n: 0.0)
    hs = [mk_h(t), mk_h(s)]
    dist = [{s: 0.0}, {t: 0.0}]
    parent = [{s: None}, {t: None}]
    done = [set(), set()]
    pq = [[(hs[0](s), s)], [(hs[1](t), t)]]
    settled, best = [], (1e18, None)
    while pq[0] and pq[1]:
        side = 0 if len(done[0]) <= len(done[1]) else 1
        while pq[side]:
            _, u = heapq.heappop(pq[side])
            if u not in done[side]:
                break
        else:
            break
        done[side].add(u)
        settled.append(u)
        for v, d in adj[u].items():
            nd = dist[side][u] + d
            if nd < dist[side].get(v, 1e18):
                dist[side][v], parent[side][v] = nd, u
                heapq.heappush(pq[side], (nd + hs[side](v), v))
            if v in dist[1 - side] and nd + dist[1 - side][v] < best[0]:
                best = (nd + dist[1 - side][v], (u, v) if side == 0 else (v, u))
        if best[1]:
            if not informed and pq[0] and pq[1] and pq[0][0][0] + pq[1][0][0] >= best[0]:
                break
            if informed and u in done[1 - side]:
                break
    if not best[1]:
        return settled, []
    fu, bv = best[1]
    left = unwind(parent[0], fu)          # s … fu
    right = unwind(parent[1], bv)         # t … bv (backward tree)
    return settled, left + list(reversed(right))  # s … fu, bv … t


def unwind(parent, t):
    path, n = [], t
    while n is not None:
        path.append(n)
        n = parent[n]
    path.reverse()
    return path


def path_km(nodes, path):
    return sum(haversine(nodes[a], nodes[b]) for a, b in zip(path, path[1:])) / 1000


def write_svg(name, nodes, adj, settled, path, s, t, ext, out_dir):
    lat0, lon0, lat1, lon1 = ext[0], ext[1], ext[2], ext[3]
    W = 800
    H = round(W * (lat1 - lat0) * 111.13
              / ((lon1 - lon0) * 111.32 * math.cos(math.radians((lat0 + lat1) / 2))))

    def xy(n):
        la, lo = nodes[n]
        return (round((lo - lon0) / (lon1 - lon0) * W, 1),
                round((lat1 - la) / (lat1 - lat0) * H, 1))

    def polyline(pairs, colour, width, opacity=1.0):
        d = " ".join(f"M{a[0]} {a[1]} L{b[0]} {b[1]}" for a, b in pairs)
        return (f'<path d="{d}" stroke="{colour}" stroke-width="{width}" '
                f'fill="none" opacity="{opacity}"/>')

    base = [(xy(u), xy(v)) for u in adj for v in adj[u] if u < v]
    lit_nodes = set(settled)
    lit = [(xy(u), xy(v)) for u, v in
           ((u, v) for u in lit_nodes for v in adj[u] if v in lit_nodes and u < v)]
    route = list(zip(map(xy, path), map(xy, path[1:])))
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
           f'viewBox="0 0 {W} {H}" style="background:#0a0a0a">',
           f'<rect width="{W}" height="{H}" fill="#0a0a0a"/>',
           polyline(base, "#2a261f", 0.6),
           polyline(lit, ACCENT[name], 1.2, 0.9),
           polyline(route, "#efece4", 2.5),
           f'<circle cx="{xy(s)[0]}" cy="{xy(s)[1]}" r="6" fill="#da9062"/>',
           f'<circle cx="{xy(t)[0]}" cy="{xy(t)[1]}" r="6" fill="#b0cbd6"/>',
           "</svg>"]
    p = out_dir / f"{name}.svg"
    p.write_text("\n".join(svg), encoding="utf-8")
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--city", default="madrid", choices=sorted(CITIES))
    ap.add_argument("--bbox", nargs=4, type=float, metavar=("S", "W", "N", "E"))
    args = ap.parse_args()
    bbox = tuple(args.bbox) if args.bbox else CITIES[args.city]
    name = "custom" if args.bbox else args.city

    here = Path(__file__).resolve().parent
    nodes, adj = build(fetch(bbox, here / f"{name}.json"))
    print(f"{name}: {len(nodes):,} nodes, {sum(len(v) for v in adj.values())//2:,} edges")

    # fractions are applied to the GRAPH's own extent, not the request bbox —
    # the same convention as the film's data build, so this script reproduces
    # the film's query (and its node counts) exactly.
    lats = [p[0] for p in nodes.values()]
    lons = [p[1] for p in nodes.values()]
    ext = (min(lats), min(lons), max(lats), max(lons))

    def frac_to_node(fx, fy):
        la = ext[2] - fy * (ext[2] - ext[0])
        lo = ext[1] + fx * (ext[3] - ext[1])
        return min(nodes, key=lambda n: (nodes[n][0] - la) ** 2 + (nodes[n][1] - lo) ** 2)

    s, t = frac_to_node(*START_FRAC), frac_to_node(*END_FRAC)
    print(f"query: {haversine(nodes[s], nodes[t])/1000:.2f} km as the crow flies\n")

    races = [
        ("dijkstra",      lambda: search(adj, nodes, s, t)),
        ("greedy",        lambda: search(adj, nodes, s, t, g_weight=0, h_target=t)),
        ("astar",         lambda: search(adj, nodes, s, t, h_target=t)),
        ("bidi-dijkstra", lambda: bidirectional(adj, nodes, s, t, False)),
        ("bidi-astar",    lambda: bidirectional(adj, nodes, s, t, True)),
    ]
    print(f"{'algorithm':<16}{'nodes':>9}{'time':>10}{'route':>10}")
    results = {}
    for rname, fn in races:
        t0 = time.perf_counter()
        out = fn()
        ms = (time.perf_counter() - t0) * 1000
        settled, ptr = out
        path = ptr if isinstance(ptr, list) else unwind(ptr, t)
        km = path_km(nodes, path)
        results[rname] = km
        print(f"{rname:<16}{len(settled):>9,}{ms:>8.1f}ms{km:>8.2f}km")
        write_svg(rname, nodes, adj, settled, path, s, t, ext, here)

    ref = results["dijkstra"]
    for rname in ("astar", "bidi-dijkstra", "bidi-astar"):
        assert abs(results[rname] - ref) < 0.001, f"{rname} is not optimal!"
    print(f"\noptimal route {ref:.2f} km — dijkstra, astar and both bidirectionals agree.")
    print(f"greedy's route is {100*(results['greedy']/ref-1):.1f}% longer. "
          f"That is the trade it makes for touching almost nothing.")
    print(f"SVGs written next to this script — open them side by side.")


if __name__ == "__main__":
    main()

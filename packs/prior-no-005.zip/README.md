# Prior — No. 005 — Load balancing

The runnable version of the film. A load balancer, three backends, active
health checks, and a failure you trigger yourself.

**Python 3.9+. No dependencies, no Docker, no network beyond `127.0.0.1`.**

```
python run.py
```

That is the whole setup. It takes about twenty seconds.

---

## What you are looking for

The film claims one thing above all others, and this is here so you can check
it rather than take it:

> A load balancer does not make a request faster. It stops requests waiting
> for each other.

`run.py` runs three acts against the same balancer, at the same offered load of
40 requests a second, with the same 40 ms of work inside every request.

**Act 1 — one server.** 40 req/s offered against 25 req/s of capacity. The
queue grows, and the growth *is* the latency:

```
   second   answered   dropped   median response
        0         40         0            406 ms
        1         40         0           1082 ms
        2         36         4           1719 ms
        3          0        40                 —
        4          0        40                 —
        5          0        40                 —
```

Note the second half. An overloaded server does not politely get slower
forever — past a point the balancer's upstream timeout fires and it starts
shedding traffic. By second three it is dropping everything.

**Act 2 — three servers behind one entry point.** Same 40 req/s, now against
75 req/s of capacity:

```
        0         40         0             63 ms
        1         40         0             66 ms
   ...
   window median 65 ms   ·   worst 86 ms   ·   dropped 0/240
```

**It does not go below 40 ms.** It cannot. That is the work. The 1,679 ms that
disappeared was never computation — it was requests queueing.

**Act 3 — one of the three is killed.** Health checks notice, take it out of
rotation, and the number does not move:

```
        0         36         4             66 ms
        1         40         0             72 ms
   ...
   window median 67 ms   ·   worst 88 ms   ·   dropped 4/240
```

The four dropped requests are the ones already in flight to `app2` when it
died. **Failover is not free** — it costs you whatever was mid-air. It is just
very much cheaper than the alternative.

Your numbers will differ. The shape will not.

---

## The files

| | |
|---|---|
| `run.py` | The three acts. Start here. |
| `balancer.py` | The balancer: round-robin, health checking, failover. ~140 lines. |
| `backend.py` | One backend. Single-threaded on purpose — that is where the queue comes from. |
| `nginx.conf` | The same thing in production shape, with the film's own `upstream` block filled in. |

Each of them runs on its own too:

```
python backend.py  --name app1 --port 9001
python balancer.py --port 9000 --upstream 127.0.0.1:9001 --upstream 127.0.0.1:9002
curl http://127.0.0.1:9000/
curl http://127.0.0.1:9101/kill      # health port is traffic port + 100
```

---

## Three things this pack gets right that are easy to get wrong

**1. The health check is on a different port from the traffic.** The first
version of this pack served `/health` from the work port. With the server
saturated, health checks queued behind the requests they were meant to measure,
timed out, and the checker started marking a slow-but-alive server as dead —
removing capacity at the exact moment there was none to spare. Real deployments
put health on its own listener for this reason. See the note at the top of
`backend.py`.

**2. One failure is not evidence.** An upstream is removed after
`FAIL_THRESHOLD` consecutive failures and restored after `RISE_THRESHOLD`
consecutive successes. Networks drop packets; a single timeout means nothing,
and a single success from a flapping server means nothing either.

**3. The load generator is open-loop.** A generator where N workers each send
the next request as soon as the last returns can never build a queue — it
throttles itself to whatever the server can do, so the server always looks
fine. Real traffic does not wait to be invited. `run.py` fires on a fixed
schedule regardless, which is why act 1 has anything to show.

---

## And one the film simplifies

The film says "health checks detect the failure". `balancer.py` does that
actively — a background loop on its own clock. **Open-source nginx does not.**
It has passive checks only: `max_fails` / `fail_timeout`, which notice an
upstream failing while it is serving real traffic. Some of your users *are* the
health check. Active checking is nginx Plus, or HAProxy, or Envoy, or your
cloud's balancer. `nginx.conf` says so at the top.

---

Prior · one idea per issue, and the source with every one
https://prior-fm.github.io/prior-site/

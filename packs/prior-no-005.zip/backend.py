"""One backend. Two ports, and both choices are the lesson.

THE WORK PORT IS SINGLE-THREADED, on purpose. A `ThreadingHTTPServer` would
answer every request at once and there would be no queue to demonstrate. A
plain `HTTPServer` handles one request at a time, so requests arriving faster
than it can serve them wait — which is what a real server does when it
saturates, and where the 440 ms in the film comes from.

THE HEALTH PORT IS SEPARATE, and this is not a convenience. The first version
of this pack served `/health` from the work port, and the demo fell apart: with
the server saturated, health checks queued behind the very requests they were
meant to measure, timed out, and the checker started marking a slow-but-alive
server as dead. That is a real failure mode — it is why production health
endpoints live on their own listener or admin port — but it meant act one
measured flapping instead of queueing.

    port          the work. Single-threaded. This is what gets slow.
    port + 100    health and admin. Threaded, cheap, never queues.

Stdlib only. No dependencies, nothing beyond 127.0.0.1.
"""
from __future__ import annotations

import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer

# How long the actual work takes. This is the floor: no amount of load
# balancing can make a request finish faster than the work inside it.
WORK_MS = 40

# The accept queue. Python's default is 5, and at 5 the kernel REFUSES the
# sixth waiting connection instead of queueing it — so the first build of this
# demo reported 98 failures where it should have reported a growing queue. The
# backlog has to be deep enough for the queue to exist before you can measure
# it.
BACKLOG = 512

HEALTH_PORT_OFFSET = 100


class _State:
    """Shared between a backend's two servers."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.served = 0
        self.healthy = True


def _json(handler: BaseHTTPRequestHandler, code: int, payload: dict) -> None:
    body = json.dumps(payload).encode()
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _work_handler(state: _State):
    class Work(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802  (stdlib naming)
            if not state.healthy:
                _json(self, 503, {"status": "down", "server": state.name})
                return
            time.sleep(WORK_MS / 1000)          # the work
            state.served += 1
            _json(self, 200, {"server": state.name, "served": state.served})

        def log_message(self, *_args) -> None:
            pass                                 # quiet; run.py does the reporting

    return Work


def _admin_handler(state: _State):
    class Admin(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                if state.healthy:
                    _json(self, 200, {"status": "ok", "served": state.served})
                else:
                    _json(self, 503, {"status": "down"})
            elif self.path == "/kill":
                state.healthy = False
                _json(self, 200, {"status": "killed", "server": state.name})
            elif self.path == "/revive":
                state.healthy = True
                _json(self, 200, {"status": "ok", "server": state.name})
            else:
                _json(self, 404, {"error": "not found"})

        def log_message(self, *_args) -> None:
            pass

    return Admin


def serve(name: str, port: int) -> tuple[_State, HTTPServer, ThreadingHTTPServer]:
    """Start one backend: work on `port`, health and admin on `port + 100`."""
    state = _State(name)

    work_cls = type("Work", (HTTPServer,), {"request_queue_size": BACKLOG})
    work = work_cls(("127.0.0.1", port), _work_handler(state))
    threading.Thread(target=work.serve_forever, daemon=True).start()

    admin = ThreadingHTTPServer(("127.0.0.1", port + HEALTH_PORT_OFFSET), _admin_handler(state))
    threading.Thread(target=admin.serve_forever, daemon=True).start()

    return state, work, admin


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="app1")
    ap.add_argument("--port", type=int, default=9001)
    args = ap.parse_args()
    _state, work, admin = serve(args.name, args.port)
    print(f"{args.name}: work on 127.0.0.1:{args.port}, "
          f"health on 127.0.0.1:{args.port + HEALTH_PORT_OFFSET}  (work = {WORK_MS} ms)")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        work.shutdown()
        admin.shutdown()

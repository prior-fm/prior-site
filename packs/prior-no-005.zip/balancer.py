"""A load balancer, in about a hundred lines of standard library.

Round-robin over a pool of upstreams, skipping any the health checker has
marked down. This is the thing the film draws: one entry point, several
identical servers behind it, and a background loop that decides which of them
are allowed to receive traffic.

Two details that are easy to get wrong and matter more than the round-robin:

1. The health checker runs on its own clock, not on the request path. Checking
   an upstream's health *while* forwarding a request would put the check behind
   the queue it is trying to measure.

2. An upstream is only removed after it fails repeatedly (FAIL_THRESHOLD), and
   is only restored after it passes repeatedly (RISE_THRESHOLD). A single
   timeout is not evidence of anything — networks drop packets — and a single
   success from a flapping server is not evidence either.

3. The health check goes to a DIFFERENT PORT from the traffic. Checking the
   port that is busy serving requests means the check queues behind them, times
   out, and reports a slow server as a dead one — which removes capacity at the
   exact moment you have none to spare. See the note at the top of backend.py;
   this pack got it wrong first and the demo told on it.

An upstream here is therefore a triple: (host, traffic_port, health_port).
"""
from __future__ import annotations

import itertools
import json
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CHECK_EVERY_S = 0.25     # how often the health loop polls each upstream
CHECK_TIMEOUT_S = 0.20   # a health check that hangs IS a failure
FAIL_THRESHOLD = 2       # consecutive failures before an upstream is removed
RISE_THRESHOLD = 2       # consecutive successes before it is restored
UPSTREAM_TIMEOUT_S = 2.0


class Pool:
    """The upstream list, and the only thing that decides who gets traffic."""

    def __init__(self, upstreams: list[tuple[str, int, int]]) -> None:
        self.upstreams = upstreams
        self.up = {u: True for u in upstreams}
        self.fails = {u: 0 for u in upstreams}
        self.rises = {u: 0 for u in upstreams}
        self.dispatched = {u: 0 for u in upstreams}
        self._cycle = itertools.cycle(range(len(upstreams)))
        self._lock = threading.Lock()
        self._stop = threading.Event()

    def healthy(self) -> list[tuple[str, int]]:
        with self._lock:
            return [u for u in self.upstreams if self.up[u]]

    def pick(self) -> tuple[str, int] | None:
        """Next healthy upstream, round-robin.

        The cycle runs over ALL upstreams and skips the unhealthy ones rather
        than cycling over a filtered list — so removing one server does not
        re-order the rotation for the others.
        """
        with self._lock:
            for _ in range(len(self.upstreams)):
                u = self.upstreams[next(self._cycle)]
                if self.up[u]:
                    self.dispatched[u] += 1
                    return u
        return None

    # ---------------------------------------------------------------- health --
    def _check_once(self, u: tuple[str, int]) -> bool:
        host, _port, health_port = u
        try:
            with urllib.request.urlopen(
                f"http://{host}:{health_port}/health", timeout=CHECK_TIMEOUT_S
            ) as r:
                return r.status == 200
        except (urllib.error.URLError, OSError):
            return False

    def _health_loop(self, on_change) -> None:
        while not self._stop.is_set():
            for u in self.upstreams:
                ok = self._check_once(u)
                with self._lock:
                    if ok:
                        self.fails[u] = 0
                        self.rises[u] += 1
                        if not self.up[u] and self.rises[u] >= RISE_THRESHOLD:
                            self.up[u] = True
                            changed = ("up", u)
                        else:
                            changed = None
                    else:
                        self.rises[u] = 0
                        self.fails[u] += 1
                        if self.up[u] and self.fails[u] >= FAIL_THRESHOLD:
                            self.up[u] = False
                            changed = ("down", u)
                        else:
                            changed = None
                if changed and on_change:
                    on_change(*changed)
            self._stop.wait(CHECK_EVERY_S)

    def start_health_checks(self, on_change=None) -> None:
        threading.Thread(target=self._health_loop, args=(on_change,), daemon=True).start()

    def stop(self) -> None:
        self._stop.set()


def make_handler(pool: Pool):
    class Balancer(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def do_GET(self) -> None:  # noqa: N802
            u = pool.pick()
            if u is None:
                # Every upstream is down. Say so honestly with a 503 rather
                # than forwarding into a hole — which is what a balancer with
                # no health checks does, and why it is worse than one server.
                self._send(503, {"error": "no healthy upstream"})
                return
            host, port, _health = u
            try:
                with urllib.request.urlopen(
                    f"http://{host}:{port}{self.path}", timeout=UPSTREAM_TIMEOUT_S
                ) as r:
                    body = r.read()
                    self.send_response(r.status)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
            except (urllib.error.URLError, OSError) as exc:
                self._send(502, {"error": str(exc), "upstream": f"{host}:{port}"})

        def _send(self, code: int, payload: dict) -> None:
            body = json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_args) -> None:
            pass

    return Balancer


def serve(pool: Pool, port: int) -> ThreadingHTTPServer:
    """Threaded ON PURPOSE, the mirror image of the backend.

    The balancer must never be the bottleneck — it does no work, it only
    forwards. The backends are single-threaded because they do the work.
    """
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(pool))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--port", type=int, default=9000)
    ap.add_argument("--upstream", action="append", default=[],
                    help="host:port[:health_port], repeatable. "
                         "health_port defaults to port + 100.")
    args = ap.parse_args()
    ups = []
    for spec in args.upstream:
        parts = spec.split(":")
        host, port = parts[0], int(parts[1])
        ups.append((host, port, int(parts[2]) if len(parts) > 2 else port + 100))
    pool = Pool(ups)
    pool.start_health_checks(lambda state, u: print(f"health: {u[0]}:{u[1]} -> {state}"))
    serve(pool, args.port)
    print(f"balancer on 127.0.0.1:{args.port} over {len(ups)} upstream(s)")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pool.stop()

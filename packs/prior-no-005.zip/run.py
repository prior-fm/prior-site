"""Reproduce the film's three acts, with your own numbers.

    python run.py

No dependencies, no Docker, no network beyond 127.0.0.1. It starts three
backends and a balancer in this process, fires a fixed rate of traffic at them,
and prints what actually happened.

WHY THE LOAD IS OPEN-LOOP, because it changes the result completely.
A closed-loop generator — N workers each sending the next request as soon as
the last one returns — can never build a queue: it throttles itself to whatever
the server can do. Real traffic does not wait to be invited. This fires on a
fixed schedule whether or not the previous request has come back, so when the
arrival rate passes the service rate the queue grows, and that growth IS the
latency in act one.

WHAT IT DEMONSTRATES

    act 1   one backend,   40 req/s offered against 25 req/s of capacity
            -> the queue grows and latency climbs with it
    act 2   three backends, same 40 req/s against 75 req/s of capacity
            -> latency falls back to roughly the work itself and STAYS there
    act 3   one of the three killed, still 40 req/s against 50 req/s
            -> health checks remove it, and the number does not move

The floor in acts 2 and 3 is `backend.WORK_MS`. Nothing here can go below it,
because that is the work. A load balancer does not make a request faster; it
stops requests waiting for each other.
"""
from __future__ import annotations

import statistics
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import backend
import balancer

BAL_PORT = 9000
PORTS = [9001, 9002, 9003]
RATE = 40          # requests per second offered, in every act
WINDOW = 6         # seconds per act
TIMEOUT = 10.0


def one_request(url: str) -> float | None:
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(url, timeout=TIMEOUT) as r:
            r.read()
            if r.status != 200:
                return None
    except (urllib.error.URLError, OSError):
        return None
    return (time.perf_counter() - t0) * 1000


def offer(url: str, rate: int, seconds: int, pool: ThreadPoolExecutor):
    """Submit `rate` requests a second for `seconds`, on the clock."""
    futures = []
    start = time.perf_counter()
    total = rate * seconds
    for i in range(total):
        due = start + i / rate
        now = time.perf_counter()
        if due > now:
            time.sleep(due - now)
        futures.append((i / rate, pool.submit(one_request, url)))
    return futures


def report(label: str, futures) -> None:
    """Latency AND drops, per second.

    Reporting only the requests that came back would flatter act one badly. An
    overloaded server does not just get slow — past a point the balancer's
    upstream timeout fires and it starts shedding traffic, and by the third
    second of act one that is most of it. The dropped column is the honest half
    of the story, and it is the half that takes a site down.
    """
    ok: dict[int, list[float]] = {}
    dropped: dict[int, int] = {}
    for offered_at, f in futures:
        s = int(offered_at)
        ms = f.result()
        if ms is None:
            dropped[s] = dropped.get(s, 0) + 1
        else:
            ok.setdefault(s, []).append(ms)

    print(f"\n{label}")
    print("   second   answered   dropped   median response")
    for s in sorted(set(ok) | set(dropped)):
        vals = ok.get(s, [])
        med = f"{statistics.median(vals):.0f} ms" if vals else "—"
        print(f"   {s:>6}   {len(vals):>8}   {dropped.get(s, 0):>7}   {med:>15}")
    allv = [v for vals in ok.values() for v in vals]
    total_dropped = sum(dropped.values())
    if allv:
        print(f"   window median {statistics.median(allv):.0f} ms"
              f"   ·   worst {max(allv):.0f} ms"
              f"   ·   dropped {total_dropped}/{len(futures)}")


def drain(url: str, quiet_ms: float) -> None:
    """Wait until the backlog is gone, so the next act starts from rest."""
    for _ in range(400):
        ms = one_request(url)
        if ms is not None and ms < quiet_ms:
            return
        time.sleep(0.05)


def main() -> int:
    servers = []
    for name, port in zip(("app1", "app2", "app3"), PORTS):
        state, work, admin = backend.serve(name, port)
        servers.append((name, port, work, admin))

    upstreams = [("127.0.0.1", p, p + backend.HEALTH_PORT_OFFSET) for p in PORTS]
    pool = balancer.Pool(upstreams)
    pool.start_health_checks(
        lambda state, u: print(f"   health check: 127.0.0.1:{u[1]} -> {state.upper()}")
    )
    balancer.serve(pool, BAL_PORT)
    url = f"http://127.0.0.1:{BAL_PORT}/"

    print(__doc__.split("WHAT IT DEMONSTRATES")[0].strip())
    print(f"\nwork per request: {backend.WORK_MS} ms"
          f"   ·   offered load: {RATE} req/s   ·   window: {WINDOW}s")

    # ---- act 1: one backend ------------------------------------------------
    # Take two of the three out by killing them, so act 1 runs against a single
    # server through the same balancer — one variable at a time.
    for _, port, _, _ in servers[1:]:
        one_request(f"http://127.0.0.1:{port + backend.HEALTH_PORT_OFFSET}/kill")
    time.sleep(balancer.CHECK_EVERY_S * (balancer.FAIL_THRESHOLD + 1))

    with ThreadPoolExecutor(max_workers=RATE * WINDOW + 8) as ex:
        report("ACT 1 — one server. 40 req/s offered, 25 req/s of capacity.",
               offer(url, RATE, WINDOW, ex))
    drain(url, backend.WORK_MS * 2)

    # ---- act 2: three backends --------------------------------------------
    for _, port, _, _ in servers[1:]:
        one_request(f"http://127.0.0.1:{port + backend.HEALTH_PORT_OFFSET}/revive")
    time.sleep(balancer.CHECK_EVERY_S * (balancer.RISE_THRESHOLD + 1))

    with ThreadPoolExecutor(max_workers=RATE * WINDOW + 8) as ex:
        report("ACT 2 — three servers behind one entry point. Same 40 req/s.",
               offer(url, RATE, WINDOW, ex))
    drain(url, backend.WORK_MS * 2)

    # ---- act 3: kill one ---------------------------------------------------
    print("\n   killing app2 ...")
    one_request(f"http://127.0.0.1:{PORTS[1] + backend.HEALTH_PORT_OFFSET}/kill")

    with ThreadPoolExecutor(max_workers=RATE * WINDOW + 8) as ex:
        report("ACT 3 — app2 is dead. Health checks take it out. Same 40 req/s.",
               offer(url, RATE, WINDOW, ex))

    print("\n   dispatched per upstream (cumulative, all three acts):")
    for u, n in pool.dispatched.items():
        state = "up" if pool.up[u] else "DOWN"
        print(f"      {u[0]}:{u[1]}   {n:>5}   {state}")

    print(f"\n   The floor is {backend.WORK_MS} ms and nothing above can beat it.")
    print("   What acts 2 and 3 removed was queueing, not work.")

    pool.stop()
    for _, _, work, admin in servers:
        work.shutdown()
        admin.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

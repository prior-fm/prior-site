"""The same watermarker, against a real model, producing real English.

    pip install -r requirements-hf.txt
    python demo_hf.py --prompt "The problem with detecting AI text is"

Optional. `demo_synthetic.py` runs the identical watermarker and detector with
no dependencies at all and is the better place to read the statistics; this file
exists so you can see what watermarked text actually looks like — which is the
point most coverage of the subject gets wrong. It looks like nothing. There are
no odd words, no rare synonyms, no tells.

GPT-2 by default because it is small and downloads quickly. Any causal LM with a
`transformers` tokenizer works; pass --model.

IMPORTANT: this watermarks GPT-2 output with YOUR key. It cannot tell you
whether a commercial model wrote something. Detection requires the key that
generated the text, and this pack's key is its own.
"""

from __future__ import annotations

import argparse

from kgw import (
    DEFAULT_DELTA,
    DEFAULT_GAMMA,
    Detector,
    Watermarker,
    WatermarkLogitsProcessor,
    new_key,
)
from significance import tokens_for_power

DEMO_KEY = "5f1c" * 16


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="gpt2")
    parser.add_argument("--prompt", default="The problem with detecting AI-written text is")
    parser.add_argument("--tokens", type=int, default=200)
    parser.add_argument("--gamma", type=float, default=DEFAULT_GAMMA)
    parser.add_argument("--delta", type=float, default=DEFAULT_DELTA)
    parser.add_argument("--key", default=DEMO_KEY)
    args = parser.parse_args()

    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, LogitsProcessorList
    except ImportError:
        print("This demo needs torch and transformers:\n")
        print("    pip install -r requirements-hf.txt\n")
        print("For the statistics with no dependencies at all, run demo_synthetic.py.")
        return 1

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(args.model)
    model.eval()

    vocab = model.get_output_embeddings().weight.shape[0]
    wm = Watermarker(args.key, vocab, args.gamma, args.delta)
    detector = Detector(args.key, vocab, args.gamma)

    ids = tokenizer(args.prompt, return_tensors="pt").input_ids
    prompt_len = ids.shape[1]

    def generate(processors):
        with torch.no_grad():
            return model.generate(
                ids,
                do_sample=True,
                max_new_tokens=args.tokens,
                top_k=0,
                pad_token_id=tokenizer.eos_token_id,
                logits_processor=processors,
            )

    # Same prompt, same model, same sampler — the ONLY difference is the bias.
    torch.manual_seed(0)
    marked = generate(LogitsProcessorList([WatermarkLogitsProcessor(wm)]))
    torch.manual_seed(0)
    plain = generate(LogitsProcessorList([]))

    # Score only the GENERATED tokens. The prompt was not written by the model
    # and counting it drags every z toward chance.
    marked_new = marked[0][prompt_len:].tolist()
    plain_new = plain[0][prompt_len:].tolist()

    print(f"model {args.model}   gamma {args.gamma}   delta {args.delta}   "
          f"{len(marked_new)} generated tokens scored")
    print()
    print("WATERMARKED")
    print("-" * 72)
    print(tokenizer.decode(marked[0], skip_special_tokens=True))
    print()
    print("NOT WATERMARKED")
    print("-" * 72)
    print(tokenizer.decode(plain[0], skip_special_tokens=True))
    print()
    print("DETECTION")
    print("-" * 72)
    marked_result = detector.score(marked_new)
    print(f"  watermarked      {marked_result}   -> {marked_result.verdict()}")
    plain_result = detector.score(plain_new)
    print(f"  not watermarked  {plain_result}   -> {plain_result.verdict()}")
    wrong = Detector(new_key(), vocab, args.gamma).score(marked_new)
    print(f"  wrong key        {wrong}   -> {wrong.verdict()}")
    print()
    if marked_result.green_fraction > args.gamma:
        need = tokens_for_power(marked_result.green_fraction, args.gamma, 4.0, 0.95)
        print(f"  At this green rate, 95% of passages need {need:,} tokens to clear z=4.")
    print()
    print("Read the two passages. Neither is obviously the marked one, which is")
    print("the property that matters: the bias operates between candidates the")
    print("model already considered acceptable.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

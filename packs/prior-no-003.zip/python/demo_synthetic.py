"""End to end with no model, no download and no dependencies.

    python demo_synthetic.py

There is no language model here. There is a stand-in that produces the one
thing the watermark actually interacts with: a plausible next-token
distribution over a vocabulary. That is enough to exercise the real
watermarker, the real detector and the real statistics — and it is honest
about being a stand-in rather than dressing a bigram toy up as Claude.

`demo_hf.py` runs the same code against GPT-2 and produces actual English, if
you want to read the output rather than measure it.

What this shows, and what it is for:

    1. watermarked text lands in its keyed green lists far more often than
       chance, and unwatermarked text does not
    2. the SAME text checked with the WRONG key looks unwatermarked — which is
       what makes a key a key
    3. the signal is proportional to how much freedom the text has. Low-entropy
       steps (one obvious next word) carry almost none, which is why detection
       is weak on short, factual or formulaic text — Anthropic states the same
       limit for its own scheme
    4. how many tokens a verdict needs, at each of those entropy levels
"""

from __future__ import annotations

import math

from kgw import DEFAULT_DELTA, DEFAULT_GAMMA, Detector, Watermarker, new_key
from significance import tokens_for_power, tokens_needed

VOCAB = 32_000

# A fixed key for a reproducible demo. `new_key()` is what you would actually
# use; printing a real secret into a terminal is not a habit worth teaching.
DEMO_KEY = "5f1c" * 16


class ToySampler:
    """A stand-in for a model's next-token distribution.

    Real next-token distributions are steep and vary enormously in how much
    they leave open: "the capital of France is ___" is nearly deterministic,
    "the weather was ___" is not. `freedom` controls that, and it is the single
    variable this whole demo turns on.

    The distribution is drawn from a fixed hash of the step index, so two runs
    of this file produce identical numbers — the same rule the film's own
    renderer follows.
    """

    def __init__(self, vocab_size: int = VOCAB, top_k: int = 64, freedom: float = 1.0) -> None:
        self.vocab_size = vocab_size
        self.top_k = top_k
        self.freedom = freedom

    def logits(self, step: int) -> list[float]:
        """A sparse-ish distribution: `top_k` live candidates, the rest far
        below. Returned as a full logit vector so `Watermarker.bias` operates on
        exactly the object it would get from a real model."""
        out = [-40.0] * self.vocab_size
        decay = 3.0 / max(self.freedom, 1e-3)
        for rank in range(self.top_k):
            token = _hash(step * 7919 + rank) % self.vocab_size
            # A Zipf-ish decay, flattened by `freedom`. Small freedom is a steep
            # distribution — one candidate that is obviously right, the
            # low-entropy case. Large freedom is flat: many candidates that are
            # all defensible, which is where a watermark has room to work.
            # `freedom` DIVIDES the decay; multiplying it inverts the axis, and
            # that is exactly the bug this comment exists to prevent.
            out[token] = -math.log(rank + 1.5) * decay
        return out


def _hash(n: int) -> int:
    x = (n * 2654435761) % 4294967296
    x = ((x ^ (x >> 13)) * 1274126177) % 4294967296
    return (x ^ (x >> 16)) % 4294967296


def _sample(logits: list[float], step: int, salt: int) -> int:
    """Softmax sample, with a deterministic uniform draw.

    Deterministic on purpose. An unseeded sampler makes two runs of this file
    disagree, and then nobody can tell a real change in the numbers from noise.
    """
    top = max(logits)
    weights = [math.exp(v - top) for v in logits]
    total = sum(weights)
    u = (_hash(step * 104729 + salt) / 4294967296.0) * total
    acc = 0.0
    for token, w in enumerate(weights):
        acc += w
        if acc >= u:
            return token
    return len(logits) - 1


def generate(
    n_tokens: int,
    freedom: float,
    watermarked: bool,
    key: str = DEMO_KEY,
    gamma: float = DEFAULT_GAMMA,
    delta: float = DEFAULT_DELTA,
    salt: int = 0,
) -> list[int]:
    sampler = ToySampler(freedom=freedom)
    wm = Watermarker(key, VOCAB, gamma, delta)
    tokens: list[int] = [_hash(salt) % VOCAB]
    for step in range(n_tokens):
        logits = sampler.logits(step)
        if watermarked:
            logits = wm.bias(logits, tokens)
        tokens.append(_sample(logits, step, salt))
    return tokens


def main() -> int:
    gamma, delta = DEFAULT_GAMMA, DEFAULT_DELTA
    detector = Detector(DEMO_KEY, VOCAB, gamma)
    wrong_key = Detector(new_key(), VOCAB, gamma)

    print("KGW watermark — synthetic demo")
    print(f"vocabulary {VOCAB:,}   gamma {gamma}   delta {delta}   400 tokens per run")
    print()

    print("1. Watermarked vs not, and the same text under the wrong key")
    print("-" * 68)
    marked = generate(400, freedom=1.0, watermarked=True)
    clean = generate(400, freedom=1.0, watermarked=False)
    print(f"  watermarked, right key   {detector.score(marked)}")
    print(f"  watermarked, WRONG key   {wrong_key.score(marked)}")
    print(f"  not watermarked          {detector.score(clean)}")
    print()
    print("  The middle line is the point. Detection is not a property of the")
    print("  text; it is a property of the text AND the key. Without the key")
    print("  the watermarked text is statistically ordinary.")
    print()

    print("2. Signal against how much freedom the text has")
    print("-" * 68)
    print(f"  {'freedom':>8}  {'green rate':>10}  {'z':>7}  {'p':>10}  {'tokens for 95%':>15}")
    for freedom in (0.15, 0.35, 0.6, 1.0, 1.6):
        tokens = generate(400, freedom=freedom, watermarked=True, salt=int(freedom * 100))
        result = detector.score(tokens)
        try:
            need = f"{tokens_for_power(result.green_fraction, gamma, 4.0, 0.95):,}"
        except ValueError:
            need = "no verdict, ever"
        print(f"  {freedom:>8.2f}  {result.green_fraction:>9.1%}  {result.z:>7.2f}  "
              f"{result.p_value:>10.2g}  {need:>15}")
    print()
    print("  Low freedom is the formulaic, factual or heavily-constrained case:")
    print("  fewer real choices per token, so fewer places to put a mark. It is")
    print("  the same reason Anthropic reports its own detection is sparser on")
    print("  factual passages and negligible on functional code.")
    print()

    print("3. Length, at the WEAKEST setting that still carries a signal")
    print("-" * 68)
    print("  Deliberately not the best case. The length question only matters")
    print("  where the answer is close, and the strong cases clear any")
    print("  threshold in a couple of dozen tokens.")
    best = generate(1600, freedom=0.6, watermarked=True, salt=60)
    rate = detector.score(best).green_fraction
    print(f"  measured green rate {rate:.1%} (chance {gamma:.0%})")
    print(f"  {'tokens':>8}  {'z':>7}  {'verdict at z>=4':>17}")
    for n in (25, 50, 100, 200, 400, 800, 1600):
        r = detector.score(best[: n + 1])
        print(f"  {n:>8}  {r.z:>7.2f}  {r.verdict():>17}")
    print()
    print(f"  average passage clears z=4 at  {tokens_needed(rate, gamma, 4.0):>5,} tokens")
    print(f"  95% of passages clear it at    {tokens_for_power(rate, gamma, 4.0, 0.95):>5,} tokens")
    print()
    print("  Those two numbers are why 'how long does the text need to be' has")
    print("  no single answer. At the first one, half the watermarked text you")
    print("  care about still comes back as no verdict.")
    print()
    print("Everything above is measured by this run, on this stand-in. It is NOT")
    print("a measurement of any commercial model, and the numbers are not")
    print("transferable to one. Run significance.py against a green rate you")
    print("measured yourself.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""How many tokens a verdict needs.

The watermarker is the easy half. The half that decides whether any of this is
usable is statistical: a keyed green list leaves a signal per token, and a
short enough passage does not carry enough of it to distinguish from chance no
matter how good the scheme is.

    python significance.py --help

Three questions it answers, all from the same one-proportion test that
`kgw.Detector` scores with:

    tokens-needed   given an observed green rate, how long must the text be
                    before the verdict clears a chosen z (or a chosen
                    false-positive rate)?
    false-positive  what is the chance that unwatermarked text reaches this z
                    on its own — per document, and across a corpus?
    power           at this length and this green rate, how often does a real
                    watermark actually get caught?

Stdlib only.

A note on where the numbers come from. The green rate you feed this is the
thing that varies: it depends on delta, on the model, and above all on how
much freedom the text leaves. A passage with one defensible next word at every
step gets no watermark at any delta, which is the same reason Anthropic states
detection is sparser on factual passages and negligible on functional code.
Measure your own rate with `demo_synthetic.py` or `demo_hf.py` and put THAT
number in here. There is no universal green rate and this file does not invent
one.
"""

from __future__ import annotations

import argparse
import math
import sys

from kgw import DEFAULT_GAMMA, normal_sf


def z_for_false_positive(alpha: float) -> float:
    """The z threshold whose one-sided tail is `alpha`.

    Inverted by bisection rather than by an erfc-inverse approximation: the
    interesting alphas here are 1e-5 and smaller, where a rational
    approximation's error is a larger share of the answer than anyone would
    accept in a number used to accuse somebody.
    """
    if not 0.0 < alpha < 0.5:
        raise ValueError("alpha must be in (0, 0.5)")
    lo, hi = 0.0, 40.0
    for _ in range(200):
        mid = (lo + hi) / 2.0
        if normal_sf(mid) > alpha:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


def tokens_needed(green_rate: float, gamma: float = DEFAULT_GAMMA, z_target: float = 4.0) -> int:
    """Smallest T whose EXPECTED z reaches `z_target` at this green rate.

        z = (p - gamma) * T / sqrt(T * gamma * (1-gamma))
          = (p - gamma) * sqrt(T) / sqrt(gamma * (1-gamma))

    so   T = z_target^2 * gamma * (1-gamma) / (p - gamma)^2.

    This is the length at which the AVERAGE watermarked passage clears the
    threshold, which means roughly half of them still miss it. For a length
    that catches a stated share of passages, use `tokens_for_power`.
    """
    if not 0.0 < gamma < 1.0:
        raise ValueError("gamma must be in (0, 1)")
    if green_rate <= gamma:
        raise ValueError(
            f"green rate {green_rate:.3f} is at or below chance ({gamma:.3f}) — "
            "no length of text produces a verdict, because there is no signal"
        )
    t = (z_target ** 2) * gamma * (1.0 - gamma) / ((green_rate - gamma) ** 2)
    return int(math.ceil(t))


def tokens_for_power(
    green_rate: float,
    gamma: float = DEFAULT_GAMMA,
    z_target: float = 4.0,
    power: float = 0.95,
) -> int:
    """Smallest T that catches `power` of watermarked passages.

    The count of green hits is Binomial(T, p) with sd sqrt(T*p*(1-p)); the
    threshold sits at gamma*T + z*sqrt(T*gamma*(1-gamma)). Requiring the
    observed count to clear it `power` of the time gives the usual two-sd
    sample-size form:

        sqrt(T) >= [ z*sqrt(gamma(1-gamma)) + z_power*sqrt(p(1-p)) ] / (p - gamma)
    """
    if green_rate <= gamma:
        raise ValueError("green rate is at or below chance — no length suffices")
    z_power = z_for_false_positive(1.0 - power)
    num = z_target * math.sqrt(gamma * (1 - gamma)) + z_power * math.sqrt(green_rate * (1 - green_rate))
    return int(math.ceil((num / (green_rate - gamma)) ** 2))


def expected_z(tokens: int, green_rate: float, gamma: float = DEFAULT_GAMMA) -> float:
    """The z a passage of this length averages at this green rate."""
    if tokens <= 0:
        return 0.0
    return (green_rate - gamma) * math.sqrt(tokens) / math.sqrt(gamma * (1 - gamma))


def detection_power(
    tokens: int,
    green_rate: float,
    gamma: float = DEFAULT_GAMMA,
    z_target: float = 4.0,
) -> float:
    """Share of watermarked passages of this length that clear `z_target`."""
    if tokens <= 0 or green_rate <= gamma:
        return 0.0
    threshold = gamma * tokens + z_target * math.sqrt(tokens * gamma * (1 - gamma))
    sd = math.sqrt(tokens * green_rate * (1 - green_rate))
    if sd == 0:
        return 1.0 if green_rate * tokens >= threshold else 0.0
    return normal_sf((threshold - green_rate * tokens) / sd)


def corpus_false_positives(z_target: float, documents: int) -> tuple[float, float]:
    """(per-document rate, expected count) of clean documents flagged.

    The number that actually matters and the one that gets left out. A z of 4
    is a per-document false-positive rate of about 3 in 100,000 — run it over a
    million documents and roughly 32 innocent ones get flagged. A threshold is
    only strict relative to how many times you pull it.
    """
    alpha = normal_sf(z_target)
    return alpha, alpha * documents


# --------------------------------------------------------------------------


def _cmd_tokens(args: argparse.Namespace) -> int:
    z_target = args.z if args.alpha is None else z_for_false_positive(args.alpha)
    half = tokens_needed(args.green_rate, args.gamma, z_target)
    reliable = tokens_for_power(args.green_rate, args.gamma, z_target, args.power)
    alpha, _ = corpus_false_positives(z_target, 1)

    print(f"green rate      {args.green_rate:.1%}   (chance is gamma = {args.gamma:.1%})")
    print(f"threshold       z >= {z_target:.2f}   false positive {alpha:.3g} per document")
    print()
    print(f"{half:>7} tokens   the average passage reaches the threshold")
    print(f"{reliable:>7} tokens   {args.power:.0%} of passages reach it")
    print()
    print("The first number is the one usually quoted and the second is the one")
    print("to design against: at the first length, half the watermarked text")
    print("you care about still comes back as no verdict.")
    return 0


def _cmd_curve(args: argparse.Namespace) -> int:
    z_target = args.z if args.alpha is None else z_for_false_positive(args.alpha)
    print(f"green rate {args.green_rate:.1%}, gamma {args.gamma:.1%}, threshold z >= {z_target:.2f}")
    print()
    print(f"{'tokens':>8}  {'expected z':>10}  {'caught':>7}")
    for t in args.lengths:
        print(f"{t:>8}  {expected_z(t, args.green_rate, args.gamma):>10.2f}  "
              f"{detection_power(t, args.green_rate, args.gamma, z_target):>6.1%}")
    return 0


def _cmd_fp(args: argparse.Namespace) -> int:
    alpha, count = corpus_false_positives(args.z, args.documents)
    print(f"threshold        z >= {args.z:.2f}")
    print(f"per document     {alpha:.3g}  (1 in {1/alpha:,.0f})")
    print(f"over {args.documents:,} docs  {count:,.1f} clean documents flagged")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--gamma", type=float, default=DEFAULT_GAMMA, help="green-list fraction (default 0.25)")
    common.add_argument("--z", type=float, default=4.0, help="z threshold for a verdict (default 4.0)")
    common.add_argument("--alpha", type=float, default=None,
                        help="target false-positive rate per document; overrides --z")

    p = sub.add_parser("tokens", parents=[common], help="how many tokens a verdict needs")
    p.add_argument("green_rate", type=float, help="observed green fraction, e.g. 0.42 — measure it, do not guess")
    p.add_argument("--power", type=float, default=0.95, help="share of passages that must be caught (default 0.95)")
    p.set_defaults(func=_cmd_tokens)

    p = sub.add_parser("curve", parents=[common], help="expected z and catch rate across lengths")
    p.add_argument("green_rate", type=float)
    p.add_argument("--lengths", type=int, nargs="+", default=[25, 50, 100, 200, 400, 800, 1600])
    p.set_defaults(func=_cmd_curve)

    p = sub.add_parser("false-positives", help="what a threshold costs across a corpus")
    p.add_argument("--z", type=float, default=4.0)
    p.add_argument("--documents", type=int, default=1_000_000)
    p.set_defaults(func=_cmd_fp)

    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

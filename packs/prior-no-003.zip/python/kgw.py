"""KGW text watermarking — the published academic scheme, implemented in full.

    Kirchenbauer, Geiping, Wen, Katz, Miers and Goldstein,
    "A Watermark for Large Language Models", ICML 2023, arXiv:2301.10226.

THIS IS NOT ANTHROPIC'S SCHEME. Anthropic has not published the scheme behind
Claude's text watermark, and its own write-up describes something different in
kind: it says the secret key changes the SOURCE OF THE RANDOMNESS used to pick
between candidate words, and is explicit that Claude is not pushed toward
particular words. KGW does the opposite — it adds a fixed bias `delta` to the
logits of a keyed "green list", which does shift the distribution. Anything you
read that draws a green-list / red-list diagram and labels it "how Claude works"
is inferring, not quoting. See the README.

Stdlib only. No numpy, no torch, no network. The `LogitsProcessor` at the bottom
is the one place this touches an ML framework, and it is optional.

The scheme, end to end:

    generation, at every step t
        seed  <- H(key, token[t-1])            a "left hash", h = 1 in the paper
        green <- a pseudo-random gamma-fraction of the vocabulary, from that seed
        logits[green] += delta
        sample as normal

    detection, over T scored tokens
        recompute each step's green list from the key and the PRECEDING token
        count the hits |s|_G
        z = (|s|_G - gamma*T) / sqrt(T * gamma * (1 - gamma))
        p = one-sided tail of the standard normal at z

The null hypothesis is "this text was written without the key", under which each
token lands in its green list with probability gamma independently, so the count
is Binomial(T, gamma) and z is standard normal for T of any useful size. A high z
means the text hits its green lists far more often than chance allows.
"""

from __future__ import annotations

import hashlib
import math
import secrets
from dataclasses import dataclass, field
from typing import Iterable, Sequence

__all__ = [
    "GreenList",
    "Watermarker",
    "Detector",
    "DetectionResult",
    "new_key",
    "WatermarkLogitsProcessor",
]

# The paper's defaults, and the ones every number in the README was measured at.
DEFAULT_GAMMA = 0.25   # fraction of the vocabulary that is green at each step
DEFAULT_DELTA = 2.0    # logit bonus added to green tokens


def new_key() -> str:
    """A fresh 256-bit secret key, hex encoded.

    THIS PACK'S KEY IS YOUR OWN. It has nothing to do with any key held by any
    model provider: a watermark keyed here is detectable here and nowhere else,
    and text from a commercial model is not detectable with it. That is the
    whole point of a keyed scheme, and it is also why "can I check whether
    Claude wrote this?" is not a question this code can answer.
    """
    return secrets.token_hex(32)


# --------------------------------------------------------------------------
# the green list
# --------------------------------------------------------------------------


@dataclass
class GreenList:
    """Derives the keyed green list for a step.

    The list is a pure function of (key, previous token, vocabulary size), so
    the detector reconstructs exactly what the generator used without ever
    seeing the generator's state. That is the only reason detection works.

    `hash_scheme` is the paper's h. h=1 ("left hash") seeds from the single
    preceding token and is what this pack uses everywhere. A larger h seeds from
    the last h tokens, which is harder to attack by editing one word at a time
    and weaker on short or repetitive text.
    """

    key: str
    vocab_size: int
    gamma: float = DEFAULT_GAMMA
    hash_scheme: int = 1

    def __post_init__(self) -> None:
        if not 0.0 < self.gamma < 1.0:
            raise ValueError(f"gamma must be in (0, 1), got {self.gamma}")
        if self.vocab_size < 2:
            raise ValueError("vocab_size must be at least 2")
        if self.hash_scheme < 1:
            raise ValueError("hash_scheme (h) must be at least 1")
        self._key_bytes = bytes.fromhex(self.key) if _is_hex(self.key) else self.key.encode()

    @property
    def size(self) -> int:
        """How many tokens are green at each step. At least 1, so gamma is never
        rounded away to an empty list on a small vocabulary."""
        return max(1, int(round(self.gamma * self.vocab_size)))

    def seed(self, context: Sequence[int]) -> int:
        """Seed for the step that FOLLOWS `context`.

        Only the last `hash_scheme` tokens are used. A step with too little
        context to hash (the very first token of a text) has no green list and
        is not scored — see `Detector.score`.
        """
        window = tuple(context[-self.hash_scheme:])
        payload = self._key_bytes + b"|" + b",".join(str(t).encode() for t in window)
        return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big")

    def members(self, context: Sequence[int]) -> set[int]:
        """The green token ids for the step following `context`.

        A partial Fisher-Yates shuffle: it draws exactly `size` distinct ids
        uniformly at random from the vocabulary, in O(size) rather than O(V),
        which matters because this runs once per generated token AND once per
        scored token. Same seed always gives the same set, on any machine, in
        any Python 3 — the PRNG is written out here rather than taken from
        `random`, whose internals are not a stability guarantee.
        """
        rng = _Splitmix64(self.seed(context))
        n = self.vocab_size
        swapped: dict[int, int] = {}
        out: set[int] = set()
        for i in range(self.size):
            j = i + rng.below(n - i)
            out.add(swapped.get(j, j))
            swapped[j] = swapped.get(i, i)
        return out

    def contains(self, context: Sequence[int], token: int) -> bool:
        return token in self.members(context)


class _Splitmix64:
    """A small, fully specified PRNG so the green list is reproducible forever.

    Deliberately not `random.Random`: its stream is an implementation detail of
    CPython, and a detector that disagrees with its generator by one shuffle is
    a detector that reports chance on its own watermark.
    """

    _MASK = (1 << 64) - 1

    def __init__(self, seed: int) -> None:
        self._s = seed & self._MASK

    def next(self) -> int:
        self._s = (self._s + 0x9E3779B97F4A7C15) & self._MASK
        z = self._s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & self._MASK
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & self._MASK
        return z ^ (z >> 31)

    def below(self, n: int) -> int:
        """Uniform in [0, n) with rejection sampling — the modulo shortcut
        skews the low ids, and the low ids are token ids."""
        if n <= 0:
            raise ValueError("n must be positive")
        limit = ((1 << 64) // n) * n
        while True:
            r = self.next()
            if r < limit:
                return r % n


def _is_hex(s: str) -> bool:
    try:
        bytes.fromhex(s)
    except ValueError:
        return False
    return len(s) % 2 == 0 and len(s) > 0


# --------------------------------------------------------------------------
# generation
# --------------------------------------------------------------------------


@dataclass
class Watermarker:
    """Applies the keyed green-list bias to a step's scores.

    Model-agnostic on purpose: it takes a list of logits and returns a list of
    logits. Wire it to whatever produces them.
    """

    key: str
    vocab_size: int
    gamma: float = DEFAULT_GAMMA
    delta: float = DEFAULT_DELTA
    hash_scheme: int = 1
    _green: GreenList = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._green = GreenList(self.key, self.vocab_size, self.gamma, self.hash_scheme)

    def bias(self, logits: Sequence[float], context: Sequence[int]) -> list[float]:
        """`logits` for the next token, `context` the tokens generated so far.

        With too little context to hash, the step is left alone — an unbiased
        step is honest, where hashing a padded context would put a bias on a
        step the detector cannot reproduce.
        """
        out = list(logits)
        if len(context) < self.hash_scheme:
            return out
        for token_id in self._green.members(context):
            if token_id < len(out):
                out[token_id] += self.delta
        return out

    def green_ids(self, context: Sequence[int]) -> set[int]:
        return self._green.members(context)


# --------------------------------------------------------------------------
# detection
# --------------------------------------------------------------------------


@dataclass
class DetectionResult:
    """What a detector can honestly say about one piece of text."""

    tokens_scored: int
    green_hits: int
    gamma: float
    z: float
    p_value: float

    @property
    def green_fraction(self) -> float:
        return self.green_hits / self.tokens_scored if self.tokens_scored else 0.0

    def verdict(self, z_threshold: float = 4.0) -> str:
        """A word, not a probability, for the common case.

        The threshold is a policy choice and belongs to whoever is accusing
        somebody of something. z >= 4.0 is the paper's conservative setting and
        corresponds to a false-positive rate around 3 in 100,000 per document
        under the null — `significance.py` computes it exactly for any z.
        """
        if self.tokens_scored == 0:
            return "no verdict — nothing scorable"
        return "watermark detected" if self.z >= z_threshold else "no watermark detected"

    def __str__(self) -> str:
        return (
            f"{self.green_hits}/{self.tokens_scored} green "
            f"({self.green_fraction:.1%}, chance is {self.gamma:.1%})  "
            f"z = {self.z:.2f}  p = {self.p_value:.3g}"
        )


@dataclass
class Detector:
    """Scores a token sequence against the key that may have generated it."""

    key: str
    vocab_size: int
    gamma: float = DEFAULT_GAMMA
    hash_scheme: int = 1
    _green: GreenList = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._green = GreenList(self.key, self.vocab_size, self.gamma, self.hash_scheme)

    def score(self, tokens: Sequence[int]) -> DetectionResult:
        """The first `hash_scheme` tokens have no context to hash and are not
        scored — counting them as red would drag z down on short texts, which
        are already the case where this scheme is weakest."""
        hits = 0
        scored = 0
        for i in range(self.hash_scheme, len(tokens)):
            context = tokens[max(0, i - self.hash_scheme):i]
            scored += 1
            if self._green.contains(context, tokens[i]):
                hits += 1
        return DetectionResult(scored, hits, self.gamma, *z_and_p(hits, scored, self.gamma))


def z_and_p(green_hits: int, tokens_scored: int, gamma: float) -> tuple[float, float]:
    """The one-proportion z test the paper uses, and its one-sided p-value.

        z = (hits - gamma*T) / sqrt(T * gamma * (1 - gamma))

    One-sided because only an EXCESS of green tokens is evidence of a
    watermark; a deficit is just unusual text.
    """
    if tokens_scored <= 0:
        return 0.0, 1.0
    expected = gamma * tokens_scored
    sd = math.sqrt(tokens_scored * gamma * (1.0 - gamma))
    z = (green_hits - expected) / sd if sd > 0 else 0.0
    return z, normal_sf(z)


def normal_sf(z: float) -> float:
    """P(Z > z) for a standard normal, via the stdlib's erfc.

    erfc rather than 1 - cdf: at the z values that matter here (4 and up) the
    complement of a number very close to 1 loses every digit that carries the
    answer.
    """
    return 0.5 * math.erfc(z / math.sqrt(2.0))


# --------------------------------------------------------------------------
# optional: drop straight into a Hugging Face `model.generate()`
# --------------------------------------------------------------------------


class WatermarkLogitsProcessor:
    """A `transformers` LogitsProcessor wrapping `Watermarker`.

    Kept import-free so this module still loads with no ML stack installed —
    torch is imported inside `__call__`, which only runs if you are already
    running a model. Usage is in demo_hf.py.
    """

    def __init__(self, watermarker: Watermarker) -> None:
        self.wm = watermarker

    def __call__(self, input_ids, scores):  # pragma: no cover - needs torch
        import torch

        for batch in range(scores.shape[0]):
            context = input_ids[batch].tolist()
            if len(context) < self.wm.hash_scheme:
                continue
            green = sorted(self.wm.green_ids(context))
            index = torch.tensor(green, device=scores.device, dtype=torch.long)
            scores[batch].index_add_(
                0, index, torch.full((len(green),), self.wm.delta, device=scores.device, dtype=scores.dtype)
            )
        return scores


def scored_positions(tokens: Sequence[int], hash_scheme: int = 1) -> Iterable[int]:
    """Which positions a detector will actually score. Useful when you want to
    highlight the green hits in rendered text rather than just count them."""
    return range(hash_scheme, len(tokens))

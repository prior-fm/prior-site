# Prior — No. 003 · The watermark is in the choosing

A working text watermarker, its detector, and the calculator that tells you
whether a verdict means anything. Python, standard library only, no downloads.

    cd python
    python demo_synthetic.py

## Read this before anything else

**This is the published academic scheme. It is not Claude's.**

The code here implements **KGW** — Kirchenbauer, Geiping, Wen, Katz, Miers and
Goldstein, *"A Watermark for Large Language Models"*, ICML 2023
([arXiv:2301.10226](https://arxiv.org/abs/2301.10226)). It is the scheme every
green-list / red-list diagram on the internet is drawing, it is well understood,
and it is a genuinely good thing to have working code for.

**Anthropic has not published the scheme behind Claude's text watermark.** Its
own write-up describes something different in kind. In Anthropic's description,
what the secret key changes is the **source of the randomness** used to choose
between candidate words — and it is explicit that Claude is *not* pushed toward
particular words or unusual synonyms. KGW does the opposite: it adds a fixed
bonus to the scores of a keyed "green list", which does move the model's
choices.

Those are not two ways of saying the same thing. A keyed randomness source is
the description of a *distortion-free* scheme, where the distribution of the
output is left exactly as it was. KGW is a *biased* scheme. Both put a
detectable signal in the text; they differ on whether the text you get back is
the text you would have got anyway.

So, plainly:

- If you want to understand how text watermarking works, this code is a correct,
  complete, runnable example, and the statistics at the end of it are the same
  statistics any scheme in this family has to live with.
- If you want to know exactly what Anthropic does — **nobody outside Anthropic
  does**, and anyone showing you a green-list diagram captioned "how Claude
  works" has inferred it from a paper about a different scheme.
- This code **cannot tell you whether Claude wrote something.** Detection needs
  the key that generated the text. The key in this pack is this pack's own.

The film says the same thing and it is the reason it exists.

## What's here

    python/kgw.py               the watermarker and the detector
    python/significance.py      how many tokens a verdict needs
    python/demo_synthetic.py    end to end, no dependencies, no model
    python/demo_hf.py           the same code against GPT-2, for real English

## The watermarker

At every step the model produces a score for each token in its vocabulary. KGW
inserts one operation before sampling:

    seed  <- hash(secret key, the preceding token)
    green <- a pseudo-random 25% of the vocabulary, drawn from that seed
    scores[green] += 2.0
    sample as normal

Nothing is added to the text. No characters, no tokens, no metadata. The output
is the same length and the same shape it would have been; what changed is which
of several acceptable words got picked.

```python
from kgw import Watermarker, Detector, new_key

key = new_key()                              # your key. Keep it.
wm  = Watermarker(key, vocab_size=32000)
biased = wm.bias(logits, tokens_so_far)      # drop into any sampling loop

Detector(key, vocab_size=32000).score(tokens)
# 162/400 green (40.5%, chance is 25.0%)  z = 7.16  p = 4.06e-13
```

## The detector, and why it returns a probability

The detector recomputes each step's green list from the key and the preceding
token, counts how many of the text's tokens landed in their own green list, and
runs one proportion test:

    z = (hits - 0.25 * T) / sqrt(T * 0.25 * 0.75)

Under the null hypothesis — text written without the key — each token lands
green with probability 0.25 independently, so a high z means the text is hitting
its keyed lists far more often than chance permits.

**It never returns "yes".** It returns a z and a p-value, and somebody has to
choose a threshold. That choice is the entire ethical content of the tool, which
is why `significance.py` exists as a separate file rather than a constant.

## The significance calculator

    python significance.py tokens 0.42
    python significance.py curve 0.32
    python significance.py false-positives --z 4.0 --documents 1000000

Three questions, all from that same test.

**How long does the text have to be?** Measured by `significance.py` in this
session, at a 42% green rate against a 25% chance rate and a z ≥ 4 threshold:
**104 tokens** for the average passage to clear the bar, and **224 tokens** for
95% of passages to clear it. Those two numbers are the point. At the first one,
half the watermarked text you care about still comes back as no verdict, and the
first is the number that usually gets quoted.

**What does the threshold cost?** Also measured this session: z ≥ 4 is a
false-positive rate of **3.17 × 10⁻⁵** per document — about **1 in 31,600**.
Which sounds decisive until you run it over a million documents and flag
**31.7** innocent ones. A threshold is only as strict as the number of times you
pull it.

**When is there no signal at all?** `demo_synthetic.py` sweeps it. Measured on
this pack's stand-in sampler, 400 tokens per run, at δ = 2.0:

| freedom in the text | green rate | z | tokens for a 95% catch |
|---|---|---|---|
| very constrained | 20.2% | −2.19 | never |
| constrained | 22.2% | −1.27 | never |
| moderate | 32.0% | 3.23 | 1,275 |
| open | 42.5% | 8.08 | 212 |
| very open | 57.8% | 15.13 | 61 |

Those are measurements of the stand-in in `demo_synthetic.py`, not of any
commercial model, and they do not transfer to one. Measure your own rate and
feed *that* to `significance.py`.

The shape is what transfers. **A watermark can only live in a choice.** Text
with one defensible next word at every step — a formula, a quotation, a
function signature — carries no mark at any strength, and no length of it
produces a verdict. Anthropic reports the same limits for its own scheme:
weakest on short samples, sparser on factual passages, negligible on functional
code, and gone entirely if every word is replaced.

## Two things the coverage keeps getting wrong

Both are checkable against Anthropic's own write-up, and both are in the film.

**1. The probabilities are not nudged.** Anthropic says the key changes where
the randomness *comes from*, and says outright that Claude is not steered toward
particular words. The green-list picture, including the one this pack
implements, is a description of KGW.

**2. Translation keeps the watermark.** The common claim is that translating
text launders it. Anthropic states the opposite: a translation carries the mark,
because every word of the translation is itself a choice the model makes.

## Limits of this code

- It is a reference implementation, not a production one. `GreenList.members`
  runs a partial shuffle per token; fine for the demos, not for a serving path.
- `hash_scheme` (the paper's *h*) is 1 — each step is seeded from a single
  preceding token. Larger *h* resists word-level editing better and is weaker on
  short or repetitive text. The parameter is there; the trade-off is yours.
- The z test assumes tokens are independent under the null. Real text is not
  independent, and heavily repetitive text can inflate z on its own. Treat a
  borderline verdict on repetitive input with suspicion.
- No attack implementations. Paraphrasing, token-substitution and
  emoji-insertion attacks are all in the literature and none of them are here.

## Licence

MIT, like everything Prior ships. The scheme is the authors' — cite the paper,
not this repository.

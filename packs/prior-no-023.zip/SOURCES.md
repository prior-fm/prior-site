# Sources

Every time in the film is a published one. Prior measured nothing itself except the subtractions marked OUR COUNT on screen, which are the difference between two published times and are shown as such.

## The film's own sourcing note, verbatim

> Times as published by each government and reported by NKVC, MApN, IGSU, Kaitsevägi, LRT, LETA, ERR, Delfi, Raja.fi, AP and the US DoD. Routes are schematic.

## Where each of those appears

Seconds into the film at which a sourcing header naming it is first on screen. An outlet with no second listed is credited in the closing note but not in a header of its own.

- **NKVC** — 40.2s
- **MApN** — 53.9s, 124.9s
- **IGSU** — closing note only
- **Kaitsevägi** — 66.6s, 91.0s
- **LRT** — closing note only
- **LETA** — 71.4s
- **ERR** — 91.0s, 150.4s
- **Delfi** — 91.0s
- **Raja.fi** — 76.2s
- **AP** — 130.2s
- **the US DoD** — closing note only

## Every sourcing header, in order

The complete on-screen sourcing band, which is what `timeline.csv` holds as data.

- **0.8s — LITHUANIA · 15 SEP**  
  ≈ 00:00 OBSERVED → ≈ 00:20 SHOT · ARMED FORCES
- **7.1s — ROMANIA · 24 JUL**  
  83 MIN ON THE RADAR · OUR COUNT
- **18.0s — DOT: ONE MINUTE OF FLIGHT**  
  RINGS: WHERE IT CAME DOWN
- **28.8s — CLOCK: ONE MINUTE = 0.4 S OF FILM**  
  WHITE BAR: PUBLISHED TIME → SHOT
- **40.2s — LITHUANIA · 15 SEP · ARMED FORCES**  
  ≈ 00:00 OBSERVED, IN FROM BELARUS · NKVC
- **46.3s — ≈ 00:20 SHOT · ITALIAN EUROFIGHTERS, ŠIAULIAI**  
  EXPLOSIVE CHARGE, DEFUSED · R. KAUNAS
- **51.3s — ROMANIA · 24 JUL**  
  SULINA → BUZĂU
- **53.9s — 09:39 RADAR · E OF SULINA**  
  09:48 ITALIAN JETS · 10:56 ROMANIAN · MApN
- **58.4s — 11:02 SHOT · NEAR PADINA, BUZĂU**  
  83 MIN FROM RADAR · OUR COUNT
- **66.6s — ESTONIA · 19 MAY**  
  ≈ NOON ALERT → 12:14 SHOT · KAITSEVÄGI
- **71.4s — LATVIA · 8 JUN**  
  09:18 ALERT → 10:05 SHOT · 47 MIN · LETA
- **76.2s — FINLAND · 20 AUG · IL-20, CREWED**  
  ≈ 3 MIN INSIDE, SUSPECTED · NO SHOT · RAJA.FI
- **85.7s — THE GREY BAR: THE PHONES**  
  ALERT SENT → LIFTED
- **91.0s — 12:00 ALERT → 12:14 SHOT → ≈ 12:55 ALL-CLEAR**  
  KAITSEVÄGI, ERR, DELFI
- **99.1s — ROMANIA · 16 AUG**  
  04:44 RADAR → 05:01 SHOT · 17 MIN
- **103.4s — 05:08 RO-ALERT · GALAȚI, TULCEA**  
  'AFTER THE SHOT' · VIAȚA LIBERĂ
- **107.2s — SHOT 05:01, ALERT 05:08**  
  —
- **109.3s — D. MATULIONIS, PRESIDENTIAL ADVISER**  
  ŽINIŲ RADIJAS VIA BNS · REPORTED SPEECH
- **117.6s — RADAR → SHOT: 17 · 83 MIN**  
  FROM THE ALERT: ≈ 14 · 47 MIN
- **124.9s — 'UNPOPULATED AREA' · MApN**  
  'THAT IS WHY HE COULD FIRE' · N. DAN
- **130.2s — NORTH AMERICA · 28 JAN → 4 FEB 2023 · AP**  
  10,080 MIN SHOWN IN 8 S
- **136.6s — AUTHORISED WED 1 FEB · SHOT SAT 4 FEB · DoD**  
  SHOT OVER WATER: 'UNDUE RISK' OVER LAND
- **150.4s — ESTONIA · 19 MAY · ORIGIN 'LIKELY' UKRAINIAN · MIL.EE**  
  UKRAINE'S MINISTER APOLOGISED · ERR
- **155.7s — LATVIA · 14 AUG · UKRAINIAN, IN FROM BELARUS · NBS**  
  'MOST LIKELY' RUSSIAN ELECTRONIC WARFARE
- **161.4s — LITHUANIA · 15 SEP · R. KAUNAS**  
  REUTERS SOURCE: DEBRIS MAY BE RUSSIAN
- **166.1s — LAUNCHED FROM:**  
  NO GOVERNMENT HAS SAID

## What the film does not claim

Routes on the maps are schematic: they connect the places each government named, at one dot per minute of flight, and are not flight tracks. No government had published a launch point for the Lithuanian object at the time of the film, and the film says so on screen.

# License and asset boundary

The pack-authored files `README.md`, `SOURCES.md` and the accompanying pack manifest are released under the MIT License:

Copyright (c) 2026 Prior

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files, to deal in the software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the software, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

`timeline.csv`, `timeline.json` and `captions.txt` are a record of times and statements published by the governments and news organisations named in `SOURCES.md`. The facts themselves are not ours and are not licensed here; the arrangement is. Each outlet's own terms apply to its reporting. The pack does not include Printvetica, GSAP, the generated voice, the ambience bed, or the rendered film, so their separate licensing is outside this pack.

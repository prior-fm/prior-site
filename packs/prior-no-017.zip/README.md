# Prior — No. 017 · *Not a Transformer. A brain.*

A Transformer stops learning the moment training ends. **BDH — the Dragon
Hatchling — keeps learning while it thinks:** the synapses change during
inference, and nothing else changes at all. This is the network the film ran.
Not a re-implementation of it — the same script, with its output path moved.

```bash
pip install numpy      # the only dependency
python bdh.py          # the whole run: four stages, five gates, ~20s
```

Python 3.8+ and numpy. No installs beyond that, no network, no arguments
needed. Deterministic: fixed seed, float64, no wall clock — you get the film's
numbers, to the digit.

---

## What it does

It builds a BDH network of `N` neurons wired by a sparse, non-negative synaptic
graph, then runs it over a token sequence **with no training phase at all**.
Every step does the four things the film narrates, in this order:

| stage | what happens | in code |
|---|---|---|
| 1 · propagate | belief flows forward along weighted implications | `Wx + σᵀx + gain·u` |
| 2 · hebbian | connections that fired together strengthen | `σ ← λσ + η·x x'ᵀ` |
| 3 · compete | divisive inhibition, then a threshold at 55% of peak | `compete(drive)` |
| 4 · feedback | the survivors become the next step's input | `x ← x'` |

The graph is built the way BDH-GPU says it is *stored*: each neuron reads a few
of `R` circuits and writes to a few **other** circuits, so `W = E·Dᵀ` comes out
sparse, non-negative, and exactly rank ≤ `R` with no self-loops. That is what
makes the first gate a real test rather than a restatement of a definition.

The task is in-context associative recall. Twelve symbol pairs are shown as
consecutive tokens, six times over. Then each cue is shown alone, and on the
blank step that follows, the **fast-weight** term is read off. Nothing is
trained. The only thing that changed is σ, and it changed during inference.

## What it shows

Five gates run on every execution and the script prints `GATE: GO` only if all
five pass. Measured on this run, 2026-09-03:

- **512 neurons, 12,230 synapses** — 4.67% of the possible connections, mean
  degree 23.9, max 37. Measured rank of `W`: **192**, exactly the circuit
  count.
- **G1 · the two formulations agree to 7.8e−16.** The same run is computed
  twice: once as explicit per-edge message passing with a materialised 512×512
  fast-weight matrix (BDH), once as two low-rank matvecs with the fast weights
  held as a linear-attention state that is never materialised (BDH-GPU). They
  are the same machine. A transpose, an index slip, or a decay applied in the
  wrong order all fail this.
- **G2 · 4.41% of neurons fire on an average step**, and that sparsity is
  *caused* by inhibition, not assumed. The control run — same drive,
  competition removed — washes out to **99.2%** active. Two measurements the
  competing explanations predict differently, which is the only way one number
  proves anything.
- **G3 · modus ponens holds exactly.** For every step and every edge i→j with
  belief in i and a positive weight, the contribution to j is strictly positive
  — smallest seen across the whole run: 2.1e−05. Because `W ≥ 0`, belief can
  only ever be added, never cancelled.
- **G4 · the Hebbian sign pattern is exact.** σ increases on precisely the
  pairs that fired together and nowhere else.
- **G5 · recall is 38%, against a 4.88% chance baseline** — read off the fast
  weights, which grew from `‖σ‖ = 0` to 233.3 during inference. The same
  readout taken from the fixed synaptic graph alone scores **4.0%**, i.e. at
  chance. The association lives in what changed while the model was thinking,
  not in the wiring. That is what "it keeps learning during inference" has to
  mean to be worth saying.

## Try your own

Every knob is an environment variable, so you can break it and watch which
gate notices:

```bash
BDH_THETA=0.0 python bdh.py    # no inhibition:   G2 FAILS, 4.41% active -> 99.2%
BDH_ETA=0.0   python bdh.py    # no Hebbian rule: G4+G5 FAIL, recall 38% -> 8.0%
BDH_LAM=0.90  python bdh.py    # forget faster:   still GO, recall 38% -> 23%
BDH_R=64      python bdh.py    # fewer circuits:  12,230 synapses -> 35,598, rank 64
BDH_GAIN=1.0  python bdh.py    # drive the current token in more softly
```

Every arrow above is a run, not a prediction (measured 2026-09-03).
`BDH_THETA=0.0` is the instructive one: the network still runs, still
propagates, still writes to its synapses — and stops working, because 99.2% of
neurons firing at once carries no information to recall. Sparsity is not a
detail of this architecture, it is the architecture.

The issue page — film, cover, and this pack —
is at https://prior-fm.github.io/prior-site/no-017.html.

## The model, in one place

```
W          = E · Dᵀ                       sparse, non-negative, rank ≤ R, no self-loops
drive      = W x  +  σᵀ x  +  3·u         structural belief + fast weights + the token
g          = drive / mean(drive)
x'         = max(g − 0.55·max g, 0)       normalised to sum 1        (compete)
σ          ← 0.995·σ  +  15·x x'ᵀ         decay, then fire-together  (hebbian)
x          ← x'                           (feedback)
```

Six lines. No attention block, no backward pass, no weights to update. The
recall in G5 is produced entirely by the σ term, and σ exists only for the
duration of the run.

— Prior, @prior.fm

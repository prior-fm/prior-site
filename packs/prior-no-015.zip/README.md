# Prior — No. 015 · *Seventeen minutes*

The bridge-and-torch puzzle, solved for real and **proved minimal**.

```bash
python bridge.py                 # the film's four people: 1, 2, 5, 10
python bridge.py 1 2 5 10 15     # any group you like
python bridge.py --enumerate     # count every legal schedule
```

Python 3.8+. Standard library only — no installs, no network, no arguments needed.

---

## What it does

Four people must cross a bridge at night with one torch. Two can cross at a time,
and a crossing takes the **slower** person's time. Someone has to bring the torch
back. With times of 1, 2, 5 and 10 minutes, what is the fastest everyone gets across?

The intuitive answer — always send the fastest person back and forth to escort
everyone — costs **19 minutes**. The optimum is **17**, and the script proves it
three ways rather than asserting it:

| | |
|---|---|
| `replay()` | walks a schedule move by move and **refuses** to add a cost that the rules do not allow: one or two people, always on the torch's side, always the slower one's time, torch ending on the far bank. Both the 19 and the 17 are produced by this, not typed in. |
| `optimum()` | exhaustive shortest path (Dijkstra) over the full state graph — every subset of people on each bank, times two torch positions. This is not a heuristic; it searches everything reachable. |
| `closed_form()` | the classic recursive result, implemented **independently** of the search. If the two disagree the script exits non-zero. |
| `enumerate_all()` | counts every legal schedule. For 1, 2, 5, 10 there are **85,368** of them, and exactly **2** cost 17 minutes. |

Those are the numbers on screen in the film, and this is where they come from.

---

## The idea worth keeping

A crossing costs the **slower** person's time. So a slow person is only expensive
when they are the slowest one moving.

Escorting pays the 10 once and the 5 once — 15 minutes of slow — and buys cheap
returns. Sending 5 and 10 **together** pays the 10 once and the 5 **not at all**,
at the cost of one 2-minute return instead of a 1-minute one. That trade is worth
two minutes, and no arrangement does better.

It generalises: the fix is never "make the fastest thing faster". It is **reducing
how often the slowest constraint gets triggered** — batch the expensive work so it
is paid for once. Which is why this puzzle keeps turning up in scheduling,
in batch inference, and in anything with a straggler.

Try `python bridge.py 1 2 5 10 15 20` and watch the shuttle strategy take over.

---

## Files

| | |
|---|---|
| `bridge.py` | everything above, ~180 lines, stdlib only |
| `README.md` | this file |

Free with every issue. **[prior-fm.github.io/prior-site](https://prior-fm.github.io/prior-site/)**

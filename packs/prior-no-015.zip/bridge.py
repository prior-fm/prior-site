#!/usr/bin/env python3
"""Prior No. 015 - "Seventeen minutes".

The bridge-and-torch puzzle, solved for real and proved minimal.

    python bridge.py                 # the film's four people: 1, 2, 5, 10
    python bridge.py 1 2 5 10 15     # any group you like
    python bridge.py --enumerate     # count every legal schedule

Stdlib only. No arguments needed, no network, no dependencies.

WHAT THE FILM CLAIMS, AND WHERE EACH NUMBER COMES FROM

  19  the cost of the "always escort with the fastest person" schedule.
      Replayed step by step in `replay()`, which checks each move is legal
      before adding its cost.
  17  the true optimum. Found by exhaustive shortest-path search over the
      state graph in `optimum()`, and independently re-derived by the classic
      closed form in `closed_form()`. The two must agree or the script exits
      non-zero.
  85,368  the number of legal schedules the search is optimal against, and
      exactly 2 of them cost 17. Counted by `enumerate_all()`.

THE IDEA, IN ONE LINE: the cost of a crossing is the SLOWER person's time, so
a slow person is only expensive when they are the slowest one moving. Carrying
the two slowest together makes the 5 free.
"""
from __future__ import annotations

import heapq
import itertools
import sys


# --------------------------------------------------------------------- model
# A state is (frozenset of people still on the start bank, torch side).
# torch 0 = start bank, 1 = far bank.

def moves(state, n):
    """Every legal move from `state`. One or two people, always with the torch."""
    left, torch = state
    src = left if torch == 0 else frozenset(range(n)) - left
    for size in (1, 2):
        for grp in itertools.combinations(sorted(src), size):
            nl = (left - set(grp)) if torch == 0 else (left | set(grp))
            yield (frozenset(nl), 1 - torch), grp


def optimum(times):
    """Shortest total time, by Dijkstra over the state graph. Exhaustive."""
    n = len(times)
    start = (frozenset(range(n)), 0)
    goal = frozenset()
    dist = {start: 0}
    prev = {}
    pq = [(0, tuple(sorted(start[0])), start[1])]
    done = set()
    while pq:
        d, lt, torch = heapq.heappop(pq)
        s = (frozenset(lt), torch)
        if s in done:
            continue
        done.add(s)
        if s[0] == goal:
            return d, unwind(prev, s, times)
        for ns, grp in moves(s, n):
            nd = d + max(times[i] for i in grp)
            if nd < dist.get(ns, float("inf")):
                dist[ns] = nd
                prev[ns] = (s, grp)
                heapq.heappush(pq, (nd, tuple(sorted(ns[0])), ns[1]))
    raise SystemExit("no solution: is the torch capacity right?")


def unwind(prev, end, times):
    out, s = [], end
    while s in prev:
        p, grp = prev[s]
        out.append(([times[i] for i in grp], "cross" if p[1] == 0 else "return",
                    max(times[i] for i in grp)))
        s = p
    return out[::-1]


def closed_form(times):
    """The classic result, implemented INDEPENDENTLY of the search above.

    Take the two slowest off the group at a time. Either the fastest ferries
    them one by one (a + 2b + d, using the two fastest as a shuttle) or it
    escorts each (2a + c + d). Take the cheaper, recurse on what is left.
    """
    t = sorted(times)
    total = 0
    while len(t) > 3:
        a, b, c, d = t[0], t[1], t[-2], t[-1]
        total += min(a + 2 * b + d, 2 * a + c + d)
        t = t[:-2]
    return total + (sum(t) if len(t) == 3 else t[-1])


def replay(times, plan, label):
    """Walk a schedule, refusing to add a cost that a rule does not allow."""
    left, torch, total = set(times), 0, 0
    for i, (movers, direction) in enumerate(plan):
        src = left if torch == 0 else set(times) - left
        assert 1 <= len(movers) <= 2, f"{label} step {i}: {len(movers)} people"
        assert set(movers) <= src, f"{label} step {i}: {movers} are not with the torch"
        assert (direction == "cross") == (torch == 0), f"{label} step {i}: wrong way"
        cost = max(movers)
        total += cost
        if torch == 0:
            left -= set(movers)
        else:
            left |= set(movers)
        torch = 1 - torch
        print(f"    {'+'.join(map(str, movers)):>6} {direction:<7}{cost:>4} min"
              f"   running {total:>3}")
    assert not left, f"{label}: somebody is still on the near bank"
    assert torch == 1, f"{label}: the torch ended on the wrong bank"
    return total


def enumerate_all(times, cap=40, max_depth=12):
    """Count every legal schedule and its cost. Exponential - four people only."""
    from collections import Counter
    n = len(times)
    counts = Counter()

    def walk(state, total, depth):
        if total > cap or depth > max_depth:
            return
        if not state[0]:
            counts[total] += 1
            return
        for ns, grp in moves(state, n):
            walk(ns, total + max(times[i] for i in grp), depth + 1)

    walk((frozenset(range(n)), 0), 0, 0)
    return counts


# ---------------------------------------------------------------------- main
def main(argv):
    enum = "--enumerate" in argv
    argv = [a for a in argv if not a.startswith("--")]
    times = [int(a) for a in argv] if argv else [1, 2, 5, 10]
    print(f"people: {times}\n")

    if times == [1, 2, 5, 10]:
        print("  the schedule that feels right - escort everyone with the fastest:")
        naive = replay(times, [([1, 10], "cross"), ([1], "return"),
                               ([1, 5], "cross"), ([1], "return"),
                               ([1, 2], "cross")], "naive")
        print(f"    -> {naive} minutes\n")

    best, plan = optimum(times)
    print("  the optimum, found by exhaustive search:")
    total = replay(times, [(m, d) for m, d, _ in plan], "optimal")
    print(f"    -> {total} minutes\n")

    cf = closed_form(times)
    print(f"  cross-check, closed form:  {cf} minutes")
    if cf != best:
        print("  MISMATCH - the search and the closed form disagree.")
        return 1
    print("  the two agree.\n")

    if enum or times == [1, 2, 5, 10]:
        counts = enumerate_all(times)
        n_all = sum(counts.values())
        print(f"  legal schedules found: {n_all:,}")
        print(f"  schedules that achieve {best}: {counts[best]}")
        print(f"  worst found: {max(counts)} minutes")
        print("\n  cost   how many schedules")
        for k in sorted(counts):
            print(f"  {k:>4}   {counts[k]:>7,}  {'#' * min(48, counts[k] // 260)}")

    print("\n  Why it works: a crossing costs the SLOWER person's time, so a slow")
    print("  person is only expensive when they are the slowest one moving.")
    print("  Send 5 and 10 together and the 5 costs nothing at all.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

# The papers behind No. 011

Seven papers. Every citation below — volume, pages, DOI — was checked against
the publisher's own record while this pack was assembled, not quoted from
memory. Where a free copy is hosted by the journal or by one of the authors,
the link is given; otherwise the DOI resolves to the publisher.

They are in the order that makes sense to read them, not chronological order.

---

## 1. Start here — the one that started it

**Lorenz, E. N. (1963). "Deterministic Nonperiodic Flow."**
*Journal of the Atmospheric Sciences* **20**(2), 130–141.
Free from the journal:
<https://journals.ametsoc.org/view/journals/atsc/20/2/1520-0469_1963_020_0130_dnf_2_0_co_2.xml>

Lorenz was modelling convection with twelve equations, cut it down to three,
and found that the three still would not settle. Restarting a run from
printed output rounded to three decimals instead of the machine's six gave a
completely different forecast. That accident is the origin of the whole field.

**Why it matters if you build things.** This is the cleanest statement anywhere
of the thing that bites you: a system can be fully deterministic, have no noise
term at all, and still be unpredictable in practice, because the error you
cannot avoid — rounding, measurement, a different BLAS — grows exponentially.
It is short and it is readable. If you read one, read this.

---

## 2. The one that is literally this film

**Shinbrot, T., Grebogi, C., Wisdom, J., & Yorke, J. A. (1992).
"Chaos in a double pendulum."**
*American Journal of Physics* **60**(6), 491–499. DOI
[10.1119/1.16860](https://doi.org/10.1119/1.16860)
Author's copy:
<https://yorke.umd.edu/Yorke_papers_most_cited_and_post2000/1992-04-Wisdom_Shinbrot_AmerJPhys_double_pendulum.pdf>

They built a real double pendulum, released it repeatedly from as close to the
same position as they could manage, and measured how fast the trajectories came
apart. Not a simulation — an actual object on a bench, with the divergence
measured against the theory.

**Why it matters.** It closes the loop between the equations in `chaos.py` and
a physical thing you could hold. It also shows how you *measure* sensitivity
experimentally rather than asserting it, which is the honest version of what
this issue's film claims.

---

## 3. The one that named it

**Li, T.-Y., & Yorke, J. A. (1975). "Period Three Implies Chaos."**
*The American Mathematical Monthly* **82**(10), 985–992. DOI
[10.2307/2318254](https://doi.org/10.2307/2318254)

The paper that put the word "chaos" into mathematics. The result is startling
for how little it assumes: if a continuous map of an interval to itself has
even one point of period three, it has points of *every* period, and an
uncountable set of points that never settle into any cycle at all.

**Why it matters.** It is the counterexample to "complicated behaviour needs a
complicated model". One dimension, one continuous function, one period-three
orbit, and you are done.

---

## 4. The one that made it everybody's problem

**May, R. M. (1976). "Simple mathematical models with very complicated
dynamics."** *Nature* **261**, 459–467. DOI
[10.1038/261459a0](https://doi.org/10.1038/261459a0)

May took `x → rx(1−x)` — a population model a school student can follow — and
showed it goes from a stable point, to a two-cycle, to a four-cycle, to
everything, as one parameter increases. Then he argued, in *Nature*, that
people in every quantitative field should be taught this.

**Why it matters.** It is the best twenty minutes you can spend on the idea
that model complexity and behavioural complexity are unrelated. Also the
origin of most people's first encounter with the bifurcation diagram.

---

## 5. The one with the number in it

**Feigenbaum, M. J. (1978). "Quantitative universality for a class of
nonlinear transformations."** *Journal of Statistical Physics* **19**(1),
25–52. DOI [10.1007/BF01020332](https://doi.org/10.1007/BF01020332)

The period-doublings in May's map do not just happen — they happen at a
shrinking rate that converges to a specific constant, δ ≈ 4.669. And the same
constant turns up in completely unrelated systems with the same qualitative
shape.

**Why it matters.** This is where chaos stops being a collection of curiosities
and becomes a theory with universal constants, the way physics has. It is the
hardest read on this list; the first eight pages carry the idea.

---

## 6. The one you would actually use

**Wolf, A., Swift, J. B., Swinney, H. L., & Vastano, J. A. (1985).
"Determining Lyapunov exponents from a time series."**
*Physica D: Nonlinear Phenomena* **16**(3), 285–317. DOI
[10.1016/0167-2789(85)90011-9](https://doi.org/10.1016/0167-2789(85)90011-9)

Sensitivity is quantified by the Lyapunov exponent λ: nearby states separate
like e^(λt). This paper is the standard method for estimating λ from observed
data, when you do not have the equations — which is the situation you are
normally in.

**Why it matters.** It turns "this system is chaotic" from an adjective into a
number you can compute from a log file. `chaos.py` fits λ the easy way, because
it has the equations; this paper is what you reach for when you don't.

---

## 7. The one that says how long you get

**Zhang, F., Sun, Y. Q., Magnusson, L., Buizza, R., Lin, S.-J., Chen, J.-H., &
Emanuel, K. (2019). "What Is the Predictability Limit of Midlatitude
Weather?"** *Journal of the Atmospheric Sciences* **76**(4), 1077–1091. DOI
[10.1175/JAS-D-18-0269.1](https://doi.org/10.1175/JAS-D-18-0269.1)
Free from the journal:
<https://journals.ametsoc.org/view/journals/atsc/76/4/jas-d-18-0269.1.xml>

Fifty-six years after Lorenz, with modern models and near-perfect initial
conditions, how far ahead can midlatitude weather be forecast at all? Their
answer is a hard ceiling of roughly two weeks — not a funding problem or a
resolution problem, a property of the atmosphere.

**Why it matters.** It is the clearest modern demonstration that some limits
are structural rather than engineering. Worth having to hand the next time
somebody proposes that a bigger model will fix a forecasting problem.

---

## Also worth knowing about

**Ruelle, D., & Takens, F. (1971). "On the nature of turbulence."**
*Communications in Mathematical Physics* **20**(3), 167–192. DOI
[10.1007/BF01646553](https://doi.org/10.1007/BF01646553) — where the term
*strange attractor* is introduced.

**Poincaré's three-body work (1890)** is the real origin of sensitive
dependence, decades before anyone had a computer to see it with. Historical
rather than practical.

**Strogatz, S. H. — *Nonlinear Dynamics and Chaos***. Not a paper, and the
right first book by a distance if any of the above appeals.

---

Prior — AI engineering and data science, explained visually.
<https://prior-fm.github.io/prior-site/>

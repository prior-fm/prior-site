# Chaos, properly

*The long version of No. 011. Fifteen minutes. Every number in it comes from
the simulation in `chaos.py`, which you can run.*

---

## The thing you just watched

Fifty double pendulums. Identical rods, identical masses, released at the same
instant from the same height. The only difference between any two neighbours is
that one starts **a tenth of a degree** further round than the other.

For about ten seconds they move as one body. The colours stay in order, the
trails sweep a single clean bowl, and if you paused it you would say the fifty
were doing the same thing. Then, over the next five seconds, that falls apart —
not gradually, and not because anything was added. By twenty seconds their
release angles span **190 degrees** and two neighbours are on opposite sides of
the frame.

Nothing was randomised. There is no random number generator anywhere in the
code that made it. Run it twice and you get the same twenty seconds to the last
decimal place.

That gap — completely determined, completely unpredictable — is the whole
subject.

---

## Chaos is not randomness, and the difference is not pedantic

The everyday use of "chaotic" means messy, unpredictable, arbitrary. The
technical meaning is almost the opposite, and confusing the two will cost you.

A chaotic system is:

- **Deterministic.** The next state is a fixed function of the current state.
  No noise, no dice.
- **Sensitive to initial conditions.** Two states that start close together
  separate *exponentially*.
- **Bounded and non-repeating.** It does not fly off to infinity, and it never
  settles into a cycle.

A random system fails the first test. A pendulum in treacle fails the second.
A metronome fails the third. You need all three, and the double pendulum has
all three.

The practical consequence is precise: **a chaotic system is perfectly
predictable in principle and unpredictable in practice**, because you can never
specify the present state exactly, and the error you cannot avoid gets
amplified until it swamps the answer.

---

## The one equation worth carrying

Nearby states separate like this:

```
    δ(t) ≈ δ(0) · e^(λt)
```

`δ(0)` is how far apart you start, `λ` (lambda) is the **Lyapunov exponent**,
and it is the single number that characterises a chaotic system. Positive λ
means chaos. Bigger λ means it comes apart faster.

Rearrange it for the thing you actually want to know — how long until your
initial error grows to the size of the answer itself:

```
    t_horizon ≈ (1/λ) · ln(Δ / δ₀)
```

Read that carefully, because it contains the most important and least intuitive
fact in the field: **your prediction horizon grows only with the LOGARITHM of
your precision.**

For the film's pendulums, `chaos.py` fits **λ = 0.98 per second** — the
separation multiplies by about 2.7 every second. Starting a tenth of a degree
apart (δ₀ ≈ 0.0017 arm spans), the fifty stay together for about ten seconds.

Now suppose you want twice that. Twenty seconds instead of ten. How much more
precise do you need to be?

```
    extra time = (1/λ) · ln(improvement)
    10 seconds = (1/0.98) · ln(improvement)
    improvement = e^9.8 ≈ 18,000×
```

**Eighteen thousand times more precise, to buy ten more seconds.** Then another
eighteen thousand for the next ten. This is why chaos is not a measurement
problem you can spend your way out of. Halving your error buys you 0.7/λ more
time, always, no matter how small the error already is.

---

## Where the line is: try it yourself

The chaos is not in the equations. It is in how hard you push them.

```
python chaos.py --theta0 40
```

Same fifty pendulums, same tenth of a degree, same integrator. The separation
column reads `never` all the way down: after twenty seconds they are still
moving as one. A gently-swung double pendulum is quasi-periodic and boring.

```
python chaos.py --theta0 120
```

Gone in a few seconds.

Between them is a transition, and finding where it sits for a given system is
much of what nonlinear dynamics is. That the same equations can be tame or
chaotic depending only on energy is the point Robert May was making in *Nature*
in 1976 (see `PAPERS.md` #4) — model complexity and behavioural complexity have
very little to do with each other.

---

## The part that should change how you work

If you build models, train them, or run simulations, four consequences follow
directly.

### 1. "It reproduced" and "it is correct" are different claims

Determinism gets you bit-identical reruns on the same machine with the same
seed. It does not get you a right answer, and it does not survive a change of
hardware. Change the order of a floating-point reduction — a different GPU, a
different number of threads, a different BLAS — and you have perturbed the
initial state in the last bits. In a chaotic system that perturbation grows
exponentially. Two "identical" runs legitimately diverge.

So when a long-running simulation gives you a different answer on a different
cluster, the first question is not *where is the bug* but **is this system
chaotic, and has my perturbation had time to grow?** Sometimes there is no bug.

### 2. A forecast horizon is a property of the system, not of your model

The two-week limit on weather forecasting is not a compute budget. Zhang et al.
(2019) put modern models on near-perfect initial conditions and found the
ceiling holds (`PAPERS.md` #7). Any pipeline whose value proposition is
"predict further ahead" needs to know whether it is fighting engineering or
arithmetic.

### 3. Seed sensitivity is a measurement, not a nuisance

If your results move when you change the seed, that variance is telling you
something real about the loss surface you are on. Reporting one seed and
calling it the result hides it. Reporting the spread across seeds is the honest
version — and if the spread is large, the interesting question is why the
system amplifies small differences that much.

### 4. Sensitivity is measurable, so measure it

You do not have to argue about whether something is chaotic. Perturb the
initial state by ε, run both, and plot `log(separation)` against time. A
straight line with positive slope is a positive Lyapunov exponent, and the
slope is λ. Wolf et al. (1985) is the standard method for doing it from
observed data when you do not have the equations (`PAPERS.md` #6).

---

## One story from making this film, because it is the real lesson

The first version of `derivs()` — the function that says how the pendulum
accelerates — was **wrong**. Not a typo: an algebraically different, incorrect
form of the equations of motion.

It did not look wrong. It was numerically stable. It produced a smooth,
convincing, entirely plausible animation of fifty pendulums coming apart. And
it *converged*: the identical trajectory came back at timesteps of 1e-3, 1e-4
and 1e-5, so it did not look like integrator error either. Every check you
would normally apply, it passed.

The one thing that caught it: **a double pendulum conserves energy exactly**, so
energy drift measures the model, not just the resolution. The wrong equations
lost 0.169 joules a second. The correct ones lose 2.3 × 10⁻¹³.

`chaos.py` ships that check and prints it on every run, which is the point.
The general version:

> **Find a quantity your system must conserve, and assert it.** Not because
> integrators drift — because a *wrong model* also drifts, and it will happily
> produce beautiful output while doing so.

Mass, energy, probability summing to one, a count that should be invariant, a
number of rows that should not change. If nothing in your pipeline is checked
against a conservation law, nothing in your pipeline can tell you it is
modelling the wrong thing.

---

## Where to go next

- **`chaos.py`** — the simulation from the film. Standard library only, no
  numpy, nothing to install. Run it, break it, change the release angle.
- **`PAPERS.md`** — seven papers, in reading order, with what each one
  established and why it matters. Start with Lorenz 1963; it is short.

---

Prior — AI engineering and data science, explained visually.
<https://prior-fm.github.io/prior-site/>

# Prior No. 011 — Chaos Theory

The film shows fifty double pendulums released a tenth of a degree apart.
This is that, in one file you can read in a sitting.

```
python chaos.py                 # run it, print the divergence schedule
python chaos.py --svg out.svg   # ...and draw the trails
python chaos.py --theta0 120    # a more violent release
```

Standard library only. No numpy, no plotting library, no network, nothing to
install. Python 3.8+.

## What it prints

```
energy drift      6.774e-09 of the energy scale  OK
launch separation 0.001745 arm spans
  reaches 0.01      9.00 s
  reaches 0.05      10.47 s
  reaches 0.25      12.70 s
  reaches 0.5       14.67 s
final separation  0.7364 arm spans
```

Those are the film's own numbers. The film integrates at `dt = 1/3000`; this
script runs at `dt = 1/600`, five times coarser, and lands on the same
schedule to four significant figures — which is the point of a converged
integration.

## Two things worth your attention

**The caption is asserted, not decorated.** The film says "50 pendulums, 0.1°
apart", and `run()` refuses to integrate anything until it has checked that
the fifty initial angles really are spaced 0.1 degrees apart to machine
precision. If you edit `SPACING_DEG`, the assertion follows you.

**The energy check is the load-bearing test.** A double pendulum conserves
energy exactly; an integrator does not, and — this is the part that bites — a
*wrong set of equations* also does not, while still producing a smooth,
convincing, entirely fictional animation.

That happened while this film was being made. An algebraically different form
of the equations of motion was written first. It was stable. It converged: the
identical trajectory came back at `dt = 1e-3`, `1e-4` and `1e-5`, so it did not
look like integrator error. It lost **0.169 J per second** where the correct
form loses `2.3e-13`. Nothing else in the pipeline would have caught it, and
the film would have shipped fifty pendulums obeying a physics that does not
exist.

If you change `derivs()`, watch that number. A drift that moves means you have
changed the model, not the resolution.

## Where the divergence comes from

Nothing in this script is random. `chaos.py` contains no call to any random
number generator, and every run produces the identical output. The whole
twenty seconds is determined by one line:

```python
angles = [math.radians(theta0_deg + i * SPACING_DEG) for i in range(N)]
```

The fifty trajectories separate because the double pendulum stretches nearby
states apart exponentially — at this release angle, by a factor of e roughly
**every second** (the fitted Lyapunov exponent is 0.98 per second). A tenth of
a degree survives that for about ten seconds and then it does not.

Try `--theta0 40`: the pendulums stay in step for the whole run, and the
separation column reads `never` all the way down. The chaos is not in the
equations. It is in how hard you push them.

---

Prior — AI engineering and data science, explained visually.
<https://prior-fm.github.io/prior-site/>

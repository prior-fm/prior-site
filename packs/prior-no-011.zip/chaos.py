#!/usr/bin/env python3
"""No. 011 — Chaos Theory. Fifty double pendulums, 0.1 degrees apart.

This is the real thing the film shows, small enough to read in one sitting.
Standard library only: no numpy, no scipy, no plotting library, no network.

    python chaos.py                 # run it, print the divergence schedule
    python chaos.py --svg out.svg   # ...and draw the trails
    python chaos.py --theta0 120    # a more violent release

WHAT THE FILM CLAIMS, AND HOW THIS CHECKS IT

The film's caption is "50 pendulums, 0.1 apart". That is not set dressing:
the fifty initial angles below really are spaced 0.1 degrees apart, and the
script asserts it to machine precision before integrating anything.

The second claim is that the fifty diverge. That is measured here as the mean
distance between consecutively numbered bobs, in units of the arm span. It
starts at the launch separation (~0.0017) and, at the film's release angle,
passes half an arm span at 17.5 seconds.

WHY THE ENERGY CHECK IS NOT DECORATION

A double pendulum conserves energy exactly. An integrator does not, and a
WRONG SET OF EQUATIONS also does not — but it will still produce a smooth,
convincing, completely fictional animation. That happened while building this
film: an algebraically different (and wrong) form of the equations converged
to the same trajectory at dt = 1e-3, 1e-4 and 1e-5, so it did not look like
integrator error, and it lost 0.169 J per second where the correct form loses
2.3e-13. The energy gate is the only thing that caught it.

If you change the physics below, watch that number. If it moves, you have
changed the model, not the resolution.
"""

from __future__ import annotations

import argparse
import math

# ------------------------------------------------------------------ the setup
N = 50                 # pendulums
SPACING_DEG = 0.1      # the caption's "0.1 apart"
L1 = L2 = 1.0          # rod lengths, m
M1 = M2 = 1.0          # bob masses, kg
G = 9.81               # m/s^2

FPS = 30
DURATION = 20.0
SUBSTEPS = 20          # RK4 substeps per frame; dt = 1/600 s

ENERGY_SCALE = (M1 + M2) * G * (L1 + L2)


def derivs(t1, t2, w1, w2):
    """dy/dt for one planar double pendulum, theta from the downward vertical."""
    d = t1 - t2
    sd, cd = math.sin(d), math.cos(d)
    den = 2 * M1 + M2 - M2 * math.cos(2 * t1 - 2 * t2)
    a1 = (-G * (2 * M1 + M2) * math.sin(t1)
          - M2 * G * math.sin(t1 - 2 * t2)
          - 2 * sd * M2 * (w2 * w2 * L2 + w1 * w1 * L1 * cd)) / (L1 * den)
    a2 = (2 * sd * (w1 * w1 * L1 * (M1 + M2)
                    + G * (M1 + M2) * math.cos(t1)
                    + w2 * w2 * L2 * M2 * cd)) / (L2 * den)
    return w1, w2, a1, a2


def step(s, dt):
    """One RK4 step on a 4-tuple state."""
    k1 = derivs(*s)
    s2 = tuple(s[i] + 0.5 * dt * k1[i] for i in range(4))
    k2 = derivs(*s2)
    s3 = tuple(s[i] + 0.5 * dt * k2[i] for i in range(4))
    k3 = derivs(*s3)
    s4 = tuple(s[i] + dt * k3[i] for i in range(4))
    k4 = derivs(*s4)
    return tuple(s[i] + (dt / 6.0) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i])
                 for i in range(4))


def energy(s):
    t1, t2, w1, w2 = s
    y1 = -L1 * math.cos(t1)
    y2 = y1 - L2 * math.cos(t2)
    v1sq = (L1 * w1) ** 2
    v2sq = (L1 * w1) ** 2 + (L2 * w2) ** 2 + 2 * L1 * L2 * w1 * w2 * math.cos(t1 - t2)
    return 0.5 * M1 * v1sq + 0.5 * M2 * v2sq + M1 * G * y1 + M2 * G * y2


def bob(s):
    """In-plane position of the second bob."""
    t1, t2, _, _ = s
    return (L1 * math.sin(t1) + L2 * math.sin(t2),
            -L1 * math.cos(t1) - L2 * math.cos(t2))


def run(theta0_deg=83.0):
    # THE CLAIM, ASSERTED: consecutive releases are exactly 0.1 degrees apart.
    angles = [math.radians(theta0_deg + i * SPACING_DEG) for i in range(N)]
    gaps = [math.degrees(angles[i + 1] - angles[i]) for i in range(N - 1)]
    assert max(abs(g - SPACING_DEG) for g in gaps) < 1e-12, "spacing is not 0.1 deg"

    state = [(a, a, 0.0, 0.0) for a in angles]        # released as a straight arm
    e0 = [energy(s) for s in state]

    nframes = int(round(FPS * DURATION))
    dt = 1.0 / (FPS * SUBSTEPS)
    trails = [[] for _ in range(N)]
    seps, worst_drift = [], 0.0

    for _ in range(nframes):
        pts = [bob(s) for s in state]
        for i, p in enumerate(pts):
            trails[i].append(p)
        span = L1 + L2
        seps.append(sum(math.hypot(pts[i + 1][0] - pts[i][0],
                                   pts[i + 1][1] - pts[i][1]) for i in range(N - 1))
                    / ((N - 1) * span))
        for i in range(N):
            s = state[i]
            for _ in range(SUBSTEPS):
                s = step(s, dt)
            state[i] = s
            worst_drift = max(worst_drift, abs(energy(s) - e0[i]) / ENERGY_SCALE)

    return trails, seps, worst_drift


def first_above(seps, level):
    for i, v in enumerate(seps):
        if v >= level:
            return i / FPS
    return None


def write_svg(trails, path, size=900):
    """The trails, in the film's own ramp.

    One hue per pendulum, around a full wheel. The wheel WRAPS because the
    fifty planes are arranged in a circle about the pivot -- pendulum 49 is
    next to pendulum 0 in space, so it is next to it in colour too. That is
    the whole reason the picture reads: while the spectrum is smooth the
    system is predictable, and the moment adjacent hues stop being adjacent
    in space it is not.
    """
    import colorsys

    def ramp(u):
        r, g, b = colorsys.hsv_to_rgb(u, 0.82, 1.0)
        return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))

    span = L1 + L2
    c = size / 2.0
    k = (size / 2.0 - 10) / span
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" '
           f'viewBox="0 0 {size} {size}">',
           f'<rect width="{size}" height="{size}" fill="#0a0a0a"/>']
    for i, tr in enumerate(trails):
        pts = " ".join(f"{c + x * k:.1f},{c - y * k:.1f}" for x, y in tr)
        out.append(f'<polyline points="{pts}" fill="none" stroke="{ramp(i/N)}" '
                   f'stroke-width="1" stroke-opacity="0.65"/>')
    out.append("</svg>")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--theta0", type=float, default=83.0,
                    help="release angle of pendulum 0, degrees (the film uses 83)")
    ap.add_argument("--svg", metavar="PATH", help="also write an SVG of the trails")
    args = ap.parse_args()

    print(f"{N} double pendulums, released {SPACING_DEG} deg apart, "
          f"first at {args.theta0} deg")
    print(f"RK4, dt = 1/{FPS * SUBSTEPS} s, {DURATION:g}s\n")

    trails, seps, drift = run(args.theta0)

    print(f"energy drift      {drift:.3e} of the energy scale", end="  ")
    print("OK" if drift < 1e-6 else "*** TOO LARGE — check the equations ***")
    print(f"launch separation {seps[0]:.6f} arm spans")
    for lvl in (0.01, 0.05, 0.25, 0.50):
        t = first_above(seps, lvl)
        print(f"  reaches {lvl:<5}     {'never' if t is None else f'{t:.2f} s'}")
    print(f"final separation  {seps[-1]:.4f} arm spans")
    print("\nA tenth of a degree, and twenty seconds later they have nothing")
    print("to do with each other. Nothing was random; the whole run is")
    print("determined by the line that sets the angles.")

    if args.svg:
        write_svg(trails, args.svg)
        print(f"\nwrote {args.svg}")


if __name__ == "__main__":
    main()

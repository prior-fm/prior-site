# Prior — No. 016 · *A score, not a test*

The "I'm not a robot" checkbox never tests you. It **scores** you — before you
click — and the picture puzzle is what happens when the score is too low.
This is the scorer the film ran, on the film's own cursor paths.

```bash
python score.py                  # the three paths from the film: 0.9, 0.1, 0.4
python score.py --straight       # a synthetic straight line
python score.py mine.csv         # your own path: one "x,y" per line, evenly sampled
python score.py mine.csv --cookie 0 --network 0    # declare the other signals
```

Python 3.8+. Standard library only — no installs, no network, no arguments needed.

---

## What it does

The film says the checkbox "checks four things": **cookie, browser, network,
movement**. Three of those are states a real CAPTCHA reads from your session,
and the film simply declares them — pass or fail. The fourth is the one a mouse
path makes measurable, and it is the one this script computes:

| feature | what it measures | straight-line bot |
|---|---|---|
| `wander` | 1 − chord ÷ path length | 0 |
| `tempo` | speed variation ÷ mean speed | 0 |
| `turn` | mean heading change per moving sample, radians | 0 |
| `pauses` | fraction of samples slower than 2 px | 0 |

One logistic unit turns those into a **movement** probability. The overall
score is the **mean of the four signals**, clamped to 0.1–0.9 and shown to one
decimal — which is how reCAPTCHA v3 scores look in practice.

`film-paths.json` holds the three paths the film scores, tracked off the film
frame by frame (30 samples per second, source pixels). The numbers you see on
screen are what this script prints from that file. Nothing is typed in.

## What it shows

- The wandering visitor scores **0.9**. The bot's dead-straight approach scores
  **0.1**: every measurable signal is zero and the declared ones fail.
- The "careful" human scores **0.4** — and that is the point. Its **movement**
  passes (0.73, the same as everyone else's). What sinks it is the two declared
  signals the film paints amber: cookie and network. The model is not deciding
  whether you are human; it is scoring whether *your session* looks like the
  sessions it has seen. Nothing here knows them.
- Run `--straight` with the other three signals passing and a straight line
  still scores **0.8**. Movement alone cannot fail you. Movement alone cannot
  save you either.

## Try your own

Record a path (any tool that logs cursor positions at a fixed rate — a browser
`mousemove` listener sampled every 33 ms is enough), save it as `x,y` lines, and
run it. Then run it again with `--cookie 0`. Same hand, different verdict.

The interactive version — move your mouse, read your score, nothing leaves the
page — is at https://prior-fm.github.io/prior-site/robot.html.

## The model, in one place

```
z        = 8·wander + 4·tempo + 3·turn − 4·pauses − 2.3
movement = 1 / (1 + e^−z)
score    = clamp( mean(movement, cookie, browser, network), 0.1, 0.9 )
```

The weights were chosen on three paths and then held against all twenty-three
the film draws: the bot under 0.2, every human above 0.5 on movement. If that
gate had failed, the film would not have been built.

— Prior, @prior.fm

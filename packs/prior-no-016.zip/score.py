"""Prior — No. 016 · A score, not a test

Score a mouse path the way the film did. Python 3.8+, standard library only.

    python score.py                       # the three paths from the film
    python score.py path.csv              # your own: one "x,y" per line, sampled evenly in time
    python score.py --straight            # a synthetic straight line, for comparison
    python score.py path.csv --cookie 0 --network 0   # declare the other signals

The film's checkbox scores four signals and shows you one of them. Three —
cookie, browser, network — are states it declares (pass = 1, fail = 0). The
fourth, movement, is measured from the path. Everything below is the film's
own model, unchanged; the weights were tuned on three paths and then held
against all twenty-three the film draws (bot < 0.2, every human > 0.5).
"""
from __future__ import annotations
import argparse, math, sys

W = dict(wander=8.0, tempo=4.0, turn=3.0, pauses=-4.0, bias=-2.3)

# The three paths the film scores, in source pixels at 30 samples per second,
# trimmed to the approach (spawn to the first frame at the checkbox). Tracked
# off the film frame by frame and written next to this file by
# kit/scripts/build-captcha-016.py — not typed in.
import json, os
FILM = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "film-paths.json"), encoding="utf-8"))
DECLARED = {"b1  a bot": (0, 0, 0), "h19 also a person": (0, 1, 0)}


def features(pts):
    v, th = [], []
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        v.append(math.hypot(x1 - x0, y1 - y0)); th.append(math.atan2(y1 - y0, x1 - x0))
    L = sum(v); C = math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1])
    wander = 0.0 if L < 1e-9 else 1.0 - C / L
    mean = L / len(v); sd = math.sqrt(sum((s - mean) ** 2 for s in v) / len(v))
    tempo = 0.0 if mean < 1e-9 else sd / mean
    moving = [s > 2.0 for s in v]
    turns = [abs(math.remainder(b - a, 2 * math.pi)) for a, b, ma, mb in zip(th, th[1:], moving, moving[1:]) if ma and mb]
    turn = sum(turns) / len(turns) if turns else 0.0
    pauses = sum(1 for m in moving if not m) / len(moving)
    return dict(wander=wander, tempo=tempo, turn=turn, pauses=pauses)


def movement(f):
    z = W["wander"] * f["wander"] + W["tempo"] * f["tempo"] + W["turn"] * f["turn"] + W["pauses"] * f["pauses"] + W["bias"]
    return 1.0 / (1.0 + math.exp(-z))


def score(pts, cookie=1, browser=1, network=1):
    f = features(pts); m = movement(f)
    s = (m + cookie + browser + network) / 4.0
    return f, m, min(0.9, max(0.1, s))


def report(name, pts, signals):
    f, m, s = score(pts, *signals)
    print(f"{name:22s} wander {f['wander']:.3f} tempo {f['tempo']:.3f} turn {f['turn']:.3f} pauses {f['pauses']:.3f}"
          f"  movement {m:.2f}  signals {signals}  ->  score {s:.1f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?"); ap.add_argument("--straight", action="store_true")
    ap.add_argument("--cookie", type=int, default=1); ap.add_argument("--browser", type=int, default=1)
    ap.add_argument("--network", type=int, default=1)
    a = ap.parse_args()
    if a.straight:
        pts = [(600 - 18 * i, 300 + 14 * i) for i in range(20)]
        report("straight line", pts, (a.cookie, a.browser, a.network)); return
    if a.csv:
        pts = []
        for line in open(a.csv, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#"):
                x, y = line.replace(";", ",").split(",")[:2]; pts.append((float(x), float(y)))
        if len(pts) < 4: sys.exit("need at least 4 points")
        report(a.csv, pts, (a.cookie, a.browser, a.network)); return
    for name, pts in FILM.items():
        report(name, pts, DECLARED.get(name, (1, 1, 1)))


if __name__ == "__main__":
    main()

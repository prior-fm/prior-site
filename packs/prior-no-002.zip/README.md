# Prior — No. 002 · MCP and APIs

The video's claim, as code you can run.

Two MCP servers, two apps, and a script that counts the integrations for you.
No API keys, no network, no accounts. Everything is in-memory, so it runs
offline and it runs the same on your machine as on mine.

## Run it

    npm install
    npm run demo

That starts two servers, connects one app to both, prints the tools it
discovered, and calls one of them.

Then the part that actually matters:

    npm run count

which prints the arithmetic from the film — the same one you would have had to
take on trust.

## What's here

    src/servers/chat.ts      an MCP server wrapping a fake chat service
    src/servers/mail.ts      a second one, wrapping fake mail
    src/client.ts            the client: connect, discover, call
    src/apps/assistant.ts    app one — uses both servers
    src/apps/support.ts      app two — uses the SAME two servers
    src/count.ts             integrations, the old way vs this way

## The point, in one paragraph

`src/apps/support.ts` is the second app from the film. Open it. It is nineteen
lines, and **not one of them is an integration**. It imports the same client as
`assistant.ts` and points it at the same two servers. Under the old model this
file would have carried its own authentication, its own request code, its own
error handling and its own retries, once per service — and so would every app
after it.

That is the whole argument. Two apps and two services is four integrations the
old way, and four pieces the new way, which is a wash. The gap opens as you
grow: run `npm run count -- 8 30` and it will tell you what eight apps and
thirty services cost each way.

## The bit people get wrong

The model never calls anything. Watch the log line from `client.ts`:

    [client] discovered 4 tools -> chat.list_messages, chat.post_message, mail.list_threads, mail.send

The client asks each server what it can do, and hands that list to the model.
The model replies with the *name of a tool and some arguments* — text, nothing
more. Your code is what executes it. Every guardrail you want lives at that
step, in your process, not in the model's judgement.

`src/client.ts` marks that line with a comment, because it is the only line in
the pack where the distinction is visible.

## Requirements

Node 18 or newer. That is all.

---

Prior · https://prior-fm.github.io/prior-site/

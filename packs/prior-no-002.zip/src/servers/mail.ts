/* A second MCP server, wrapping mail.
 *
 * Deliberately near-identical in shape to chat.ts. That repetition IS the
 * lesson: the per-service work is now confined to one small program that the
 * service's owner could publish once, instead of being copied into every app
 * that wants it.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// --- the service --------------------------------------------------------
const threads = [
  { id: "t1", subject: "Invoice 4021 overdue", from: "billing@acme.test" },
  { id: "t2", subject: "Re: onboarding docs", from: "sam@acme.test" },
];

// --- the MCP wrapper ----------------------------------------------------
const server = new McpServer({ name: "mail", version: "1.0.0" });

server.tool("list_threads", "List recent mail threads", {}, async () => ({
  content: [{ type: "text", text: threads.map((t) => `${t.id}  ${t.subject}  (${t.from})`).join("\n") }],
}));

server.tool(
  "send",
  "Send a mail",
  { to: z.string(), subject: z.string(), body: z.string() },
  async ({ to, subject }) => ({
    content: [{ type: "text", text: `sent "${subject}" to ${to}` }],
  })
);

await server.connect(new StdioServerTransport());

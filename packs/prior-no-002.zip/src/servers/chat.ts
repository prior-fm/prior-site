/* An MCP server wrapping a chat service.
 *
 * The service is fake and in-memory on purpose: the film's argument is about
 * the SHAPE of the integration, and a real Slack token would only add an
 * account, a rate limit and a reason for this to stop working next year.
 *
 * Everything below the `--- the service ---` line is the part you would
 * replace with a real API client. Everything above it is the same in every
 * MCP server ever written, which is the whole point.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// --- the service --------------------------------------------------------
// Pretend this is behind api.example-chat.com, with auth, retries and all the
// error handling you would otherwise write once per app.
const channels: Record<string, { from: string; text: string }[]> = {
  "#alerts": [
    { from: "monitor", text: "p95 latency over 800ms for 5 minutes" },
    { from: "monitor", text: "recovered" },
  ],
  "#general": [{ from: "ana", text: "standup moved to 10:15" }],
};

// --- the MCP wrapper ----------------------------------------------------
const server = new McpServer({ name: "chat", version: "1.0.0" });

server.tool(
  "list_messages",
  "Read recent messages from a channel",
  { channel: z.string().describe("e.g. #alerts") },
  async ({ channel }) => {
    const msgs = channels[channel];
    if (!msgs) {
      // An error the MODEL can read and react to, rather than a thrown
      // exception the model never sees. This is a real difference.
      return {
        content: [{ type: "text", text: `no such channel: ${channel}. try ${Object.keys(channels).join(", ")}` }],
        isError: true,
      };
    }
    return {
      content: [{ type: "text", text: msgs.map((m) => `${m.from}: ${m.text}`).join("\n") }],
    };
  }
);

server.tool(
  "post_message",
  "Post a message to a channel",
  { channel: z.string(), text: z.string() },
  async ({ channel, text }) => {
    (channels[channel] ??= []).push({ from: "you", text });
    return { content: [{ type: "text", text: `posted to ${channel}` }] };
  }
);

await server.connect(new StdioServerTransport());

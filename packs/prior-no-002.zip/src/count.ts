/* The arithmetic from the film, executable.
 *
 *   npm run count            2 apps, 10 services  (the film's numbers)
 *   npm run count -- 8 30    your numbers
 *
 * The old way costs one integration per app per service: apps x services.
 * MCP costs one client per app plus one server per service: apps + services.
 * Both are trivially true. Seeing your own numbers in them is the useful part.
 */
const apps = Number(process.argv[2] ?? 2);
const services = Number(process.argv[3] ?? 10);

const byHand = apps * services;
const withMcp = apps + services;

console.log(`\n  ${apps} apps x ${services} services\n`);
console.log(`  hand-written integrations   ${String(byHand).padStart(4)}`);
console.log(`  clients + servers           ${String(withMcp).padStart(4)}`);
console.log(`  difference                  ${String(byHand - withMcp).padStart(4)}  (${(byHand / withMcp).toFixed(1)}x fewer pieces)\n`);

// The shape matters more than any single pair of numbers: one grows as a
// product, the other as a sum. At 2 x 2 they are equal and MCP buys you
// nothing. The case is only ever an argument about scale.
if (byHand <= withMcp) {
  console.log("  At these numbers MCP costs you MORE to build than it saves.");
  console.log("  That is not a bug in the argument - it is the argument.\n");
}

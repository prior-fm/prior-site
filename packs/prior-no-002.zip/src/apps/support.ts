/* App two: a support chat. The second app from the film.
 *
 * Count the integrations in this file. There are none. It points the same
 * client at the same two servers - no auth, no request code, no error
 * handling, no retries. Under the old model every one of those would have had
 * to be written again here, once per service, and again in the third app.
 */
import { Toolbox } from "../client.js";

const box = new Toolbox();
await box.add("chat", "src/servers/chat.ts");
await box.add("mail", "src/servers/mail.ts");

console.log(`\n[support] same two servers, ${box.tools.length} tools, zero new integration code`);
console.log(`[support] ${box.catalogue().join(", ")}\n`);

const result = await box.call("mail", "list_threads");
console.log((result as any).content?.[0]?.text, "\n");

await box.close();

/* App one: an assistant. Connects to both servers and uses what it finds. */
import { Toolbox } from "../client.js";

const box = new Toolbox();
await box.add("chat", "src/servers/chat.ts");
await box.add("mail", "src/servers/mail.ts");

console.log(`\n[client] discovered ${box.tools.length} tools -> ${box.catalogue().join(", ")}`);
console.log("[client] that list is what gets handed to the model.\n");

// Stand-in for the model's reply. In a real app this is text that came back
// from an LLM - a tool name and arguments, nothing executable.
const modelChose = { server: "chat", tool: "list_messages", args: { channel: "#alerts" } };
console.log(`[model ] asked for: ${modelChose.server}.${modelChose.tool}`, modelChose.args);

const result = await box.call(modelChose.server, modelChose.tool, modelChose.args);
console.log("[your code ran it, not the model]\n");
console.log((result as any).content?.[0]?.text, "\n");

await box.close();

/* The client. One of these per APP, not one per service.
 *
 * It does three things: connect to each server, ask what it can do
 * (discovery), and call a tool when asked. Nothing here knows anything about
 * chat or mail specifically - that is what makes it reusable, and it is why
 * the second app needs no new integration code at all.
 */
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

export type Tool = { server: string; name: string; description?: string };

export class Toolbox {
  private clients = new Map<string, Client>();
  tools: Tool[] = [];

  /** Start a server and connect to it. */
  async add(name: string, scriptPath: string) {
    const client = new Client({ name: "prior-demo", version: "1.0.0" });
    await client.connect(
      new StdioClientTransport({ command: "npx", args: ["tsx", scriptPath] })
    );
    this.clients.set(name, client);

    // DISCOVERY. The client asks; it was not told in advance.
    const { tools } = await client.listTools();
    for (const t of tools) {
      this.tools.push({ server: name, name: t.name, description: t.description });
    }
  }

  /** The list you hand to the model. It picks from this and nothing else. */
  catalogue() {
    return this.tools.map((t) => `${t.server}.${t.name}`);
  }

  /**
   * THE LINE THAT MATTERS.
   *
   * The model does not run this. The model produced a string - a tool name and
   * some arguments - and YOUR code decided to call it. Every guardrail you
   * want (allow-lists, confirmation, rate limits, audit) belongs right here,
   * in your process, because this is the only place with a network stack.
   */
  async call(server: string, tool: string, args: Record<string, unknown> = {}) {
    const client = this.clients.get(server);
    if (!client) throw new Error(`no server named ${server}`);
    return client.callTool({ name: tool, arguments: args });
  }

  async close() {
    for (const c of this.clients.values()) await c.close();
  }
}

# Prior no. 004 — Sorting visualiser

The machine from the film, with your numbers in it.

`sorting-visualiser.html` is **one file**. Double-click it. No install, no build step,
no network — it runs from your filesystem, offline, in any browser from the last few
years.

## What it does

- Put your own array in. Two to fourteen values.
- Watch it sort, one step at a time: **play**, **step**, or scrub with the speed slider.
- Four in-place comparison sorts: **bubble**, **insertion**, **selection**, **quicksort**
  (Lomuto partition).
- The code panel on the right highlights the line that is executing *right now*. It is
  the real implementation, not a script of pre-recorded frames — the bars move because
  the algorithm ran.
- Live counts of **comparisons** and **swaps**, so you can see for yourself why
  selection sort does 15 comparisons and 3 swaps where bubble sort does 15 and 11.

## Keyboard

| Key | Does |
|---|---|
| `Space` | play / pause |
| `→` | one step |
| `R` | reset |

## The number from the film

The film sorts `[4, 6, 8, 5, 2, 1]` with bubble sort. Run that exact array here and you
get **15 comparisons and 11 swaps** — the same five passes, in the same order. That is
the point of the thing: you can check the film against the code.

## Colour

Same system as the film. Hollow bars are untouched, solid paper is the pair being
compared, clay is a swap in flight, powder blue has settled and will not move again.

## Reuse

Yours to keep, change and ship. The four algorithms are plain generator functions near
the top of the `<script>` block — add a fifth and it will appear in the dropdown with a
working code panel as long as you give it a `src` array and yield `{type, i, j, line}`.

Prior /// no. 004 — https://prior-fm.github.io/prior-site/

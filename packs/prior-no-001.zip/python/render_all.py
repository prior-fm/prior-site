"""Render all thirteen charts to PNG.

    python render_all.py            # writes ./out/*.png
    python render_all.py --show 07  # draw one on screen instead

Every chart is deterministic — same seed, same output, every run. If a render
differs from the last one, something changed in the code, not in the dice.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

from prior_style import use_prior_style


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="out", help="output directory")
    parser.add_argument("--show", metavar="N",
                        help="show one chart by number (01-13) instead of saving")
    args = parser.parse_args()

    if not args.show:
        matplotlib.use("Agg")  # no display needed, and it is faster

    use_prior_style()

    import matplotlib.pyplot as plt
    from prior_charts import CHARTS

    if args.show:
        wanted = args.show.zfill(2)
        for name, fn in CHARTS:
            if name.startswith(wanted):
                fn()
                plt.show()
                return 0
        print(f"no chart {args.show!r}; expected 01-13", file=sys.stderr)
        return 1

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for name, fn in CHARTS:
        fig = fn()
        path = out / f"{name}.png"
        fig.savefig(path, facecolor=fig.get_facecolor())
        plt.close(fig)
        print(f"  {path}")

    # ASCII only — Windows consoles default to cp1252 and an arrow here
    # crashes the script after every chart has already been written.
    print(f"\n{len(CHARTS)} charts -> {out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""The thirteen charts from Prior No. 001, in matplotlib.

One function per chart, same order as the film. Each is standalone — read the
one you came for, ignore the rest. Every function returns a matplotlib Figure.

The data is generated with a fixed seed rather than loaded, so the file runs
anywhere with no downloads, and so you can see exactly which structure each
chart is built to show. Swap in your own data; the drawing code does not care.

Where a real model is the honest way to make the picture — the tree, the forest,
the SVM, k-means — this uses scikit-learn rather than faking the geometry. That
is the point of the pack: these are charts of real fits, not illustrations of
them.
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Polygon
from scipy import stats

from prior_style import (
    BLUE,
    PARCH,
    SIGNAL,
    PROBLEM,
    MUTED,
    SIGNAL_SOFT,
    SIGNAL_FILL,
    PROBLEM_FILL,
    STROKE,
    HAIRLINE,
    FIELDS,
    figure,
    eyebrow,
    strip_axes,
)

SEED = 7


def _grid(field: str, rows: int, cols: int, size: tuple[float, float]):
    """A multi-panel figure on a field. `figure()` only does single axes."""
    fig, axes = plt.subplots(rows, cols, figsize=size)
    fig.patch.set_facecolor(FIELDS[field])
    for ax in np.ravel(axes):
        ax.set_facecolor("none")
    return fig, axes


# ---------------------------------------------------------------- 01 heatmap
def heatmap():
    """4x4 correlation matrix. Cell density is proportional to |r|.

    Density, not hue, carries magnitude — so the matrix still reads correctly
    printed in grey, and clay is left free to mean the one thing it means:
    here, a correlation that runs the wrong way.
    """
    rng = np.random.default_rng(SEED)
    names = ["tenure", "spend", "tickets", "churn"]
    base = rng.normal(size=(400, 4))
    base[:, 1] += 0.8 * base[:, 0]           # spend follows tenure
    base[:, 3] -= 0.7 * base[:, 0]           # churn falls as tenure rises
    base[:, 2] += 0.5 * base[:, 3]           # tickets track churn
    corr = np.corrcoef(base, rowvar=False)

    fig, ax = figure("parchment", (6.0, 6.0))
    n = len(names)
    for i in range(n):
        for j in range(n):
            r = corr[i, j]
            # Negative correlation is the obstacle in this story, so it is the
            # only thing allowed to be clay.
            colour = PROBLEM if r < 0 else SIGNAL
            ax.add_patch(
                Rectangle(
                    (j, n - 1 - i), 1, 1,
                    facecolor=colour,
                    alpha=abs(r) * 0.85,
                    edgecolor="none",
                )
            )
            ax.text(
                j + 0.5, n - 1 - i + 0.5, f"{r:+.2f}",
                ha="center", va="center", fontsize=9,
                color=SIGNAL if abs(r) < 0.55 else FIELDS["parchment"],
            )

    ax.set_xlim(0, n)
    ax.set_ylim(0, n)
    ax.set_xticks(np.arange(n) + 0.5)
    ax.set_yticks(np.arange(n) + 0.5)
    ax.set_xticklabels(names)
    ax.set_yticklabels(names[::-1])
    ax.set_aspect("equal")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)
    eyebrow(ax, "correlation")
    return fig


# -------------------------------------------------------------------- 02 eda
def eda():
    """The four questions you ask a new table, in one 2x2 panel.

    Shape, relationship, spread, and composition. Outliers are clay — they are
    the thing that will break the model you are about to fit.
    """
    rng = np.random.default_rng(SEED)
    x = rng.normal(50, 12, 300)
    y = 0.8 * x + rng.normal(0, 9, 300)
    outlier = x > 78

    fig, axes = _grid("blue", 2, 2, (7.2, 7.2))
    (a, b), (c, d) = axes

    a.hist(x, bins=22, color=SIGNAL, alpha=0.85, edgecolor="none")
    a.set_title("shape", fontsize=9, color=MUTED, loc="left")

    b.scatter(x[~outlier], y[~outlier], s=9, color=SIGNAL, alpha=0.55, linewidths=0)
    b.scatter(x[outlier], y[outlier], s=22, color=PROBLEM, linewidths=0)
    b.set_title("relationship", fontsize=9, color=MUTED, loc="left")

    bp = c.boxplot([x, y], widths=0.5, patch_artist=True, tick_labels=["x", "y"])
    for patch in bp["boxes"]:
        patch.set(facecolor=SIGNAL_FILL, edgecolor=SIGNAL, linewidth=HAIRLINE)
    for part in ("whiskers", "caps", "medians"):
        for line in bp[part]:
            line.set(color=SIGNAL, linewidth=HAIRLINE)
    for flier in bp["fliers"]:
        flier.set(marker="o", markersize=3, markerfacecolor=PROBLEM,
                  markeredgecolor="none")
    c.set_title("spread", fontsize=9, color=MUTED, loc="left")

    parts = [0.52, 0.31, 0.17]
    left = 0.0
    for share, colour in zip(parts, [SIGNAL, MUTED, PROBLEM]):
        d.barh(0, share, left=left, height=0.5, color=colour, edgecolor="none")
        d.text(left + share / 2, 0, f"{share:.0%}", ha="center", va="center",
               fontsize=9, color=FIELDS["blue"])
        left += share
    d.set_xlim(0, 1)
    d.set_ylim(-0.6, 0.6)
    d.set_yticks([])
    d.set_title("composition", fontsize=9, color=MUTED, loc="left")

    fig.tight_layout()
    return fig


# ------------------------------------------------------------------- 03 venn
def venn():
    """An SQL inner join is a set intersection, drawn.

    The rows the join throws away are clay — for most people that is the part
    of a join that actually costs them something.
    """
    fig, ax = figure("parchment", (6.4, 4.6))
    strip_axes(ax)

    left = Circle((-0.62, 0), 1.0, facecolor=PROBLEM_FILL, edgecolor=SIGNAL,
                  linewidth=STROKE)
    right = Circle((0.62, 0), 1.0, facecolor=PROBLEM_FILL, edgecolor=SIGNAL,
                   linewidth=STROKE)
    ax.add_patch(left)
    ax.add_patch(right)

    # The intersection — the rows the join keeps — is drawn as the third tone
    # where the two slabs cross, which is the system's overlap rule.
    theta = np.linspace(0, 2 * np.pi, 400)
    lx, ly = -0.62 + np.cos(theta), np.sin(theta)
    rx, ry = 0.62 + np.cos(theta), np.sin(theta)
    inside_right = (lx - 0.62) ** 2 + ly ** 2 <= 1.0
    inside_left = (rx + 0.62) ** 2 + ry ** 2 <= 1.0
    lens = np.vstack(
        [np.column_stack([lx[inside_right], ly[inside_right]]),
         np.column_stack([rx[inside_left], ry[inside_left]])[::-1]]
    )
    ax.add_patch(Polygon(lens, closed=True, facecolor=SIGNAL, edgecolor="none",
                         alpha=0.88))

    ax.text(-1.15, 0, "orders\nonly", ha="center", va="center", fontsize=10,
            color=SIGNAL)
    ax.text(1.15, 0, "customers\nonly", ha="center", va="center", fontsize=10,
            color=SIGNAL)
    ax.text(0, 0, "INNER\nJOIN", ha="center", va="center", fontsize=10,
            color=PARCH)
    ax.set_xlim(-2.0, 2.0)
    ax.set_ylim(-1.45, 1.45)
    eyebrow(ax, "set theory")
    return fig


# --------------------------------------------------------- 04 gaussian dist
def gaussian_dist():
    """The normal curve with the central 68% shaded — one standard deviation.

    The tails are clay: they are where your assumptions stop holding.
    """
    x = np.linspace(-4, 4, 600)
    y = stats.norm.pdf(x)

    fig, ax = figure("parchment", (6.4, 4.4))
    ax.plot(x, y, color=SIGNAL, linewidth=STROKE)

    core = np.abs(x) <= 1
    ax.fill_between(x[core], y[core], color=SIGNAL, alpha=0.14)
    for side in (x <= -1, x >= 1):
        ax.fill_between(x[side], y[side], color=PROBLEM, alpha=0.45)

    for s in (-1, 1):
        ax.plot([s, s], [0, stats.norm.pdf(s)], color=SIGNAL,
                linewidth=HAIRLINE, linestyle=(0, (4, 3)))
    ax.text(0, 0.14, "68%", ha="center", fontsize=11, color=SIGNAL)
    ax.text(-2.3, 0.045, "16%", ha="center", fontsize=9, color=SIGNAL)
    ax.text(2.3, 0.045, "16%", ha="center", fontsize=9, color=SIGNAL)

    ax.set_ylim(0, 0.46)
    ax.set_yticks([])
    ax.set_xticks([-3, -2, -1, 0, 1, 2, 3])
    ax.set_xticklabels(["-3σ", "-2σ", "-1σ", "μ", "1σ", "2σ", "3σ"])
    ax.spines["left"].set_visible(False)
    eyebrow(ax, "distribution")
    return fig


# --------------------------------------------------------- 05 gaussian test
def gaussian_test():
    """A one-tailed test: rejection region, critical value, test statistic.

    The rejection region is clay. Landing in it is the null hypothesis failing,
    which is exactly what clay is for.
    """
    x = np.linspace(-4, 4, 600)
    y = stats.norm.pdf(x)
    crit = stats.norm.ppf(0.95)
    observed = 2.31

    fig, ax = figure("parchment", (6.4, 4.4))
    ax.plot(x, y, color=SIGNAL, linewidth=STROKE)

    tail = x >= crit
    ax.fill_between(x[tail], y[tail], color=PROBLEM, alpha=0.55)
    ax.plot([crit, crit], [0, stats.norm.pdf(crit)], color=SIGNAL,
            linewidth=HAIRLINE, linestyle=(0, (4, 3)))
    ax.annotate(
        f"critical value {crit:.2f}",
        xy=(crit, stats.norm.pdf(crit)), xytext=(crit - 2.5, 0.28),
        fontsize=9, color=SIGNAL,
        arrowprops=dict(arrowstyle="-", color=MUTED, linewidth=HAIRLINE),
    )
    ax.plot([observed, observed], [0, 0.30], color=PROBLEM, linewidth=STROKE)
    ax.text(observed + 0.12, 0.31, f"observed {observed:.2f}\nreject H₀",
            fontsize=9, color=PROBLEM, va="bottom")
    ax.text(crit + 0.55, 0.02, "α = 0.05", fontsize=9, color=SIGNAL)

    ax.set_ylim(0, 0.46)
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    eyebrow(ax, "hypothesis test")
    return fig


# ------------------------------------------------------------------ 06 forest
def forest():
    """Five confidence intervals against the true mean. One misses.

    This is the picture that makes "95% confident" mean something: run the
    study twenty times and one interval is expected to miss. The one that does
    is clay, and it is not wrong — it is the advertised failure rate, drawn.
    """
    rng = np.random.default_rng(3)
    truth = 0.0
    labels = ["study A", "study B", "study C", "study D", "study E"]
    centres = np.array([0.18, -0.22, 0.44, -0.05, 0.62])
    halves = np.array([0.34, 0.30, 0.26, 0.40, 0.30])

    fig, ax = figure("parchment", (6.4, 4.4))
    for i, (c, h, name) in enumerate(zip(centres, halves, labels)):
        misses = not (c - h <= truth <= c + h)
        colour = PROBLEM if misses else SIGNAL
        y = len(labels) - 1 - i
        ax.plot([c - h, c + h], [y, y], color=colour, linewidth=STROKE)
        ax.plot([c], [y], marker="s", markersize=6, color=colour)
        for end in (c - h, c + h):
            ax.plot([end, end], [y - 0.16, y + 0.16], color=colour,
                    linewidth=HAIRLINE)
        if misses:
            ax.text(c + h + 0.06, y, "misses", fontsize=9, color=PROBLEM,
                    va="center")

    ax.axvline(truth, color=SIGNAL, linewidth=HAIRLINE, linestyle=(0, (4, 3)))
    ax.text(truth + 0.02, len(labels) - 0.35, "true mean", fontsize=9,
            color=MUTED)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels[::-1])
    ax.set_xlim(-0.8, 1.2)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    eyebrow(ax, "confidence intervals")
    return fig


# -------------------------------------------------------------- 07 regression
def regression():
    """Least squares, with the residuals actually drawn.

    Most regression plots show the line and hide the error. The residuals are
    the error, so they are clay, and they are drawn as the segments the fit is
    minimising the squares of.
    """
    rng = np.random.default_rng(SEED)
    x = np.sort(rng.uniform(0, 10, 40))
    y = 2.1 * x + 4 + rng.normal(0, 3.2, x.size)

    slope, intercept = np.polyfit(x, y, 1)
    fit = slope * x + intercept

    fig, ax = figure("blue", (6.4, 4.8))
    for xi, yi, fi in zip(x, y, fit):
        ax.plot([xi, xi], [yi, fi], color=PROBLEM, linewidth=HAIRLINE)
    ax.scatter(x, y, s=26, color=SIGNAL, zorder=3, linewidths=0)
    ax.plot(x, fit, color=SIGNAL, linewidth=STROKE, zorder=2)

    ax.text(0.4, y.max() - 1.5, f"ŷ = {slope:.2f}x + {intercept:.2f}",
            fontsize=10, color=SIGNAL)
    ax.text(0.4, y.max() - 4.2, "clay = residual", fontsize=9, color=PROBLEM)
    eyebrow(ax, "regression")
    return fig


# -------------------------------------------------------------------- 08 tree
def tree():
    """A decision tree fitted for real, then drawn by hand.

    sklearn's own plot_tree is a debugging tool, not a picture. This fits the
    same model and draws it in the system: the impure leaf — the one that still
    has both classes in it — is clay.
    """
    from sklearn.datasets import make_moons
    from sklearn.tree import DecisionTreeClassifier

    X, y = make_moons(n_samples=240, noise=0.28, random_state=SEED)
    clf = DecisionTreeClassifier(max_depth=2, random_state=SEED).fit(X, y)
    t = clf.tree_

    fig, ax = figure("blue", (6.6, 4.6))
    strip_axes(ax)
    ax.set_aspect("auto")

    positions: dict[int, tuple[float, float]] = {}

    def place(node: int, x: float, y: float, span: float) -> None:
        positions[node] = (x, y)
        left, right = t.children_left[node], t.children_right[node]
        if left == -1:
            return
        place(left, x - span, y - 1.0, span / 2)
        place(right, x + span, y - 1.0, span / 2)

    place(0, 0.0, 0.0, 1.0)

    for node, (x, y) in positions.items():
        left, right = t.children_left[node], t.children_right[node]
        for child in (left, right):
            if child != -1:
                cx, cy = positions[child]
                ax.plot([x, cx], [y - 0.12, cy + 0.12], color=SIGNAL,
                        linewidth=HAIRLINE, zorder=1)

        counts = t.value[node][0]
        impure = left == -1 and counts.min() / counts.sum() > 0.12
        colour = PROBLEM if impure else SIGNAL
        label = (
            f"x{t.feature[node]} ≤ {t.threshold[node]:.2f}"
            if left != -1
            else f"{int(counts.argmax())}\n{counts.max() / counts.sum():.0%} pure"
        )
        ax.add_patch(
            Rectangle((x - 0.42, y - 0.16), 0.84, 0.32, facecolor=colour,
                      edgecolor="none", zorder=2)
        )
        ax.text(x, y, label, ha="center", va="center", fontsize=8,
                color=BLUE, zorder=3, linespacing=1.3)

    ax.set_xlim(-2.4, 2.4)
    ax.set_ylim(-2.5, 0.6)
    eyebrow(ax, "decision tree")
    return fig


# ---------------------------------------------------------------- 09 ensemble
def ensemble():
    """Three trees voting into one answer.

    The dissenting tree is clay. That is the whole argument for an ensemble:
    one model being wrong stops mattering once you count.
    """
    fig, ax = figure("blue", (6.6, 4.2))
    strip_axes(ax)
    ax.set_aspect("auto")

    votes = [("tree 1", "A", False), ("tree 2", "A", False), ("tree 3", "B", True)]
    for i, (name, vote, dissents) in enumerate(votes):
        x = (i - 1) * 1.5
        colour = PROBLEM if dissents else SIGNAL
        ax.add_patch(Rectangle((x - 0.5, 0.55), 1.0, 0.5, facecolor=colour,
                               edgecolor="none"))
        ax.text(x, 0.8, f"{name}\n→ {vote}", ha="center", va="center",
                fontsize=8, color=BLUE, linespacing=1.4)
        ax.plot([x, 0], [0.5, -0.28], color=colour, linewidth=HAIRLINE)

    ax.add_patch(Rectangle((-0.75, -0.85), 1.5, 0.55, facecolor=SIGNAL,
                           edgecolor="none"))
    ax.text(0, -0.575, "majority → A", ha="center", va="center", fontsize=9,
            color=BLUE)
    ax.text(1.55, -0.575, "2 of 3", fontsize=9, color=MUTED, va="center")

    ax.set_xlim(-2.6, 2.6)
    ax.set_ylim(-1.2, 1.35)
    eyebrow(ax, "ensemble")
    return fig


# ------------------------------------------------------------------ 10 margin
def margin():
    """A support vector machine: boundary, margins, and the vectors themselves.

    The support vectors are clay. They are the obstacle in the literal sense —
    the only points the boundary is not free to ignore. Delete every other
    point and the model is unchanged.
    """
    from sklearn.svm import SVC

    rng = np.random.default_rng(SEED)
    a = rng.normal([-1.6, -1.1], 0.72, size=(28, 2))
    b = rng.normal([1.7, 1.3], 0.72, size=(28, 2))
    X = np.vstack([a, b])
    y = np.array([0] * len(a) + [1] * len(b))

    clf = SVC(kernel="linear", C=1.0).fit(X, y)
    w, b0 = clf.coef_[0], clf.intercept_[0]
    xs = np.linspace(X[:, 0].min() - 0.6, X[:, 0].max() + 0.6, 100)
    boundary = -(w[0] * xs + b0) / w[1]
    offset = 1.0 / np.linalg.norm(w) * np.hypot(w[0], w[1]) / abs(w[1])

    fig, ax = figure("blue", (6.4, 5.0))
    ax.fill_between(xs, boundary - offset, boundary + offset, color=SIGNAL,
                    alpha=0.07)
    ax.plot(xs, boundary, color=SIGNAL, linewidth=STROKE)
    for sign in (-1, 1):
        ax.plot(xs, boundary + sign * offset, color=SIGNAL,
                linewidth=HAIRLINE, linestyle=(0, (4, 3)))

    ax.scatter(X[:, 0], X[:, 1], s=24, color=SIGNAL, linewidths=0, alpha=0.55)
    sv = clf.support_vectors_
    ax.scatter(sv[:, 0], sv[:, 1], s=90, facecolors="none", edgecolors=PROBLEM,
               linewidths=STROKE, zorder=4)
    ax.text(xs[2], boundary[2] + offset + 0.35,
            f"{len(sv)} support vectors\ncarry the boundary",
            fontsize=9, color=PROBLEM, linespacing=1.4)

    ax.set_xlim(xs.min(), xs.max())
    ax.set_ylim(X[:, 1].min() - 1.0, X[:, 1].max() + 1.2)
    eyebrow(ax, "margin")
    return fig


# ---------------------------------------------------------------- 11 clusters
def clusters():
    """The same points before and after k-means, k = 4.

    Left: what you were handed. Right: what the algorithm decided. The point
    that sits between two centroids is clay — the assignment nobody should
    trust, and the one a silhouette score is really measuring.
    """
    from sklearn.cluster import KMeans
    from sklearn.datasets import make_blobs

    X, _ = make_blobs(n_samples=220, centers=4, cluster_std=1.25,
                      random_state=SEED)
    km = KMeans(n_clusters=4, n_init=10, random_state=SEED).fit(X)

    # Distance to the nearest two centroids — if they are close, the point is
    # genuinely ambiguous.
    d = np.linalg.norm(X[:, None, :] - km.cluster_centers_[None, :, :], axis=2)
    nearest = np.sort(d, axis=1)
    ambiguous = (nearest[:, 1] - nearest[:, 0]) < 0.35

    fig, axes = _grid("blue", 1, 2, (8.4, 4.4))
    left, right = axes

    left.scatter(X[:, 0], X[:, 1], s=18, color=SIGNAL, alpha=0.5, linewidths=0)
    left.set_title("before", fontsize=9, color=MUTED, loc="left")

    for k in range(4):
        pts = X[km.labels_ == k]
        right.scatter(pts[:, 0], pts[:, 1], s=18, color=SIGNAL,
                      alpha=0.28 + 0.16 * k, linewidths=0)
    right.scatter(X[ambiguous, 0], X[ambiguous, 1], s=42, color=PROBLEM,
                  linewidths=0, zorder=3)
    right.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],
                  marker="+", s=140, color=SIGNAL, linewidths=STROKE, zorder=4)
    right.set_title(f"after — k=4, {ambiguous.sum()} ambiguous", fontsize=9,
                    color=MUTED, loc="left")

    for ax in (left, right):
        ax.set_xticks([])
        ax.set_yticks([])
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 12 forecast
def forecast():
    """History drawing into a dashed projection, with the uncertainty cone.

    The cone is clay because it is the honest part: the further out you go the
    less you know, and a forecast drawn without it is a lie of omission.
    """
    rng = np.random.default_rng(SEED)
    t_hist = np.arange(0, 36)
    level = 100 + 1.9 * t_hist + 6 * np.sin(t_hist / 5.2)
    history = level + rng.normal(0, 3.4, t_hist.size)

    t_fut = np.arange(35, 52)
    projection = 100 + 1.9 * t_fut + 6 * np.sin(t_fut / 5.2)
    spread = 2.6 * np.sqrt(np.arange(t_fut.size))

    fig, ax = figure("parchment", (6.8, 4.4))
    ax.fill_between(t_fut, projection - spread, projection + spread,
                    color=PROBLEM, alpha=0.30, linewidth=0)
    ax.plot(t_hist, history, color=SIGNAL, linewidth=STROKE)
    ax.plot(t_fut, projection, color=SIGNAL, linewidth=STROKE,
            linestyle=(0, (5, 4)))
    ax.axvline(35, color=MUTED, linewidth=HAIRLINE)
    ax.text(35.6, history.min(), "now", fontsize=9, color=MUTED)
    ax.text(44, projection[-1] + spread[-1] + 2, "uncertainty grows\nwith horizon",
            fontsize=9, color=PROBLEM, linespacing=1.4)

    ax.set_xticks([])
    eyebrow(ax, "forecast")
    return fig


# --------------------------------------------------------------- 13 bipartite
def bipartite():
    """A user–item graph with one recommendation lighting up.

    Clay marks what the user has already seen — legacy, in the system's sense.
    The recommendation is black, because it is the thing that works. This is
    the one chart where clay is not a failure, and it still obeys the rule:
    clay is what is behind you, black is what is in front.
    """
    users = ["u1", "u2", "u3"]
    items = ["i1", "i2", "i3", "i4"]
    seen = [(0, 0), (0, 1), (1, 1), (1, 2), (2, 2), (2, 3)]
    recommended = (0, 2)

    fig, ax = figure("parchment", (6.2, 4.6))
    strip_axes(ax)
    ax.set_aspect("auto")

    ux = 0.0
    ix = 2.6
    uy = np.linspace(1.6, -1.6, len(users))
    iy = np.linspace(2.0, -2.0, len(items))

    for u, i in seen:
        ax.plot([ux, ix], [uy[u], iy[i]], color=PROBLEM, linewidth=HAIRLINE,
                zorder=1)
    u, i = recommended
    ax.plot([ux, ix], [uy[u], iy[i]], color=SIGNAL, linewidth=STROKE, zorder=2)

    for name, y in zip(users, uy):
        ax.add_patch(Circle((ux, y), 0.26, facecolor=SIGNAL, edgecolor="none",
                            zorder=3))
        ax.text(ux, y, name, ha="center", va="center", fontsize=9, color=PARCH,
                zorder=4)
    for name, y in zip(items, iy):
        ax.add_patch(Circle((ix, y), 0.26, facecolor=SIGNAL, edgecolor="none",
                            zorder=3))
        ax.text(ix, y, name, ha="center", va="center", fontsize=9, color=PARCH,
                zorder=4)

    ax.text(1.3, iy[recommended[1]] + 0.42, "recommended", ha="center",
            fontsize=9, color=SIGNAL)
    ax.text(1.3, -2.5, "clay = already seen", ha="center", fontsize=9,
            color=PROBLEM)

    ax.set_xlim(-0.8, 3.4)
    ax.set_ylim(-2.9, 2.5)
    eyebrow(ax, "recommender")
    return fig


# The order they appear in the film.
CHARTS = [
    ("01-heatmap", heatmap),
    ("02-eda", eda),
    ("03-venn", venn),
    ("04-gaussian-dist", gaussian_dist),
    ("05-gaussian-test", gaussian_test),
    ("06-forest", forest),
    ("07-regression", regression),
    ("08-tree", tree),
    ("09-ensemble", ensemble),
    ("10-margin", margin),
    ("11-clusters", clusters),
    ("12-forecast", forecast),
    ("13-bipartite", bipartite),
]

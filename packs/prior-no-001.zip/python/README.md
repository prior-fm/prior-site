# The thirteen charts, in Python

The reel is HTML and SVG. This is the same thirteen charts in matplotlib, so you
can put them in a notebook, a report or a slide instead of a video.

## Run it

    pip install -r requirements.txt
    python render_all.py

Thirteen PNGs land in `out/`. To look at one on screen instead:

    python render_all.py --show 07

## What's here

    prior_style.py     the design system as matplotlib rcParams
    prior_charts.py    thirteen functions, one per chart
    render_all.py      renders them all, or shows one
    requirements.txt   numpy, matplotlib, scikit-learn, scipy

Each chart is a function that returns a Figure. Import the one you want:

```python
from prior_style import use_prior_style
from prior_charts import regression

use_prior_style()
fig = regression()
fig.savefig("mine.png", facecolor=fig.get_facecolor())
```

## Where the models are real

Four of these are fitted, not drawn. The tree, the ensemble's logic, the SVM and
the clustering all come out of scikit-learn, so the geometry is the model's, not
an illustrator's:

| chart | what actually runs |
|---|---|
| `tree` | `DecisionTreeClassifier(max_depth=2)` on `make_moons`, then the fitted tree is walked and drawn node by node |
| `margin` | `SVC(kernel="linear")` — the support vectors circled are the ones the fit returned |
| `clusters` | `KMeans(n_clusters=4)`, and "ambiguous" means the two nearest centroids are within 0.35 |
| `forest` | five intervals against a known truth; the one that misses is the advertised 1-in-20 |

The rest are drawn from generated data with a fixed seed, so every run produces
an identical image. If a render changes, your code changed.

## The one rule to keep if you change nothing else

**Clay means it failed, is legacy, or is the obstacle. Black means everything
else.** That is the whole system. It is why the residuals are clay in the
regression, why the rejection region is clay in the test, and why the support
vectors are clay in the margin — those are the points the boundary is not free
to ignore.

It is also why `figure()` raises if you ask for a clay field. A chart on clay
loses every accent mark it has, because the accent is now the background.

## Type

The films use Printvetica. It is free for commercial use but may **not** be
redistributed as a font, so it is not in this pack. If you have it installed it
is picked up automatically; if not, everything falls back and still reads
correctly — the character in this system comes from scale, crop and tracking,
not from the face.

Printvetica is a display face with no Greek, no subscripts and no maths
operators, so `prior_style.py` sets `font.family` to a *list*. That turns on
matplotlib's per-glyph fallback and lets σ, μ, α and ≤ come from DejaVu while
everything else stays Printvetica. Set it to the string `"sans-serif"` and every
one of those characters silently becomes an empty box.

---

Prior · https://prior-fm.github.io/prior-site/

"""Prior — the design system, as matplotlib.

The reel's thirteen charts are HTML/SVG components. This is the same system
expressed for Python, so the charts you make look like the ones in the film.

The rules are not decoration. Three of them do real work:

1.  **Clay is the only accent, and it means one thing: this failed, this is
    legacy, this is the obstacle.** Black carries everything that works. If you
    use clay for "the interesting bit" the system collapses, because now the
    reader has to ask which kind of interesting it is.
2.  **Charts never sit on a clay field.** Clay is the accent; an accent on its
    own colour is invisible.
3.  **Hierarchy comes from size and colour, never weight.** One typeface.

Colours are measured off the reference poster (Michał Stróż, *sytuacje/relacje*),
not eyeballed, and match `design/palette.json` in this pack exactly.
"""

from __future__ import annotations

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager

# --------------------------------------------------------------------------
# Canvas. The films render at 1080x1920; a chart is square unless it needs not
# to be. 180 dpi means one CSS pixel is one image pixel at figsize 6.
# --------------------------------------------------------------------------
DPI = 180
PX = 1.0 / DPI  # one pixel, in inches


def px_to_pt(px: float) -> float:
    """The system specifies strokes in pixels; matplotlib wants points."""
    return px / DPI * 72.0


STROKE = px_to_pt(3)       # the system's one stroke weight
HAIRLINE = px_to_pt(1.5)   # axes, ticks, anything structural

# --------------------------------------------------------------------------
# The palette. Field colours are backgrounds; ink colours go on top of them.
# --------------------------------------------------------------------------
BLUE = "#B0CBD6"    # field: data prep, machine learning
PARCH = "#F1ECDF"   # field: statistics, advanced
CLAY = "#DA9062"    # field: statement frames ONLY — never behind a chart
BLACK = "#0A0A0A"   # field: inversion / hero frames
PAPER = "#EFECE4"   # ink: type on the black field

# Semantic names — these are what the components actually reference, and what
# you should use in your own charts. They map onto the CSS custom properties of
# the same name in design/prior.css.
SIGNAL = BLACK              # neutral, correct, everything that works
PROBLEM = CLAY              # THE ONLY ACCENT: fails, legacy, the obstacle
MUTED = (0.04, 0.04, 0.04, 0.72)
SIGNAL_SOFT = (0.04, 0.04, 0.04, 0.40)
SIGNAL_FILL = (0.04, 0.04, 0.04, 0.055)
PROBLEM_FILL = (0.855, 0.565, 0.384, 0.26)

FIELDS = {"blue": BLUE, "parchment": PARCH, "black": BLACK}

# --------------------------------------------------------------------------
# Type. Printvetica is free for commercial use but may NOT be redistributed as
# a font, so this pack does not ship it. If you have it installed it is used;
# otherwise we fall back quietly. The system's point is that character comes
# from scale, crop and tracking — not from the face — so a fallback still reads
# as Prior.
# --------------------------------------------------------------------------
_PREFERRED = ["Printvetica", "Archivo Black", "Helvetica Neue", "Arial", "DejaVu Sans"]


def _first_installed(candidates: list[str]) -> str:
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in available:
            return name
    return "DejaVu Sans"


def use_prior_style() -> None:
    """Apply the system globally. Call once, before you draw anything."""
    face = _first_installed(_PREFERRED)
    mpl.rcParams.update(
        {
            "figure.dpi": DPI,
            "savefig.dpi": DPI,
            # A LIST, not "sans-serif" — matplotlib only does per-glyph
            # fallback when the family itself is a list. Printvetica is a
            # display face and has no σ, μ, α, ≤, → or subscripts, so without
            # this every piece of statistical notation renders as a blank box.
            "font.family": [face, "DejaVu Sans"],
            "font.size": 11,
            "text.color": SIGNAL,
            # Axes are structure, not content — keep them quiet and open.
            "axes.facecolor": "none",
            "axes.edgecolor": SIGNAL,
            "axes.linewidth": HAIRLINE,
            "axes.labelcolor": SIGNAL,
            "axes.titlesize": 13,
            "axes.titlelocation": "left",
            "axes.titlepad": 14,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": False,
            "xtick.color": SIGNAL,
            "ytick.color": SIGNAL,
            "xtick.major.width": HAIRLINE,
            "ytick.major.width": HAIRLINE,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "lines.linewidth": STROKE,
            "lines.solid_capstyle": "butt",
            "patch.linewidth": STROKE,
            "legend.frameon": False,
            "legend.fontsize": 9,
            # Radius 0 everywhere. The system has no rounded corners.
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.28,
        }
    )


def figure(field: str = "parchment", size: tuple[float, float] = (6.0, 6.0)):
    """A figure on one of the three legal chart fields.

    Passing ``clay`` raises: clay is the accent, so a chart drawn on it loses
    every accent mark it has. This is the one rule the system will not let you
    break by accident.
    """
    if field == "clay":
        raise ValueError(
            "Charts must never sit on a clay field — clay IS the accent, so "
            "accent marks vanish into their own background. Use 'blue', "
            "'parchment' or 'black'."
        )
    if field not in FIELDS:
        raise ValueError(f"unknown field {field!r}; expected one of {sorted(FIELDS)}")

    ground = FIELDS[field]
    fig, ax = plt.subplots(figsize=size)
    fig.patch.set_facecolor(ground)
    ax.set_facecolor("none")

    # On the black field the ink inverts; everything else stays as set.
    if field == "black":
        ink = PAPER
        for item in (ax.xaxis.label, ax.yaxis.label, ax.title):
            item.set_color(ink)
        ax.tick_params(colors=ink)
        for spine in ax.spines.values():
            spine.set_color(ink)

    return fig, ax


def eyebrow(ax, text: str) -> None:
    """The small tracked-out label above a chart. Uppercase, wide, quiet."""
    ax.set_title(
        " ".join(text.upper()),
        fontsize=8,
        color=MUTED,
        loc="left",
        pad=16,
    )


def strip_axes(ax) -> None:
    """For diagrams that are not plots — trees, graphs, set diagrams."""
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_aspect("equal")

# Prior — No. 001 · Data science & ML

The thirteen visualisations from the reel, as source you can run and change.

Two ways in. The **Python** is probably the one you want: matplotlib versions of
all thirteen charts, ready to drop into a notebook. The **components** are the
actual HTML/SVG the film was rendered from, if you build motion graphics.

## What's here

    python/       the thirteen charts in matplotlib — start here
    components/   the thirteen chart components, one HTML file each
    design/       the palette, the rules, and the stylesheet

## Python

    cd python
    pip install -r requirements.txt
    python render_all.py

Thirteen PNGs land in `python/out/`. Each chart is a function returning a
matplotlib Figure, so you can import one on its own:

```python
from prior_style import use_prior_style
from prior_charts import regression

use_prior_style()
fig = regression()
```

Four of the thirteen are fitted with scikit-learn rather than drawn — the
decision tree, the SVM margin, the k-means clustering, and the confidence
intervals. The geometry is the model's, not an illustrator's. See
`python/README.md`.

## The components

| file | chart |
|---|---|
| viz-heatmap        | 4×4 correlation matrix, cell density ∝ \|r\| |
| viz-eda            | histogram + scatter + box plot + proportion, in one 2×2 panel |
| viz-venn           | set intersection mapped to an SQL inner join |
| viz-gaussian-dist  | normal curve with the central 68% shaded |
| viz-gaussian-test  | one-tailed rejection region, critical value vs test statistic |
| viz-forest         | five confidence intervals against the true mean; one misses |
| viz-regression     | scatter, least-squares fit, and the residuals drawn in |
| viz-tree           | binary decision tree, root through to leaves |
| viz-ensemble       | three trees voting into one answer |
| viz-margin         | SVM boundary, margins, and the support vectors called out |
| viz-clusters       | the same points before and after assignment, k = 4 |
| viz-forecast       | history drawing into a dashed projection with a cone |
| viz-bipartite      | user–item graph with the recommendation lighting up |

## Running the components

Each is a HyperFrames sub-composition — plain HTML, CSS and SVG with one paused
GSAP timeline. No build step. Mount one from a host composition:

    <div data-composition-id="viz-heatmap"
         data-composition-src="compositions/viz-heatmap.html"
         style="--ground:#B0CBD6"
         data-start="0" data-duration="2.8" data-track-index="1"
         data-width="1080" data-height="1920"></div>

Three things that will bite you:

1. The host slot's `data-composition-id` must **exactly** match the id inside the
   file and its `window.__timelines` key. A mismatch fails silently at render.
2. `data-composition-src` resolves from the **project root**, not from the host file.
3. Set stroke and fill with **inline attributes**, not CSS classes — classes do
   not reliably reach script-created SVG elements inside a sub-composition.

## The rules that matter more than the code

Colour means one thing and never drifts: **clay = it fails or it's legacy, black =
everything else.** That is why charts never sit on a clay field — the accent would
vanish into its own background. The Python enforces this: asking `figure()` for a
clay field raises rather than drawing it.

Type crops off the left edge on purpose. Losing a letter on the right just reads
as a bug.

Every reveal is keyed to the sentence of narration that describes it, and every
beat boundary is cut in the middle of a silence gap. That is measured from the
audio, never hand-tuned.

---

Prior · https://prior-fm.github.io/prior-site/

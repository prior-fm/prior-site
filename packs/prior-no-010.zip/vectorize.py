"""No. 010 — an image is a point.

    python vectorize.py photo.jpg            # 9x12 grid, like the film
    python vectorize.py photo.jpg 24 32      # any grid you like

This is the film's whole argument, runnable. Take an image, read the numbers
left to right, row by row: you get one long list — a vector x with components
x_1 .. x_n. If the image has n pixels, the image IS a point in n-dimensional
real space, and you can start doing geometry with images.

The film's own numbers come from this exact pipeline: its 9x12 grid has
n = 108 cells, and the full 1537x2048 photograph is a vector with
n = 3,147,776 components. Nothing was typed by hand.

Needs Pillow only:  pip install pillow
"""

import sys

from PIL import Image

path = sys.argv[1] if len(sys.argv) > 1 else None
if path is None:
    sys.exit("usage: python vectorize.py <image> [cols rows]")
cols = int(sys.argv[2]) if len(sys.argv) > 2 else 9
rows = int(sys.argv[3]) if len(sys.argv) > 3 else 12

im = Image.open(path).convert("L")
w, h = im.size

# --- the matrix: a real grayscale downsample --------------------------------
grid = im.resize((cols, rows), Image.LANCZOS)
cells = list(grid.getdata())  # row-major: left to right, row by row

print(f"image      {w} x {h}  ->  every pixel is one number (0..255)")
print(f"matrix     {cols} x {rows} downsample:")
for r in range(rows):
    print("           " + " ".join(f"{cells[r * cols + c]:3d}" for c in range(cols)))

# --- the flatten: one long list ---------------------------------------------
n = cols * rows
print(f"\nvector     x = [x_1 .. x_{n}]  (the rows above, laid end to end)")
print(f"           x_1 = {cells[0]}   x_2 = {cells[1]}   ...   x_{n} = {cells[-1]}")

# --- the point --------------------------------------------------------------
print(f"\npoint      the {cols}x{rows} version of this image is ONE point in R^{n}")
print(f"           the full image is one point in R^{w * h:,}".replace(",", ","))

# --- geometry: distance between two images is now just... distance ----------
# Split the image into left and right halves and measure how far apart they
# are AS POINTS. That single number is the whole reason to do this.
half_l = im.crop((0, 0, w // 2, h)).resize((cols, rows), Image.LANCZOS)
half_r = im.crop((w - w // 2, 0, w, h)).resize((cols, rows), Image.LANCZOS)
a, b = list(half_l.getdata()), list(half_r.getdata())
dist = sum((p - q) ** 2 for p, q in zip(a, b)) ** 0.5
print(f"\ngeometry   distance(left half, right half) = {dist:.1f}")
print("           two images, one number — that is geometry with images.")

grid_out = grid.resize((cols * 40, rows * 40), Image.NEAREST)
grid_out.save("matrix.png")
print("\nwrote matrix.png (the downsample, cell by cell)")

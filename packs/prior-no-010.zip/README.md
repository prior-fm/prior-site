# Prior — No. 010: an image is a point

The film, runnable. Two scripts, no setup beyond pip.

| Script | What it does | Needs |
|---|---|---|
| `vectorize.py` | image → matrix → vector → a point in ℝⁿ, plus one real piece of geometry (the distance between two images as points) | `pip install pillow` |
| `detect.py` | the film's DOG/TREE detection, re-runnable on your own photo (YOLOv8s, Open Images V7 classes) | `pip install ultralytics pillow` |

```
python vectorize.py your-photo.jpg
python detect.py your-photo.jpg
```

Every number in the film comes from these pipelines run on the film's own
CC0 photograph: the 9×12 grid's n = 108, the full photo's n = 3,147,776,
and the measured DOG 0.90 / TREE 0.30 boxes. Nothing typed by hand.

— prior.fm

"""No. 010 — the film's detection boxes, re-runnable on any photo.

    python detect.py photo.jpg

The DOG 0.90 / TREE 0.30 boxes in the film are a real model run on the film's
own CC0 photograph — this script, these weights — not numbers copied from
anywhere. Run it on your own photo and you get your own boxes.

The model is YOLOv8s trained on Open Images V7 (600 classes, including Tree —
plain COCO models cannot label a tree at all). First run downloads ~22 MB of
weights.

Needs:  pip install ultralytics pillow
"""

import sys

from PIL import Image, ImageDraw
from ultralytics import YOLO

path = sys.argv[1] if len(sys.argv) > 1 else None
if path is None:
    sys.exit("usage: python detect.py <image>")

model = YOLO("yolov8s-oiv7.pt")
result = model(path, conf=0.25, verbose=False)[0]

dets = sorted(
    ({"cls": result.names[int(b.cls)], "conf": float(b.conf), "xyxy": b.xyxy[0].tolist()}
     for b in result.boxes),
    key=lambda d: -d["conf"],
)

if not dets:
    sys.exit("nothing above conf 0.25 — try a busier photo")

for d in dets:
    x0, y0, x1, y1 = (round(v) for v in d["xyxy"])
    print(f"{d['cls'].upper():<14} {d['conf']:.2f}   box ({x0},{y0}) - ({x1},{y1})")

im = Image.open(path).convert("RGB")
draw = ImageDraw.Draw(im)
seen = set()
for d in dets:
    if d["cls"] in seen:  # top box per class, like the film
        continue
    seen.add(d["cls"])
    x0, y0, x1, y1 = d["xyxy"]
    draw.rectangle([x0, y0, x1, y1], outline=(218, 144, 98), width=max(3, im.width // 300))
    draw.text((x0 + 8, y0 + 8), f"{d['cls'].upper()} {d['conf']:.2f}", fill=(218, 144, 98))
im.save("detected.png")
print("\nwrote detected.png (top box per class)")
